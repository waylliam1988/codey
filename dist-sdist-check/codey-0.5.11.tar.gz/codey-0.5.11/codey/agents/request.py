"""Typed input for one coding-agent run."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from threading import Event
from typing import TYPE_CHECKING, Any, Protocol

from codey.agents.handoff import ConversationContext
from codey.agents.shell_approval import ShellApprovalRequest
from codey.agents.tools import AgentToolFns
from codey.completion.verification_policy import VerificationCandidate
from codey.providers.base import ChatProvider
from codey.runtime.core.models import ToolCall
from codey.runtime.core.protocol_window import ProtocolWindowRef
from codey.runtime.observe.events import RunEvent, print_run_event
from codey.toolchain.runtime import ToolOutcome

if TYPE_CHECKING:
    from codey.runs.trace import RunTraceRecorder
    from codey.runtime.write.mutation_line import RuntimeMutationLine
    from codey.storage.managed_outputs import ManagedOutputStore

DEFAULT_MAX_TURNS = 50
DEFAULT_STAGNANT_TURNS = 4


class ChangeTracker(Protocol):
    def capture_before(self, rel: str) -> None:
        """Record a file's pre-write content if it has not been captured."""

    def capture_after(self, rel: str) -> None:
        """Record the content produced by a successful write."""


@dataclass(frozen=True)
class RecoveredToolOutcome:
    call: ToolCall
    outcome: ToolOutcome
    turn: int
    tool_index: int
    effect_id: str = ""
    # Only recovery's verified adapter can supply this kernel capability.
    workspace_proof: object | None = None
    # True only for settled-result redelivery (原结果重发，未重新执行）：
    # any tool (including run/edit) may be redelivered from its durable
    # receipt. False means safe-replay rows, which stay safe-tools-only.
    redelivered: bool = False
    window_ref: ProtocolWindowRef | None = None


@dataclass(frozen=True)
class AgentRequest:
    provider: ChatProvider
    project: Path
    task: str
    max_turns: int = DEFAULT_MAX_TURNS
    stagnant_turns: int = DEFAULT_STAGNANT_TURNS
    on_event: Callable[[RunEvent], None] = print_run_event
    on_shell_request: Callable[[ShellApprovalRequest], None] | None = None
    stop_flag: Event | None = None
    fresh_chat: bool = True
    change_tracker: ChangeTracker | None = None
    conversation: ConversationContext | None = None
    provider_id: str = ""
    handoff: str = ""
    project_facts: str = ""
    research_context: str = ""
    project_map: str = ""
    project_config_warnings: str = ""
    work_checkpoint: str = ""
    verification_candidates: tuple[VerificationCandidate, ...] = ()
    verification_candidate_loader: Callable[
        [], tuple[VerificationCandidate, ...]
    ] | None = None
    verification_changed_files: tuple[str, ...] = ()
    verification_successful_checks: tuple[VerificationCandidate, ...] = ()
    coding_context_enabled: bool = True
    ghost_directive: str = ""
    ghost_continuity: str = ""
    ghost_experiences: str = ""
    completion_repair_context: str = ""
    completion_repair_context_payload: dict[str, object] | None = None
    permission_profile: str = "coding_writer"
    tool_fns: AgentToolFns | None = None
    trace_recorder: RunTraceRecorder | None = None
    session_id: str = ""
    run_id: str = ""
    effect_scope: str = ""
    runtime_mutations: RuntimeMutationLine | None = None
    workspace_revision_store: object | None = None
    workspace_ignored_paths: tuple[str, ...] = ()
    managed_outputs: ManagedOutputStore | None = None
    recovered_tool_outcomes: tuple[RecoveredToolOutcome, ...] = ()
    settled_tool_outcomes: tuple[RecoveredToolOutcome, ...] = ()
    recovered_tool_result_batch_id: str = ""
    requested_capabilities: tuple[str, ...] = ()
    research_tools: object | None = None
    project_changes_required: bool = False
    strict_research: bool = False
    task_policy: object | None = None
    task_session: Any | None = None
    completion_context: dict[str, Any] | None = None


__all__ = [
    "AgentRequest",
    "ChangeTracker",
    "DEFAULT_MAX_TURNS",
    "DEFAULT_STAGNANT_TURNS",
    "RecoveredToolOutcome",
    "ShellApprovalRequest",
]
