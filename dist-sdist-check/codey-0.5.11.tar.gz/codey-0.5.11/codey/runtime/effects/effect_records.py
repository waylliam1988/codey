"""Runtime external effect intent, settlement, and recovery projection.

The session log is the durable fact source. This module owns bounded effect
record schemas and projections. Production writes go through
``runtime.mutation_line`` so effect records and operation-state leaves commit
together.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, cast

from codey.runtime.core.operation_state import lane_for_run, operation_id_for_run
from codey.runtime.effects.keep_policies import (
    SENT_STATE_MAYBE_SENT,
    SETTLEMENT_STATUS_ERROR,
    SETTLEMENT_STATUS_INTERRUPTED,
    keep_effect_pair_for_compaction,
)
from codey.runtime.effects.replay_args import validate_replay_args_shape
from codey.runtime.effects.replay_policy import (
    ReplayClass,
    is_replayable_safe_tool,
)
from codey.runtime.log.session_log import RuntimeSessionLog
from codey.storage.local_store import session_key

SCHEMA_VERSION = 1
EFFECT_KIND = "runtime_effect"

RECORD_KIND_INTENT = "intent"
RECORD_KIND_SETTLEMENT = "settlement"
RECORD_KINDS = frozenset({RECORD_KIND_INTENT, RECORD_KIND_SETTLEMENT})

EFFECT_CATEGORY_PROVIDER_SEND = "provider_send"
EFFECT_CATEGORY_TOOL_CALL = "tool_call"
EFFECT_CATEGORIES = frozenset({
    EFFECT_CATEGORY_PROVIDER_SEND,
    EFFECT_CATEGORY_TOOL_CALL,
})

SETTLEMENT_STATUS_OK = "ok"
SETTLEMENT_STATUSES = frozenset({
    SETTLEMENT_STATUS_OK,
    SETTLEMENT_STATUS_ERROR,
    SETTLEMENT_STATUS_INTERRUPTED,
})

SENT_STATE_SETTLED = "settled"
# A send that deterministically produced no usable provider reply (e.g. the
# provider rejected the request before processing it). Unlike MAYBE_SENT, a
# NOT_SENT attempt is safe to supersede with a retry of the same batch.
SENT_STATE_NOT_SENT = "not_sent"
SENT_STATES = frozenset({
    SENT_STATE_MAYBE_SENT,
    SENT_STATE_SETTLED,
    SENT_STATE_NOT_SENT,
})

MAX_EFFECT_ID_CHARS = 128
MAX_TEXT_CHARS = 120
MAX_REF_CHARS = 160
MAX_CALL_ID_CHARS = 256
MAX_ERROR_CODE_CHARS = 80
MAX_ARGS_DIGEST_CHARS = 64
MAX_RESULT_SHA_CHARS = 64

_INTENT_PAYLOAD_KEYS = frozenset({
    "schema_version",
    "effect_kind",
    "record_kind",
    "ref",
    "effect_id",
    "effect_category",
    "session_id",
    "run_id",
    "lane",
    "operation_id",
    "phase",
    "provider_id",
    "turn",
    "tool_index",
    "tool_name",
    "tool_id",
    "call_id",
    "args_digest",
    "display_ref",
    "replay_class",
    "replay_args",
    "created_at",
})
_SETTLEMENT_PAYLOAD_KEYS = frozenset({
    "schema_version",
    "effect_kind",
    "record_kind",
    "ref",
    "effect_id",
    "effect_category",
    "session_id",
    "run_id",
    "lane",
    "operation_id",
    "status",
    "error_code",
    "sent_state",
    "replay_class",
    "replay_count",
    "replayed_from_effect_id",
    "result_excerpt",
    "result_ref",
    "result_text",
    "result_payload",
    "result_payload_sha256",
    "result_len",
    "result_truncated",
    "result_sha256",
    "call_id",
    "exit_code",
    "created_at",
})

MAX_RESULT_TEXT_CHARS = 8000

class RuntimeEffectError(Exception):
    """Base error for runtime effect violations."""


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


def new_effect_id(category: str, run_id: str) -> str:
    """Generate a globally unique effect id for each distinct execution attempt."""
    short_cat = (category or "eff")[:12]
    safe_run = session_key(run_id) or "run"
    return f"eff_{short_cat}_{safe_run}_{uuid.uuid4().hex[:12]}"


def compute_args_digest(args: Any) -> str:
    """Compute a bounded deterministic digest of arguments without storing raw text."""
    if args is None:
        return ""
    if isinstance(args, str):
        content = args.encode("utf-8")
    else:
        try:
            content = json.dumps(args, sort_keys=True, ensure_ascii=False).encode("utf-8")
        except Exception:
            content = str(args).encode("utf-8")
    return f"sha256:{hashlib.sha256(content).hexdigest()[:16]}"


def _require_bounded_str(val: Any, name: str, max_len: int, *, allow_empty: bool = False) -> str:
    if not isinstance(val, str):
        raise RuntimeEffectError(f"{name} must be a str")
    if not allow_empty and not val:
        raise RuntimeEffectError(f"{name} must not be empty")
    if len(val) > max_len:
        raise RuntimeEffectError(f"{name} exceeds max length {max_len}")
    return val


def _require_nonnegative_int(val: Any, name: str) -> int:
    if isinstance(val, bool) or not isinstance(val, int):
        raise RuntimeEffectError(f"{name} must be an integer")
    if val < 0:
        raise RuntimeEffectError(f"{name} must be non-negative")
    return cast(int, val)


def _require_enum_str(val: Any, name: str, allowed: frozenset[str] | tuple[str, ...]) -> str:
    if not isinstance(val, str) or not val:
        raise RuntimeEffectError(f"missing or invalid {name}: {val}")
    if val not in allowed:
        raise RuntimeEffectError(f"unknown {name}: {val}")
    return val


def _reject_unknown_payload_keys(payload: dict[str, Any], allowed: frozenset[str]) -> None:
    unknown = sorted(set(payload) - allowed)
    if unknown:
        raise RuntimeEffectError(f"unknown effect payload keys: {', '.join(unknown)}")


def _require_ref(payload: dict[str, Any], expected: str) -> None:
    actual = _require_bounded_str(payload.get("ref"), "ref", MAX_REF_CHARS)
    if actual != expected:
        raise RuntimeEffectError(f"effect ref '{actual}' does not match expected ref '{expected}'")


def _replay_args_from_payload(
    *,
    effect_category: str,
    replay_class: str,
    tool_name: str,
    raw_replay_args: Any,
) -> dict[str, object] | None:
    if raw_replay_args is None:
        return None
    if (
        effect_category != EFFECT_CATEGORY_TOOL_CALL
        or replay_class != ReplayClass.SAFE
        or not is_replayable_safe_tool(tool_name)
    ):
        return None
    if not isinstance(raw_replay_args, dict):
        return None
    try:
        validate_replay_args_shape(tool_name, raw_replay_args)
    except ValueError:
        return None
    return dict(raw_replay_args)


@dataclass(frozen=True)
class RuntimeEffectIntent:
    effect_id: str
    effect_category: str
    session_id: str
    run_id: str
    lane: str = ""
    operation_id: str = ""
    phase: str = ""
    provider_id: str = ""
    turn: int = 0
    tool_index: int = 0
    tool_name: str = ""
    tool_id: str = ""
    # 原生协议调用身份，原样保留（永不截断成另一个 id；超限由写入方拒绝）。
    call_id: str = ""
    args_digest: str = ""
    display_ref: str = ""
    replay_class: str = ReplayClass.UNSAFE
    replay_args: dict[str, object] | None = None
    created_at: str = ""
    record_kind: str = RECORD_KIND_INTENT
    schema_version: int = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if type(self.schema_version) is not int or self.schema_version != SCHEMA_VERSION:
            raise RuntimeEffectError(f"invalid schema_version: {self.schema_version}")
        _require_bounded_str(self.effect_id, "effect_id", MAX_EFFECT_ID_CHARS)
        _require_bounded_str(self.session_id, "session_id", MAX_REF_CHARS)
        _require_bounded_str(self.run_id, "run_id", MAX_REF_CHARS)
        _require_bounded_str(self.lane, "lane", MAX_REF_CHARS, allow_empty=True)
        _require_bounded_str(self.operation_id, "operation_id", MAX_REF_CHARS, allow_empty=True)
        _require_bounded_str(self.phase, "phase", MAX_TEXT_CHARS, allow_empty=True)
        _require_bounded_str(self.provider_id, "provider_id", MAX_TEXT_CHARS, allow_empty=True)
        _require_bounded_str(self.tool_name, "tool_name", MAX_TEXT_CHARS, allow_empty=True)
        _require_bounded_str(self.tool_id, "tool_id", MAX_TEXT_CHARS, allow_empty=True)
        _require_bounded_str(self.call_id, "call_id", MAX_CALL_ID_CHARS, allow_empty=True)
        _require_bounded_str(self.args_digest, "args_digest", MAX_ARGS_DIGEST_CHARS, allow_empty=True)
        _require_bounded_str(self.display_ref, "display_ref", MAX_TEXT_CHARS, allow_empty=True)
        _require_bounded_str(self.created_at, "created_at", MAX_TEXT_CHARS, allow_empty=True)
        _require_nonnegative_int(self.turn, "turn")
        _require_nonnegative_int(self.tool_index, "tool_index")
        _require_enum_str(self.effect_category, "effect_category", EFFECT_CATEGORIES)
        if self.record_kind != RECORD_KIND_INTENT:
            raise RuntimeEffectError("record_kind must be 'intent'")
        _require_enum_str(self.replay_class, "replay_class", (ReplayClass.SAFE, ReplayClass.UNSAFE))
        if self.replay_args is not None:
            if not isinstance(self.replay_args, dict):
                raise RuntimeEffectError("replay_args must be a dict or None")
            if (
                self.effect_category != EFFECT_CATEGORY_TOOL_CALL
                or self.replay_class != ReplayClass.SAFE
                or not is_replayable_safe_tool(self.tool_name)
            ):
                raise RuntimeEffectError("replay_args only permitted for replayable safe tool calls")
            try:
                validate_replay_args_shape(self.tool_name, self.replay_args)
            except ValueError as exc:
                raise RuntimeEffectError(f"invalid replay_args: {exc}") from exc

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "effect_kind": EFFECT_KIND,
            "record_kind": self.record_kind,
            "ref": f"effect:{self.effect_id}",
            "effect_id": self.effect_id,
            "effect_category": self.effect_category,
            "session_id": self.session_id,
            "run_id": self.run_id,
            "lane": self.lane,
            "operation_id": self.operation_id,
            "phase": self.phase,
            "provider_id": self.provider_id,
            "turn": self.turn,
            "tool_index": self.tool_index,
            "tool_name": self.tool_name,
            "tool_id": self.tool_id,
            "args_digest": self.args_digest,
            "display_ref": self.display_ref,
            "replay_class": self.replay_class,
            "created_at": self.created_at,
        }
        if self.call_id:
            payload["call_id"] = self.call_id
        if self.replay_args is not None:
            payload["replay_args"] = dict(self.replay_args)
        return payload

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> RuntimeEffectIntent:
        if not isinstance(payload, dict):
            raise RuntimeEffectError("payload must be a dict")
        _reject_unknown_payload_keys(payload, _INTENT_PAYLOAD_KEYS)
        if payload.get("effect_kind") != EFFECT_KIND or payload.get("record_kind") != RECORD_KIND_INTENT:
            raise RuntimeEffectError("invalid payload kind for RuntimeEffectIntent")
        version = payload.get("schema_version")
        if type(version) is not int or version != SCHEMA_VERSION:
            raise RuntimeEffectError(f"unsupported schema version: {version}")
        effect_id = _require_bounded_str(payload.get("effect_id"), "effect_id", MAX_EFFECT_ID_CHARS)
        _require_ref(payload, f"effect:{effect_id}")
        effect_category = _require_enum_str(payload.get("effect_category"), "effect_category", EFFECT_CATEGORIES)
        tool_name = _require_bounded_str(payload.get("tool_name") or "", "tool_name", MAX_TEXT_CHARS, allow_empty=True)
        replay_class = _require_enum_str(payload.get("replay_class"), "replay_class", (ReplayClass.SAFE, ReplayClass.UNSAFE))
        replay_args = _replay_args_from_payload(
            effect_category=effect_category,
            replay_class=replay_class,
            tool_name=tool_name,
            raw_replay_args=payload.get("replay_args"),
        )

        return cls(
            effect_id=effect_id,
            effect_category=effect_category,
            session_id=_require_bounded_str(payload.get("session_id"), "session_id", MAX_REF_CHARS),
            run_id=_require_bounded_str(payload.get("run_id"), "run_id", MAX_REF_CHARS),
            lane=_require_bounded_str(payload.get("lane"), "lane", MAX_REF_CHARS),
            operation_id=_require_bounded_str(payload.get("operation_id"), "operation_id", MAX_REF_CHARS),
            phase=_require_bounded_str(payload.get("phase") or "", "phase", MAX_TEXT_CHARS, allow_empty=True),
            provider_id=_require_bounded_str(payload.get("provider_id") or "", "provider_id", MAX_TEXT_CHARS, allow_empty=True),
            turn=_require_nonnegative_int(payload.get("turn"), "turn"),
            tool_index=_require_nonnegative_int(payload.get("tool_index"), "tool_index"),
            tool_name=tool_name,
            tool_id=_require_bounded_str(payload.get("tool_id") or "", "tool_id", MAX_TEXT_CHARS, allow_empty=True),
            call_id=_require_bounded_str(payload.get("call_id") or "", "call_id", MAX_CALL_ID_CHARS, allow_empty=True),
            args_digest=_require_bounded_str(payload.get("args_digest") or "", "args_digest", MAX_ARGS_DIGEST_CHARS, allow_empty=True),
            display_ref=_require_bounded_str(payload.get("display_ref") or "", "display_ref", MAX_TEXT_CHARS, allow_empty=True),
            replay_class=replay_class,
            replay_args=replay_args,
            created_at=_require_bounded_str(payload.get("created_at") or "", "created_at", MAX_TEXT_CHARS, allow_empty=True),
            record_kind=RECORD_KIND_INTENT,
            schema_version=SCHEMA_VERSION,
        )


@dataclass(frozen=True)
class RuntimeEffectSettlement:
    effect_id: str
    effect_category: str
    session_id: str
    run_id: str
    status: str = SETTLEMENT_STATUS_OK
    lane: str = ""
    operation_id: str = ""
    error_code: str = ""
    sent_state: str = SENT_STATE_SETTLED
    replay_class: str = ReplayClass.UNSAFE
    replay_count: int = 0
    replayed_from_effect_id: str = ""
    created_at: str = ""
    record_kind: str = RECORD_KIND_SETTLEMENT
    schema_version: int = SCHEMA_VERSION
    result_excerpt: str = ""
    result_ref: str = ""
    result_text: str = ""
    result_payload: str = ""
    result_payload_sha256: str = ""
    # 完整结果收据：原结果字符长度、是否截断、全文 sha256、原生 call id。
    # result_text 仍以 8000 字符为界；超界结果必须经受管引用恢复全量，
    # result_truncated 诚实标记，绝不静默截断。
    result_len: int = 0
    result_truncated: bool = False
    result_sha256: str = ""
    call_id: str = ""
    exit_code: int | None = None

    def __post_init__(self) -> None:
        if type(self.schema_version) is not int or self.schema_version != SCHEMA_VERSION:
            raise RuntimeEffectError(f"invalid schema_version: {self.schema_version}")
        _require_bounded_str(self.effect_id, "effect_id", MAX_EFFECT_ID_CHARS)
        _require_bounded_str(self.session_id, "session_id", MAX_REF_CHARS)
        _require_bounded_str(self.run_id, "run_id", MAX_REF_CHARS)
        _require_bounded_str(self.lane, "lane", MAX_REF_CHARS, allow_empty=True)
        _require_bounded_str(self.operation_id, "operation_id", MAX_REF_CHARS, allow_empty=True)
        _require_bounded_str(self.error_code, "error_code", MAX_ERROR_CODE_CHARS, allow_empty=True)
        _require_bounded_str(self.created_at, "created_at", MAX_TEXT_CHARS, allow_empty=True)
        _require_nonnegative_int(self.replay_count, "replay_count")
        _require_nonnegative_int(self.result_len, "result_len")
        if type(self.result_truncated) is not bool:
            raise RuntimeEffectError("result_truncated must be a boolean")
        _require_bounded_str(self.result_sha256, "result_sha256", MAX_RESULT_SHA_CHARS, allow_empty=True)
        _require_bounded_str(self.call_id, "call_id", MAX_CALL_ID_CHARS, allow_empty=True)
        _require_bounded_str(self.replayed_from_effect_id, "replayed_from_effect_id", MAX_EFFECT_ID_CHARS, allow_empty=True)
        _require_bounded_str(self.result_excerpt, "result_excerpt", 500, allow_empty=True)
        _require_bounded_str(self.result_ref, "result_ref", MAX_REF_CHARS, allow_empty=True)
        _require_bounded_str(self.result_text, "result_text", MAX_RESULT_TEXT_CHARS, allow_empty=True)
        _require_bounded_str(self.result_payload, "result_payload", MAX_RESULT_TEXT_CHARS, allow_empty=True)
        for digest in (self.result_sha256, self.result_payload_sha256):
            if digest and (len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest)):
                raise RuntimeEffectError("invalid result digest")
        if self.exit_code is not None and type(self.exit_code) is not int:
            raise RuntimeEffectError("exit_code must be an integer or None")
        if self.replayed_from_effect_id and self.replayed_from_effect_id != self.effect_id:
            raise RuntimeEffectError(
                f"replayed_from_effect_id '{self.replayed_from_effect_id}' must match effect_id '{self.effect_id}'"
            )
        _require_enum_str(self.effect_category, "effect_category", EFFECT_CATEGORIES)
        if self.record_kind != RECORD_KIND_SETTLEMENT:
            raise RuntimeEffectError("record_kind must be 'settlement'")
        _require_enum_str(self.status, "status", SETTLEMENT_STATUSES)
        _require_enum_str(self.sent_state, "sent_state", SENT_STATES)
        _require_enum_str(self.replay_class, "replay_class", (ReplayClass.SAFE, ReplayClass.UNSAFE))

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "effect_kind": EFFECT_KIND,
            "record_kind": self.record_kind,
            "ref": f"effect_settlement:{self.effect_id}",
            "effect_id": self.effect_id,
            "effect_category": self.effect_category,
            "session_id": self.session_id,
            "run_id": self.run_id,
            "lane": self.lane,
            "operation_id": self.operation_id,
            "status": self.status,
            "error_code": self.error_code,
            "sent_state": self.sent_state,
            "replay_class": self.replay_class,
            "created_at": self.created_at,
        }
        if self.replay_count:
            payload["replay_count"] = self.replay_count
        if self.replayed_from_effect_id:
            payload["replayed_from_effect_id"] = self.replayed_from_effect_id
        if self.result_excerpt:
            payload["result_excerpt"] = self.result_excerpt
        if self.result_ref:
            payload["result_ref"] = self.result_ref
        if self.result_text:
            payload["result_text"] = self.result_text
        if self.result_payload:
            payload["result_payload"] = self.result_payload
        if self.result_payload_sha256:
            payload["result_payload_sha256"] = self.result_payload_sha256
        if self.result_len:
            payload["result_len"] = self.result_len
        if self.result_truncated:
            payload["result_truncated"] = self.result_truncated
        if self.result_sha256:
            payload["result_sha256"] = self.result_sha256
        if self.call_id:
            payload["call_id"] = self.call_id
        if self.exit_code is not None:
            payload["exit_code"] = self.exit_code
        return payload

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> RuntimeEffectSettlement:
        if not isinstance(payload, dict):
            raise RuntimeEffectError("payload must be a dict")
        _reject_unknown_payload_keys(payload, _SETTLEMENT_PAYLOAD_KEYS)
        if payload.get("effect_kind") != EFFECT_KIND or payload.get("record_kind") != RECORD_KIND_SETTLEMENT:
            raise RuntimeEffectError("invalid payload kind for RuntimeEffectSettlement")
        version = payload.get("schema_version")
        if type(version) is not int or version != SCHEMA_VERSION:
            raise RuntimeEffectError(f"unsupported schema version: {version}")
        effect_id = _require_bounded_str(payload.get("effect_id"), "effect_id", MAX_EFFECT_ID_CHARS)
        _require_ref(payload, f"effect_settlement:{effect_id}")

        replay_count = _require_nonnegative_int(payload.get("replay_count", 0), "replay_count")
        replayed_from_effect_id = _require_bounded_str(
            payload.get("replayed_from_effect_id") or "",
            "replayed_from_effect_id",
            MAX_EFFECT_ID_CHARS,
            allow_empty=True,
        )
        result_excerpt = _require_bounded_str(payload.get("result_excerpt") or "", "result_excerpt", 500, allow_empty=True)
        result_ref = _require_bounded_str(payload.get("result_ref") or "", "result_ref", MAX_REF_CHARS, allow_empty=True)
        result_text = _require_bounded_str(payload.get("result_text") or "", "result_text", MAX_RESULT_TEXT_CHARS, allow_empty=True)
        result_len = payload.get("result_len", 0)
        if result_len is None:
            result_len = 0
        result_len = _require_nonnegative_int(result_len, "result_len")
        raw_truncated = payload.get("result_truncated", False)
        if raw_truncated is None:
            raw_truncated = False
        if type(raw_truncated) is not bool:
            raise RuntimeEffectError("result_truncated must be a boolean")
        result_sha256 = _require_bounded_str(
            payload.get("result_sha256") or "", "result_sha256", MAX_RESULT_SHA_CHARS, allow_empty=True,
        )
        call_id = _require_bounded_str(
            payload.get("call_id") or "", "call_id", MAX_CALL_ID_CHARS, allow_empty=True,
        )
        raw_exit = payload.get("exit_code")
        if raw_exit is not None and type(raw_exit) is not int:
            raise RuntimeEffectError("exit_code must be an integer or None")
        exit_code = raw_exit if type(raw_exit) is int else None

        return cls(
            effect_id=effect_id,
            effect_category=_require_enum_str(payload.get("effect_category"), "effect_category", EFFECT_CATEGORIES),
            session_id=_require_bounded_str(payload.get("session_id"), "session_id", MAX_REF_CHARS),
            run_id=_require_bounded_str(payload.get("run_id"), "run_id", MAX_REF_CHARS),
            status=_require_enum_str(payload.get("status"), "status", SETTLEMENT_STATUSES),
            lane=_require_bounded_str(payload.get("lane"), "lane", MAX_REF_CHARS),
            operation_id=_require_bounded_str(payload.get("operation_id"), "operation_id", MAX_REF_CHARS),
            error_code=_require_bounded_str(payload.get("error_code") or "", "error_code", MAX_ERROR_CODE_CHARS, allow_empty=True),
            sent_state=_require_enum_str(payload.get("sent_state"), "sent_state", SENT_STATES),
            replay_class=_require_enum_str(payload.get("replay_class"), "replay_class", (ReplayClass.SAFE, ReplayClass.UNSAFE)),
            replay_count=replay_count,
            replayed_from_effect_id=replayed_from_effect_id,
            result_excerpt=result_excerpt,
            result_ref=result_ref,
            result_text=result_text,
            result_payload=payload.get("result_payload", ""),
            result_payload_sha256=payload.get("result_payload_sha256", ""),
            result_len=result_len,
            result_truncated=raw_truncated,
            result_sha256=result_sha256,
            call_id=call_id,
            exit_code=exit_code,
            created_at=_require_bounded_str(payload.get("created_at") or "", "created_at", MAX_TEXT_CHARS, allow_empty=True),
            record_kind=RECORD_KIND_SETTLEMENT,
            schema_version=SCHEMA_VERSION,
        )


@dataclass(frozen=True)
class RuntimeEffectProjection:
    intent: RuntimeEffectIntent
    settlement: RuntimeEffectSettlement | None = None

    @property
    def is_pending(self) -> bool:
        return self.settlement is None

    @property
    def is_settled(self) -> bool:
        return self.settlement is not None


@dataclass(frozen=True)
class RecoverySummary:
    interrupted_writes: int = 0
    unconfirmed_provider_calls: int = 0
    retryable_read_only: int = 0
    interrupted_repairs: int = 0
    replayed_reads: int = 0
    replayed_lookups: int = 0
    explanation_lines: tuple[str, ...] = ()


def prepare_intent(
    session_id: str,
    run_id: str,
    intent: RuntimeEffectIntent,
) -> RuntimeEffectIntent:
    """Return an intent with canonical lane/op/timestamp for a run."""
    if intent.session_id != session_id:
        raise RuntimeEffectError(
            f"intent session_id '{intent.session_id}' does not match expected session_id '{session_id}'"
        )
    if intent.run_id != run_id:
        raise RuntimeEffectError(
            f"intent run_id '{intent.run_id}' does not match expected run_id '{run_id}'"
        )
    expected_lane = lane_for_run(run_id)
    expected_op = operation_id_for_run(run_id)
    if intent.lane and intent.lane != expected_lane:
        raise RuntimeEffectError(
            f"intent lane '{intent.lane}' does not match expected lane '{expected_lane}' for run {run_id}"
        )
    if intent.operation_id and intent.operation_id != expected_op:
        raise RuntimeEffectError(
            f"intent operation_id '{intent.operation_id}' does not match expected operation_id '{expected_op}' for run {run_id}"
        )
    return RuntimeEffectIntent(
        effect_id=intent.effect_id,
        effect_category=intent.effect_category,
        session_id=session_id,
        run_id=run_id,
        lane=expected_lane,
        operation_id=expected_op,
        phase=intent.phase,
        provider_id=intent.provider_id,
        turn=intent.turn,
        tool_index=intent.tool_index,
        tool_name=intent.tool_name,
        tool_id=intent.tool_id,
        call_id=intent.call_id,
        args_digest=intent.args_digest,
        display_ref=intent.display_ref,
        replay_class=intent.replay_class,
        replay_args=intent.replay_args,
        created_at=intent.created_at or _now(),
    )


def effect_intent_entry(intent: RuntimeEffectIntent) -> dict[str, object]:
    return {
        "lane": intent.lane,
        "operation_id": intent.operation_id,
        "kind": "operation_effect",
        "payload": intent.to_payload(),
    }


def prepare_settlement(
    session_id: str,
    run_id: str,
    settlement: RuntimeEffectSettlement,
    effects: tuple[RuntimeEffectProjection, ...],
) -> RuntimeEffectSettlement:
    """Return a canonical settlement validated against projected intents."""
    if settlement.session_id != session_id:
        raise RuntimeEffectError(
            f"settlement session_id '{settlement.session_id}' does not match expected session_id '{session_id}'"
        )
    if settlement.run_id != run_id:
        raise RuntimeEffectError(
            f"settlement run_id '{settlement.run_id}' does not match expected run_id '{run_id}'"
        )
    expected_lane = lane_for_run(run_id)
    expected_op = operation_id_for_run(run_id)
    if settlement.lane and settlement.lane != expected_lane:
        raise RuntimeEffectError(
            f"settlement lane '{settlement.lane}' does not match expected lane '{expected_lane}' for run {run_id}"
        )
    if settlement.operation_id and settlement.operation_id != expected_op:
        raise RuntimeEffectError(
            f"settlement operation_id '{settlement.operation_id}' does not match expected operation_id '{expected_op}' for run {run_id}"
        )
    matching = next((p for p in effects if p.intent.effect_id == settlement.effect_id), None)
    if matching is None:
        raise RuntimeEffectError(f"cannot record settlement for unknown intent: {settlement.effect_id}")
    if settlement.effect_category != matching.intent.effect_category:
        raise RuntimeEffectError(
            f"settlement category '{settlement.effect_category}' does not match intent category '{matching.intent.effect_category}'"
        )
    if settlement.call_id and settlement.call_id != matching.intent.call_id:
        raise RuntimeEffectError("settlement call_id differs from intent")
    # An omitted id inherits the persisted intent identity.
    effective_call_id = settlement.call_id or matching.intent.call_id
    if matching.settlement is not None:
        existing = matching.settlement
        if (
            existing.status == settlement.status
            and existing.error_code == settlement.error_code
            and existing.sent_state == settlement.sent_state
            and existing.replay_class == settlement.replay_class
            and existing.replay_count == settlement.replay_count
            and existing.replayed_from_effect_id == settlement.replayed_from_effect_id
            and existing.result_excerpt == settlement.result_excerpt
            and existing.result_ref == settlement.result_ref
            and existing.result_text == settlement.result_text
            and existing.result_payload == settlement.result_payload
            and existing.result_payload_sha256 == settlement.result_payload_sha256
            and existing.result_len == settlement.result_len
            and existing.result_truncated == settlement.result_truncated
            and existing.result_sha256 == settlement.result_sha256
            and existing.call_id == effective_call_id
            and existing.exit_code == settlement.exit_code
        ):
            return existing
        raise RuntimeEffectError(f"effect already settled: {settlement.effect_id}")
    return RuntimeEffectSettlement(
        effect_id=settlement.effect_id,
        effect_category=matching.intent.effect_category,
        session_id=session_id,
        run_id=run_id,
        status=settlement.status,
        lane=expected_lane,
        operation_id=expected_op,
        error_code=settlement.error_code,
        sent_state=settlement.sent_state,
        replay_class=matching.intent.replay_class,
        replay_count=settlement.replay_count,
        replayed_from_effect_id=settlement.replayed_from_effect_id,
        result_excerpt=settlement.result_excerpt,
        result_ref=settlement.result_ref,
        result_text=settlement.result_text,
        result_payload=settlement.result_payload,
        result_payload_sha256=settlement.result_payload_sha256,
        result_len=settlement.result_len,
        result_truncated=settlement.result_truncated,
        result_sha256=settlement.result_sha256,
        call_id=effective_call_id,
        exit_code=settlement.exit_code,
        created_at=settlement.created_at or _now(),
    )


def effect_settlement_entry(settlement: RuntimeEffectSettlement) -> dict[str, object]:
    return {
        "lane": settlement.lane,
        "operation_id": settlement.operation_id,
        "kind": "operation_effect",
        "payload": settlement.to_payload(),
    }


def effects_from_entries(
    entries: tuple[Any, ...],
    *,
    session_id: str,
    run_id: str,
) -> tuple[RuntimeEffectProjection, ...]:
    """Project effect intent/settlement pairs from already-read log entries."""
    expected_lane = lane_for_run(run_id)
    expected_op = operation_id_for_run(run_id)
    intents: dict[str, RuntimeEffectIntent] = {}
    settlements: dict[str, RuntimeEffectSettlement] = {}
    ordered_effect_ids: list[str] = []

    for entry in entries:
        if entry.kind != "operation_effect":
            continue
        payload = entry.payload
        if not isinstance(payload, dict):
            continue
        if payload.get("effect_kind") != EFFECT_KIND:
            continue

        is_current_operation = (entry.lane == expected_lane or entry.operation_id == expected_op)
        is_current_run = (payload.get("run_id") == run_id)
        if not is_current_operation and not is_current_run:
            continue

        if entry.lane != expected_lane:
            raise RuntimeEffectError(
                f"entry lane '{entry.lane}' does not match expected lane '{expected_lane}' for run {run_id}"
            )
        if entry.operation_id != expected_op:
            raise RuntimeEffectError(
                f"entry operation_id '{entry.operation_id}' does not match expected operation_id '{expected_op}' for run {run_id}"
            )
        payload_session_id = payload.get("session_id")
        if not payload_session_id or payload_session_id != session_id:
            raise RuntimeEffectError(
                f"payload session_id '{payload_session_id}' does not match expected session_id '{session_id}' for run {run_id}"
            )
        payload_run_id = payload.get("run_id")
        if not payload_run_id or payload_run_id != run_id:
            raise RuntimeEffectError(
                f"payload run_id '{payload_run_id}' does not match expected run_id '{run_id}'"
            )
        payload_lane = payload.get("lane")
        if not payload_lane or payload_lane != expected_lane:
            raise RuntimeEffectError(
                f"payload lane '{payload_lane}' does not match expected lane '{expected_lane}' for run {run_id}"
            )
        payload_op = payload.get("operation_id")
        if not payload_op or payload_op != expected_op:
            raise RuntimeEffectError(
                f"payload operation_id '{payload_op}' does not match expected operation_id '{expected_op}'"
            )

        record_kind = payload.get("record_kind")
        effect_id = str(payload.get("effect_id") or "")
        if not effect_id:
            raise RuntimeEffectError("missing effect_id in effect payload")

        if record_kind == RECORD_KIND_INTENT:
            if effect_id in intents:
                raise RuntimeEffectError(f"duplicate intent in session log: {effect_id}")
            ordered_effect_ids.append(effect_id)
            intents[effect_id] = RuntimeEffectIntent.from_payload(payload)
            continue

        if record_kind == RECORD_KIND_SETTLEMENT:
            if effect_id not in intents:
                raise RuntimeEffectError(f"orphan settlement without intent in session log: {effect_id}")
            new_settlement = RuntimeEffectSettlement.from_payload(payload)
            if new_settlement.effect_category != intents[effect_id].effect_category:
                raise RuntimeEffectError(
                    f"settlement category '{new_settlement.effect_category}' does not match intent category '{intents[effect_id].effect_category}'"
                )
            if effect_id in settlements:
                existing = settlements[effect_id]
                if (
                    existing.status == new_settlement.status
                    and existing.error_code == new_settlement.error_code
                    and existing.sent_state == new_settlement.sent_state
                    and existing.effect_category == new_settlement.effect_category
                    and existing.replay_class == new_settlement.replay_class
                    and existing.replay_count == new_settlement.replay_count
                    and existing.replayed_from_effect_id == new_settlement.replayed_from_effect_id
                    and existing.result_excerpt == new_settlement.result_excerpt
                    and existing.result_ref == new_settlement.result_ref
                    and existing.result_text == new_settlement.result_text
                    and existing.result_payload == new_settlement.result_payload
                    and existing.result_payload_sha256 == new_settlement.result_payload_sha256
                    and existing.result_len == new_settlement.result_len
                    and existing.result_truncated == new_settlement.result_truncated
                    and existing.result_sha256 == new_settlement.result_sha256
                    and existing.call_id == new_settlement.call_id
                    and existing.exit_code == new_settlement.exit_code
                ):
                    continue
                raise RuntimeEffectError(f"conflicting duplicate settlement in session log: {effect_id}")
            settlements[effect_id] = new_settlement
            continue

        raise RuntimeEffectError(f"unknown record_kind: {record_kind}")

    return tuple(
        RuntimeEffectProjection(intent=intent, settlement=settlements.get(eid))
        for eid in ordered_effect_ids
        if (intent := intents.get(eid)) is not None
    )


def require_new_effect_id(
    effects: tuple[RuntimeEffectProjection, ...],
    effect_id: str,
) -> None:
    if any(effect.intent.effect_id == effect_id for effect in effects):
        raise RuntimeEffectError(f"duplicate effect id: {effect_id}")


def find_effect(
    effects: tuple[RuntimeEffectProjection, ...],
    effect_id: str,
) -> RuntimeEffectProjection:
    found = next((effect for effect in effects if effect.intent.effect_id == effect_id), None)
    if found is None:
        raise RuntimeEffectError(f"effect intent not found: {effect_id}")
    return found


class RuntimeEffectStore:
    """Projection store for external effect intents and settlements."""

    def __init__(self, session_log: RuntimeSessionLog) -> None:
        self.session_log = session_log

    def load_effects(
        self,
        session_id: str,
        run_id: str,
    ) -> tuple[RuntimeEffectProjection, ...]:
        """Load and aggregate all effect intent/settlement pairs for a run in strict chronological order."""
        return effects_from_entries(
            self.session_log.entries(session_id),
            session_id=session_id,
            run_id=run_id,
        )

    def pending_effects(
        self,
        session_id: str,
        run_id: str,
    ) -> tuple[RuntimeEffectProjection, ...]:
        """Return all effects that have an intent but no settlement yet."""
        return tuple(p for p in self.load_effects(session_id, run_id) if p.is_pending)

    def recovery_summary(
        self,
        session_id: str,
        run_id: str,
    ) -> RecoverySummary:
        """Derive quiet user-facing recovery explanation rows for a run."""
        effects = self.load_effects(session_id, run_id)
        interrupted_writes = 0
        unconfirmed_provider_calls = 0
        retryable_read_only = 0
        interrupted_repairs = 0
        replayed_reads = 0
        replayed_lookups = 0

        for proj in effects:
            intent = proj.intent
            settlement = proj.settlement
            if settlement is None:
                continue

            if settlement.replay_count > 0:
                if intent.tool_name == "read":
                    replayed_reads += 1
                elif intent.tool_name in {"ls", "search", "references"}:
                    replayed_lookups += 1
                continue

            if settlement.status != SETTLEMENT_STATUS_INTERRUPTED:
                continue

            if intent.effect_category == EFFECT_CATEGORY_PROVIDER_SEND:
                unconfirmed_provider_calls += 1
            elif intent.effect_category == EFFECT_CATEGORY_TOOL_CALL:
                if intent.replay_class == ReplayClass.SAFE:
                    retryable_read_only += 1
                else:
                    interrupted_writes += 1

        lines: list[str] = []
        if replayed_reads > 0:
            lines.append("Read action was recovered")
        if replayed_lookups > 0:
            lines.append("Lookup action was recovered")
        if retryable_read_only > 0:
            lines.append("Read-only action can be retried")
        if interrupted_writes > 0:
            lines.append("Local write was interrupted and was not repeated")
        if unconfirmed_provider_calls > 0:
            lines.append("Provider response was not confirmed")

        return RecoverySummary(
            interrupted_writes=interrupted_writes,
            unconfirmed_provider_calls=unconfirmed_provider_calls,
            retryable_read_only=retryable_read_only,
            interrupted_repairs=interrupted_repairs,
            replayed_reads=replayed_reads,
            replayed_lookups=replayed_lookups,
            explanation_lines=tuple(lines),
        )


__all__ = [
    "EFFECT_CATEGORIES",
    "EFFECT_CATEGORY_PROVIDER_SEND",
    "EFFECT_CATEGORY_TOOL_CALL",
    "EFFECT_KIND",
    "RECORD_KINDS",
    "RECORD_KIND_INTENT",
    "RECORD_KIND_SETTLEMENT",
    "RecoverySummary",
    "RuntimeEffectError",
    "RuntimeEffectIntent",
    "RuntimeEffectProjection",
    "RuntimeEffectSettlement",
    "RuntimeEffectStore",
    "SENT_STATES",
    "SENT_STATE_MAYBE_SENT",
    "SENT_STATE_NOT_SENT",
    "SENT_STATE_SETTLED",
    "SETTLEMENT_STATUSES",
    "SETTLEMENT_STATUS_ERROR",
    "SETTLEMENT_STATUS_INTERRUPTED",
    "SETTLEMENT_STATUS_OK",
    "compute_args_digest",
    "effect_intent_entry",
    "effect_settlement_entry",
    "effects_from_entries",
    "find_effect",
    "keep_effect_pair_for_compaction",
    "new_effect_id",
    "prepare_intent",
    "prepare_settlement",
    "require_new_effect_id",
]
