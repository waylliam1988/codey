"""Serialized runtime mutation boundary.

Every production mutation of durable operation state, effect ledger, delivery
ledger, and operation settlement goes through this line. The callback passed to
``RuntimeSessionLog.mutate`` stays pure: it reads the current projection and
entries, decides the next bounded records, and commits them as one batch.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import replace
from typing import Any

from codey.runtime.core.operation_state import (
    LEAF_TERMINAL,
    LEAF_TOOL_DELIVERY_PENDING,
    RuntimeOperationState,
    RuntimeOperationTransitionError,
    new_operation_state,
    operation_is_open,
    operation_state_entry,
    operation_state_from_entries,
    outcome_for_terminal,
    start_entries,
)
from codey.runtime.core.operation_state import (
    mark_candidate_validation_running as state_mark_candidate_validation_running,
)
from codey.runtime.core.operation_state import (
    mark_completion_blocked as state_mark_completion_blocked,
)
from codey.runtime.core.operation_state import (
    mark_completion_proof_recorded as state_mark_completion_proof_recorded,
)
from codey.runtime.core.operation_state import (
    mark_repair_context_admitted as state_mark_repair_context_admitted,
)
from codey.runtime.core.operation_state import (
    mark_repair_running as state_mark_repair_running,
)
from codey.runtime.core.operation_state import (
    mark_repair_settled as state_mark_repair_settled,
)
from codey.runtime.core.operation_state import (
    mark_terminal as state_mark_terminal,
)
from codey.runtime.core.operation_state import (
    mark_tool_delivery_settled as state_mark_tool_delivery_settled,
)
from codey.runtime.core.operation_state import (
    mark_writer_running as state_mark_writer_running,
)
from codey.runtime.core.operation_state import (
    mark_writer_settled as state_mark_writer_settled,
)
from codey.runtime.effects.effect_records import (
    EFFECT_CATEGORY_PROVIDER_SEND,
    EFFECT_CATEGORY_TOOL_CALL,
    RuntimeEffectError,
    RuntimeEffectIntent,
    RuntimeEffectSettlement,
)
from codey.runtime.effects.tool_result_delivery import DeliveryBatchIntent, abandoned_entry
from codey.runtime.log.entries import RuntimeLogEntry
from codey.runtime.log.session_log import RuntimeSessionLog
from codey.runtime.log.session_view import load_session_view
from codey.runtime.write.delivery_recovery import build_delivery_recovered_rows
from codey.runtime.write.provider_effects import (
    build_provider_begin_rows,
    build_provider_settle_rows,
)
from codey.runtime.write.tool_batches import (
    ToolBatchCommit,
    build_tool_batch_rows,
    build_tool_settle_rows,
)


def _resolve_abandoned_delivery(
    state: RuntimeOperationState,
) -> RuntimeOperationState:
    """Resolve a delivery the driver stopped inside of before settling.

    A run stopped from inside tool delivery (e.g. headless denied a shell
    request) leaves the leaf at tool_delivery_pending. Settling the writer or
    repair directly from there is illegal and would mask the real stop with a
    transition error, so the abandoned delivery is resolved back to its driver
    first. The denial itself stays recorded in events; this only unblocks the
    honest settle. The pure machine stays strict: this composition lives only
    in the two settle entries that own a driver lifecycle end.
    """
    if state.leaf == LEAF_TOOL_DELIVERY_PENDING:
        return state_mark_tool_delivery_settled(state)
    return state


class RuntimeMutationLine:
    """Single writer-facing API for runtime durable mutations."""
    def __init__(self, session_log: RuntimeSessionLog) -> None:
        self.session_log = session_log

    def admit_reviewer_selection(self, session_id: str, run_id: str, payload: dict[str, object]) -> RuntimeOperationState | None:
        from codey.runtime.core.operation_payload import _parse_model_selection

        admitted = _parse_model_selection(payload)

        def transition(state: RuntimeOperationState) -> RuntimeOperationState:
            if state.reviewer_selection and state.reviewer_selection != admitted:
                raise RuntimeOperationTransitionError("admitted reviewer selection is immutable")
            return replace(state, reviewer_selection=admitted)

        return self._commit_state(session_id, run_id, transition)


    def accept_operation(
        self,
        *,
        session_id: str,
        run_id: str,
        project: object = "",
        provider_id: str,
        turn_budget: int,
        max_repair_rounds: int,
        task_kind: str = "task",
        model_selection: dict[str, object] | None = None,
    ) -> RuntimeOperationState | None:
        accepted: RuntimeOperationState | None = None

        def mutation(projection: Any, entries: Any) -> Any:
            nonlocal accepted
            existing = operation_state_from_entries(
                entries,
                session_id=session_id,
                run_id=run_id,
            )
            if existing is not None:
                if model_selection is not None and existing.model_selection != model_selection:
                    raise RuntimeOperationTransitionError("admitted API selection is immutable")
                operation_is_open(projection, existing)
                accepted = existing
                return ()
            state = new_operation_state(
                session_id=session_id,
                run_id=run_id,
                project=project,
                provider_id=provider_id,
                turn_budget=turn_budget,
                max_repair_rounds=max_repair_rounds,
                task_kind=task_kind,
                model_selection=model_selection,
            )
            accepted = state
            return start_entries(projection, state)

        self.session_log.mutate(session_id, mutation)
        return accepted

    def _commit_state(
        self,
        session_id: str,
        run_id: str,
        transition: Callable[[RuntimeOperationState], RuntimeOperationState],
    ) -> RuntimeOperationState | None:
        committed: RuntimeOperationState | None = None

        def mutation(projection: Any, entries: Any) -> Any:
            nonlocal committed
            current = _require_state(entries, session_id=session_id, run_id=run_id)
            op = projection.operations.get(current.operation_id)
            if op is not None and op.status != "open":
                if current.leaf == LEAF_TERMINAL:
                    next_state = transition(current)
                    if next_state == current:
                        committed = current
                        return ()
                    raise RuntimeOperationTransitionError("terminal operation is immutable")
                raise RuntimeOperationTransitionError("operation already settled")
            operation_is_open(projection, current)
            next_state = transition(current)
            if next_state == current:
                committed = current
                return ()
            rows = [operation_state_entry(next_state)]
            if next_state.leaf == LEAF_TERMINAL:
                rows.append(_operation_settled_entry(next_state))
            committed = next_state
            return tuple(rows)

        self.session_log.mutate(session_id, mutation)
        return committed

    def _commit_settle(
        self,
        session_id: str,
        run_id: str,
        transition: Callable[[RuntimeOperationState], RuntimeOperationState],
        *,
        abandoned_reason: str,
    ) -> RuntimeOperationState | None:
        """Settle writer/repair, closing any undelivered batch as abandoned.

        The abandoned receipt and the operation settle commit in the same
        mutation: the batch never hangs as pending, and replay never treats
        it as recoverable. Abandoned is terminal, never disguised as
        delivered/recovered.
        """
        committed: RuntimeOperationState | None = None

        def mutation(projection: Any, entries: Any) -> Any:
            nonlocal committed
            current = _require_state(entries, session_id=session_id, run_id=run_id)
            op = projection.operations.get(current.operation_id)
            if op is not None and op.status != "open":
                if current.leaf == LEAF_TERMINAL:
                    next_state = transition(current)
                    if next_state == current:
                        committed = current
                        return ()
                    raise RuntimeOperationTransitionError("terminal operation is immutable")
                raise RuntimeOperationTransitionError("operation already settled")
            operation_is_open(projection, current)
            rows: list[dict[str, object]] = []
            if current.leaf == LEAF_TOOL_DELIVERY_PENDING:
                view = load_session_view(entries, session_id=session_id, run_id=run_id)
                for batch in view.batches:
                    if batch.intent.turn != current.turn:
                        continue
                    if batch.is_terminal:
                        continue
                    entry = abandoned_entry(
                        session_id,
                        run_id,
                        batch_id=batch.intent.batch_id,
                        reason=abandoned_reason,
                        batches=view.batches,
                    )
                    if entry is not None:
                        rows.append(entry)
            next_state = transition(current)
            if next_state == current and not rows:
                committed = current
                return ()
            rows.append(operation_state_entry(next_state))
            if next_state.leaf == LEAF_TERMINAL:
                rows.append(_operation_settled_entry(next_state))
            committed = next_state
            return tuple(rows)

        self.session_log.mutate(session_id, mutation)
        return committed

    def mark_writer_running(
        self,
        session_id: str,
        run_id: str,
        *,
        provider_id: str,
        writer_attempt: int = 1,
    ) -> RuntimeOperationState | None:
        return self._commit_state(
            session_id,
            run_id,
            lambda state: state_mark_writer_running(
                state,
                provider_id=provider_id,
                writer_attempt=writer_attempt,
            ),
        )

    def mark_candidate_validation_running(
        self, session_id: str, run_id: str, *, provider_id: str, writer_attempt: int,
    ) -> RuntimeOperationState | None:
        return self._commit_state(session_id, run_id,
            lambda state: state_mark_candidate_validation_running(state, provider_id=provider_id,
                                                                  writer_attempt=writer_attempt))

    def set_task_policy(
        self,
        session_id: str,
        run_id: str,
        *,
        policy: dict[str, object],
    ) -> RuntimeOperationState | None:
        """Persist the entry authorization snapshot on the operation state."""
        from codey.runtime.core.operation_payload import _parse_task_policy

        normalized = _parse_task_policy(policy)
        return self._commit_state(
            session_id,
            run_id,
            lambda state: _replace_task_policy(state, normalized),
        )

    def mark_writer_settled(
        self,
        session_id: str,
        run_id: str,
        *,
        provider_id: str,
        turns_used: int,
        stop_reason: str,
    ) -> RuntimeOperationState | None:
        return self._commit_settle(
            session_id,
            run_id,
            lambda state: state_mark_writer_settled(
                _resolve_abandoned_delivery(state),
                provider_id=provider_id,
                turns_used=turns_used,
                stop_reason=stop_reason,
            ),
            abandoned_reason="writer_settled",
        )

    def record_completion_proof(
        self,
        session_id: str,
        run_id: str,
        *,
        proof_ref: str,
        proof_status: str,
    ) -> RuntimeOperationState | None:
        return self._commit_state(
            session_id,
            run_id,
            lambda state: state_mark_completion_proof_recorded(
                state,
                proof_ref=proof_ref,
                proof_status=proof_status,
            ),
        )

    def admit_repair_context(
        self,
        session_id: str,
        run_id: str,
        *,
        context_ref: str,
    ) -> RuntimeOperationState | None:
        return self._commit_state(
            session_id,
            run_id,
            lambda state: state_mark_repair_context_admitted(
                state,
                context_ref=context_ref,
            ),
        )

    def mark_repair_running(
        self,
        session_id: str,
        run_id: str,
        *,
        provider_id: str,
    ) -> RuntimeOperationState | None:
        return self._commit_state(
            session_id,
            run_id,
            lambda state: state_mark_repair_running(state, provider_id=provider_id),
        )

    def mark_repair_settled(
        self,
        session_id: str,
        run_id: str,
        *,
        provider_id: str,
        stop_reason: str,
        blocked_reason: str = "",
        turns_used: int | None = None,
    ) -> RuntimeOperationState | None:
        return self._commit_settle(
            session_id,
            run_id,
            lambda state: state_mark_repair_settled(
                _resolve_abandoned_delivery(state),
                provider_id=provider_id,
                stop_reason=stop_reason,
                blocked_reason=blocked_reason,
                turns_used=turns_used,
            ),
            abandoned_reason="repair_settled",
        )

    def mark_completion_blocked(
        self,
        session_id: str,
        run_id: str,
        *,
        reason: str,
    ) -> RuntimeOperationState | None:
        return self._commit_state(
            session_id,
            run_id,
            lambda state: state_mark_completion_blocked(state, reason=reason),
        )

    def mark_terminal(
        self,
        session_id: str,
        run_id: str,
        *,
        stop_reason: str,
        summary_chars: int,
        turns: int,
        max_turns: int,
        provider: str,
        blocked_reason: str | None = None,
        final_delivery: str | None = None,
        proof_ref: str = "",
        proof_status: str = "",
    ) -> RuntimeOperationState | None:
        return self._commit_state(
            session_id,
            run_id,
            lambda state: state_mark_terminal(
                state,
                stop_reason=stop_reason,
                summary_chars=summary_chars,
                turns=turns,
                max_turns=max_turns,
                provider=provider,
                blocked_reason=blocked_reason,
                final_delivery=final_delivery,
                proof_ref=proof_ref,
                proof_status=proof_status,
            ),
        )

    def begin_provider_effect(
        self,
        session_id: str,
        run_id: str,
        intent: RuntimeEffectIntent,
        *,
        driver: str = "",
        delivery_batch_id: str = "",
        supersede_effect_id: str = "",
    ) -> RuntimeEffectIntent:
        committed: RuntimeEffectIntent | None = None

        def mutation(projection: Any, entries: Any) -> Any:
            nonlocal committed
            view = load_session_view(entries, session_id=session_id, run_id=run_id)
            rows, prepared = build_provider_begin_rows(
                projection,
                view,
                session_id=session_id,
                run_id=run_id,
                intent=intent,
                driver=driver,
                delivery_batch_id=delivery_batch_id,
                supersede_effect_id=supersede_effect_id,
            )
            committed = prepared
            return rows

        self.session_log.mutate(session_id, mutation)
        if committed is None:
            raise RuntimeEffectError("provider effect intent was not committed")
        return committed

    def settle_provider_effect(
        self,
        session_id: str,
        run_id: str,
        settlement: RuntimeEffectSettlement,
    ) -> RuntimeEffectSettlement:
        committed: RuntimeEffectSettlement | None = None

        def mutation(projection: Any, entries: Any) -> Any:
            nonlocal committed
            view = load_session_view(entries, session_id=session_id, run_id=run_id)
            rows, prepared = build_provider_settle_rows(
                projection,
                view,
                session_id=session_id,
                run_id=run_id,
                settlement=settlement,
            )
            committed = prepared
            return rows

        self.session_log.mutate(session_id, mutation)
        if committed is None:
            raise RuntimeEffectError("provider effect settlement was not committed")
        return committed

    def begin_tool_batch(
        self,
        session_id: str,
        run_id: str,
        *,
        intents: Iterable[RuntimeEffectIntent],
        delivery_intent: DeliveryBatchIntent,
        driver: str = "",
    ) -> ToolBatchCommit:
        committed: ToolBatchCommit | None = None

        def mutation(projection: Any, entries: Any) -> Any:
            nonlocal committed
            view = load_session_view(entries, session_id=session_id, run_id=run_id)
            rows, batch_commit = build_tool_batch_rows(
                projection,
                view,
                session_id=session_id,
                run_id=run_id,
                intents=intents,
                delivery_intent=delivery_intent,
                driver=driver,
            )
            committed = batch_commit
            return rows

        self.session_log.mutate(session_id, mutation)
        if committed is None:
            raise RuntimeEffectError("tool batch was not committed")
        return committed

    def settle_tool_effect(
        self,
        session_id: str,
        run_id: str,
        settlement: RuntimeEffectSettlement,
    ) -> RuntimeEffectSettlement:
        committed: RuntimeEffectSettlement | None = None

        def mutation(projection: Any, entries: Any) -> Any:
            nonlocal committed
            view = load_session_view(entries, session_id=session_id, run_id=run_id)
            rows, prepared = build_tool_settle_rows(
                projection,
                view,
                session_id=session_id,
                run_id=run_id,
                settlement=settlement,
            )
            committed = prepared
            return rows

        self.session_log.mutate(session_id, mutation)
        if committed is None:
            raise RuntimeEffectError("tool effect settlement was not committed")
        return committed

    def settle_effect(
        self,
        session_id: str,
        run_id: str,
        settlement: RuntimeEffectSettlement,
    ) -> RuntimeEffectSettlement:
        if settlement.effect_category == EFFECT_CATEGORY_PROVIDER_SEND:
            return self.settle_provider_effect(session_id, run_id, settlement)
        if settlement.effect_category == EFFECT_CATEGORY_TOOL_CALL:
            return self.settle_tool_effect(session_id, run_id, settlement)
        raise RuntimeEffectError(f"unsupported effect category: {settlement.effect_category}")

    def record_delivery_recovered(
        self,
        session_id: str,
        run_id: str,
        *,
        batch_id: str,
        recovered_effect_ids: Iterable[str],
        recovered_reads: int = 0,
        recovered_lookups: int = 0,
    ) -> None:
        recovered_ids = tuple(recovered_effect_ids)

        def mutation(projection: Any, entries: Any) -> Any:
            view = load_session_view(entries, session_id=session_id, run_id=run_id)
            return build_delivery_recovered_rows(
                projection,
                view,
                session_id=session_id,
                run_id=run_id,
                batch_id=batch_id,
                recovered_ids=recovered_ids,
                recovered_reads=recovered_reads,
                recovered_lookups=recovered_lookups,
            )

        self.session_log.mutate(session_id, mutation)

    def record_delivery_delivered(
        self,
        session_id: str,
        run_id: str,
        *,
        batch_id: str,
        provider_effect_id: str,
    ) -> None:
        def mutation(projection: Any, entries: Any) -> Any:
            view = load_session_view(entries, session_id=session_id, run_id=run_id)
            from codey.runtime.write.provider_effects import build_delivery_delivered_rows

            rows = build_delivery_delivered_rows(
                projection, view, session_id=session_id, run_id=run_id,
                batch_id=batch_id, provider_effect_id=provider_effect_id,
            )
            return rows

        self.session_log.mutate(session_id, mutation)


def _operation_settled_entry(state: RuntimeOperationState) -> dict[str, object]:
    return {
        "lane": state.lane,
        "operation_id": state.operation_id,
        "kind": "operation_settled",
        "payload": outcome_for_terminal(state).to_payload(),
    }


def _replace_task_policy(state: RuntimeOperationState, policy: dict[str, object]) -> RuntimeOperationState:
    if state.task_policy == policy:
        return state
    if state.task_policy:
        raise RuntimeOperationTransitionError("task authorization snapshot is immutable")
    from dataclasses import replace

    return replace(state, task_policy=dict(policy))


def _require_state(
    entries: tuple[RuntimeLogEntry, ...],
    *,
    session_id: str,
    run_id: str,
) -> RuntimeOperationState:
    state = operation_state_from_entries(
        entries,
        session_id=session_id,
        run_id=run_id,
    )
    if state is None:
        raise RuntimeOperationTransitionError("operation state is missing")
    return state


__all__ = [
    "RuntimeOperationState",
    "RuntimeMutationLine",
    "ToolBatchCommit",
]
