"""Pure provider-effect write builders.

Each builder reads one SessionView plus its arguments and returns the
bounded rows to commit. Builders never touch the session lock; the
mutation line commits their rows atomically.
"""

from __future__ import annotations

from typing import Any

from codey.runtime.core.operation_state import (
    RuntimeOperationTransitionError,
    mark_provider_effect_pending,
    mark_provider_effect_settled,
    operation_state_entry,
)
from codey.runtime.effects.effect_records import (
    EFFECT_CATEGORY_PROVIDER_SEND,
    SENT_STATE_NOT_SENT,
    SENT_STATE_SETTLED,
    SETTLEMENT_STATUS_ERROR,
    RuntimeEffectIntent,
    RuntimeEffectSettlement,
    effect_intent_entry,
    effect_settlement_entry,
    find_effect,
    prepare_intent,
    prepare_settlement,
    require_new_effect_id,
)
from codey.runtime.effects.tool_result_delivery import (
    delivered_entry,
    send_attempt_entry,
    send_superseded_entry,
)
from codey.runtime.log.session_view import (
    SessionView,
    driver_for_state,
    pending_for,
    require_open_view,
)


def _require_supersedable_not_sent(
    view: SessionView,
    supersede_effect_id: str,
) -> None:
    """Prove the voided attempt deterministically sent nothing usable.

    A matching send_attempt alone is not enough: only a provider send whose
    settlement exists with an error status and a NOT_SENT state may be voided.
    Anything else (unsettled, maybe-sent, ok) keeps the batch locked.
    """
    if not supersede_effect_id:
        raise RuntimeOperationTransitionError("supersede requires a failed provider effect id")
    try:
        matching = find_effect(view.effects, supersede_effect_id)
    except Exception as exc:
        raise RuntimeOperationTransitionError(
            f"supersede requires a known provider effect: {supersede_effect_id!r}"
        ) from exc
    if matching.intent.effect_category != EFFECT_CATEGORY_PROVIDER_SEND:
        raise RuntimeOperationTransitionError(
            f"supersede requires a provider send effect: {supersede_effect_id!r}"
        )
    settlement = matching.settlement
    if (
        settlement is None
        or settlement.status != SETTLEMENT_STATUS_ERROR
        or settlement.sent_state != SENT_STATE_NOT_SENT
    ):
        raise RuntimeOperationTransitionError(
            f"supersede requires an error/NOT_SENT settlement: {supersede_effect_id!r}"
        )


def build_provider_begin_rows(
    projection: Any,
    view: SessionView,
    *,
    session_id: str,
    run_id: str,
    intent: RuntimeEffectIntent,
    driver: str = "",
    delivery_batch_id: str = "",
    supersede_effect_id: str = "",
) -> tuple[tuple[dict[str, object], ...], RuntimeEffectIntent]:
    state = require_open_view(projection, view)
    prepared = prepare_intent(session_id, run_id, intent)
    require_new_effect_id(view.effects, prepared.effect_id)
    effect_driver = driver_for_state(state, explicit=driver)
    batches = view.batches
    rows = [effect_intent_entry(prepared)]
    if delivery_batch_id:
        if supersede_effect_id:
            _require_supersedable_not_sent(view, supersede_effect_id)
            voided = send_superseded_entry(
                session_id,
                run_id,
                batch_id=delivery_batch_id,
                provider_effect_id=supersede_effect_id,
                batches=batches,
            )
            if voided is not None:
                rows.append(voided)
            from dataclasses import replace as _replace

            batches = tuple(
                _replace(
                    batch,
                    superseded_effect_ids=(*batch.superseded_effect_ids, supersede_effect_id),
                )
                if batch.intent.batch_id == delivery_batch_id
                else batch
                for batch in batches
            )
        attempt = send_attempt_entry(
            session_id,
            run_id,
            batch_id=delivery_batch_id,
            provider_effect_id=prepared.effect_id,
            batches=batches,
        )
        if attempt is not None:
            rows.append(attempt)
    rows.append(
        operation_state_entry(
            mark_provider_effect_pending(
                state,
                driver=effect_driver,
                provider_id=prepared.provider_id,
                turn=prepared.turn,
            )
        )
    )
    return tuple(rows), prepared


def build_provider_settle_rows(
    projection: Any,
    view: SessionView,
    *,
    session_id: str,
    run_id: str,
    settlement: RuntimeEffectSettlement,
) -> tuple[tuple[dict[str, object], ...], RuntimeEffectSettlement]:
    state = require_open_view(projection, view)
    effects = view.effects
    matching = find_effect(effects, settlement.effect_id)
    prepared = prepare_settlement(session_id, run_id, settlement, effects)
    if matching.settlement is not None:
        return (), prepared
    pending = pending_for(view)
    rows = [effect_settlement_entry(prepared)]
    if (
        pending.delivery_batch_id
        and prepared.status == "ok"
        and prepared.sent_state == SENT_STATE_SETTLED
    ):
        batches = view.batches
        delivered = delivered_entry(
            session_id,
            run_id,
            batch_id=pending.delivery_batch_id,
            provider_effect_id=prepared.effect_id,
            batches=batches,
        )
        if delivered is not None:
            rows.append(delivered)
    rows.append(
        operation_state_entry(
            mark_provider_effect_settled(state)
        )
    )
    return tuple(rows), prepared


def build_delivery_delivered_rows(
    projection: Any,
    view: SessionView,
    *,
    session_id: str,
    run_id: str,
    batch_id: str,
    provider_effect_id: str,
) -> tuple[dict[str, object], ...]:
    """Record a provider ledger witness as a local delivery receipt."""
    batches = view.batches
    entry = delivered_entry(
        session_id, run_id, batch_id=batch_id,
        provider_effect_id=provider_effect_id, batches=batches,
    )
    return (entry,) if entry is not None else ()


__all__ = [
    "build_provider_begin_rows",
    "build_provider_settle_rows",
    "build_delivery_delivered_rows",
]
