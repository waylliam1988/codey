"""Atomic user-file writes.

User source code must survive a crash at least as well as Codey's own state
files do: write to a temp file in the same directory, fsync, then
``os.replace``. The original file is untouched until the replace succeeds,
and the file's existing CRLF/LF style is preserved instead of being rewritten
by platform text-mode translation.
"""

from __future__ import annotations

import contextlib
import errno
import json
import os
import stat
import time
import uuid
from collections.abc import Callable
from pathlib import Path
from typing import Any

MAX_ATOMIC_JSON_BYTES = 8 * 1024 * 1024


def encode_with_original_eol(target: Path, text: str, *, encoding: str = "utf-8") -> bytes:
    """Encode ``text`` matching the target file's recorded newline style."""

    raw = _read_existing_bytes_no_follow(target)
    if b"\r\n" in raw:
        normalized = str(text or "").replace("\r\n", "\n")
        return normalized.replace("\n", "\r\n").encode(encoding)
    return str(text or "").replace("\r\n", "\n").encode(encoding)


def write_bytes_atomic(
    path: str | Path,
    data: bytes,
    *,
    mode: int | None = None,
    preserve_mode: bool = True,
) -> None:
    """Replace ``path`` with ``data`` atomically."""

    target = Path(path)
    directory = target.parent if str(target.parent) else Path(".")
    directory.mkdir(parents=True, exist_ok=True)
    tmp = directory / f".{target.name}.{uuid.uuid4().hex}.tmp"
    initial_identity = _target_identity(target)
    existing_mode = _existing_mode(target)
    creation_mode = (
        mode if mode is not None else (existing_mode if (preserve_mode and existing_mode is not None) else 0o666)
    )
    try:
        flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
        if hasattr(os, "O_BINARY"):
            flags |= os.O_BINARY
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        fd = os.open(tmp, flags, creation_mode)
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            if mode is not None:
                _apply_mode(handle.fileno(), tmp, mode, required=True)
            elif preserve_mode and existing_mode is not None:
                _apply_mode(handle.fileno(), tmp, existing_mode, required=False)
            handle.flush()
            os.fsync(handle.fileno())
        _retry_sharing_violation(
            lambda: os.replace(tmp, target),
            unchanged=lambda: _target_identity(target) == initial_identity,
        )
        _fsync_dir(directory)
    finally:
        _cleanup_temp_file(tmp)


def _apply_mode(fileno: int, path: Path, mode: int, *, required: bool = False) -> None:
    first_error: OSError | None = None
    if hasattr(os, "fchmod"):
        try:
            os.fchmod(fileno, mode)
            return
        except OSError as exc:
            first_error = exc
    try:
        os.chmod(path, mode)
    except OSError as exc:
        if required:
            if first_error is not None:
                raise exc from first_error
            raise


def _fsync_dir(directory: Path) -> None:
    if os.name == "posix":
        try:
            flags = os.O_RDONLY
            if hasattr(os, "O_DIRECTORY"):
                flags |= os.O_DIRECTORY
            dir_fd = os.open(str(directory), flags)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except OSError as exc:
            # Only directory-fsync-not-supported is best-effort. Real IO,
            # permission, or device errors must surface so durability is
            # not silently claimed.
            if exc.errno in (
                errno.EINVAL,
                errno.ENOTSUP,
                errno.EOPNOTSUPP,
                errno.ENOSYS,
                errno.EPERM,
            ):
                return
            raise


def append_bytes_durable(path: str | Path, chunks: list[bytes] | tuple[bytes, ...]) -> None:
    """Append chunks to ``path`` and fsync before returning.

    Append-only logs (run ledger, ghost events, runtime session log) must
    survive an OS crash without losing the tail. The append never follows a
    symlink: a symlink target is rejected before and after open, and
    ``O_NOFOLLOW`` is used where the platform provides it. Callers must
    already hold their file lock; this helper only adds durability, never
    locking or rotation."""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_symlink():
        raise OSError(errno.ELOOP, f"refusing to append through symlink: {target}")
    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND
    if hasattr(os, "O_BINARY"):
        flags |= os.O_BINARY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(target, flags, 0o666)
    try:
        try:
            st = os.fstat(fd)
        except OSError:
            raise
        if not stat.S_ISREG(st.st_mode):
            raise OSError(errno.ELOOP, f"refusing to append to non-regular file: {target}")
        with os.fdopen(fd, "ab") as handle:
            fd = -1
            for chunk in chunks:
                if chunk:
                    handle.write(chunk)
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        if fd >= 0:
            with contextlib.suppress(OSError):
                os.close(fd)


def write_text_atomic(
    path: str | Path,
    text: str,
    *,
    encoding: str = "utf-8",
    mode: int | None = None,
    preserve_mode: bool = True,
) -> None:
    """Replace ``path`` with ``text`` atomically, preserving EOL style."""

    target = Path(path)
    data = encode_with_original_eol(target, text, encoding=encoding)
    write_bytes_atomic(target, data, mode=mode, preserve_mode=preserve_mode)


def write_json_atomic(
    path: str | Path,
    value: dict[str, Any],
    *,
    mode: int | None = None,
    preserve_mode: bool = True,
    max_bytes: int = MAX_ATOMIC_JSON_BYTES,
) -> None:
    """Replace ``path`` with JSON-serialized ``value`` atomically."""

    data = json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    if len(data) > max_bytes:
        raise ValueError("local state is too large")
    write_bytes_atomic(path, data, mode=mode, preserve_mode=preserve_mode)


def _existing_mode(target: Path) -> int | None:
    try:
        info = target.lstat()
    except (OSError, ValueError):
        return None
    if stat.S_ISLNK(info.st_mode):
        return None
    return stat.S_IMODE(info.st_mode)


_EOL_SCAN_BYTES = 256 * 1024
_EOL_SCAN_CHUNK = 64 * 1024


def _read_existing_bytes_no_follow(target: Path) -> bytes:
    """Read a bounded prefix to detect CRLF; never buffers whole files."""
    try:
        if target.is_symlink():
            return b""
        flags = os.O_RDONLY
        if hasattr(os, "O_BINARY"):
            flags |= os.O_BINARY
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        fd = os.open(target, flags)
    except (OSError, ValueError):
        return b""
    try:
        with os.fdopen(fd, "rb") as handle:
            chunks: list[bytes] = []
            remaining = _EOL_SCAN_BYTES
            carry = b""
            while remaining > 0:
                data = handle.read(min(_EOL_SCAN_CHUNK, remaining))
                if not data:
                    break
                remaining -= len(data)
                window = carry + data
                if b"\r\n" in window:
                    return b"\r\n"
                chunks.append(data)
                carry = data[-1:] if data.endswith(b"\r") else b""
            return b"".join(chunks)
    except OSError:
        return b""


def _target_identity(path: Path) -> tuple[int, int, int, int, int] | None:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_mode


def _retry_sharing_violation(action: Callable[[], None], *, unchanged: Callable[[], bool] | None = None) -> None:
    """Retry only WinError 32, keeping the same temp and original target."""
    for attempt in range(8):
        try:
            action()
            return
        except OSError as exc:
            if getattr(exc, "winerror", None) != 32 or attempt == 7:
                raise
            time.sleep(0.01 * (attempt + 1))
            if unchanged is not None and not unchanged():
                raise OSError(errno.EBUSY, "target changed during atomic replacement") from exc


def _cleanup_temp_file(path: Path) -> None:
    try:
        _retry_sharing_violation(lambda: path.unlink(missing_ok=True))
    except PermissionError as exc:
        if getattr(exc, "winerror", None) == 32:
            return
        try:
            mode = stat.S_IMODE(path.stat().st_mode)
            os.chmod(path, mode | stat.S_IWRITE | stat.S_IWUSR)
            _retry_sharing_violation(lambda: path.unlink(missing_ok=True))
        except OSError:
            pass
    except OSError:
        pass


__all__ = [
    "append_bytes_durable",
    "encode_with_original_eol",
    "write_bytes_atomic",
    "write_json_atomic",
    "write_text_atomic",
]
