"""Durable UI session state for the native Codey shell."""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any

from codey.storage.local_store import (
    DEFAULT_STATE_HOME,
    StoreCorruption,
    backup_corrupt_file,
    read_json_strict,
    write_json_atomic,
)
from codey.utils.refs import coerce_float

SCHEMA_VERSION = 1
MAX_UI_STATE_BYTES = 16 * 1024 * 1024
MAX_SESSIONS = 200
MAX_PROJECTS = 100
MAX_MESSAGES_PER_SESSION = 500
MAX_FILES_PER_MESSAGE = 20
MAX_STRING = 200_000
MAX_VISIBLE_EXCERPT_CHARS = 12_000
MAX_VISIBLE_EXCERPT_MESSAGES = 20
MAX_EXCERPT_TEXT_CHARS = 1_500
MAX_SHORT_STRING = 1_000
MAX_TITLE = 160
MESSAGE_KEYS = {
    "type",
    "text",
    "note",
    "n",
    "kind",
    "path",
    "result",
    "error",
    "sessionId",
    "id",
    "command",
    "commandSha256",
    "commandChars",
    "commandTruncated",
    "cwd",
    "output",
    "exitCode",
    "approved",
    "shellStatus",
    "count",
    "files",
    "project",
    "eventKey",
    "runId",
    "changed",
    "riskLabel",
    "riskTitle",
    "riskDetail",
    # Pending tool-approval and activity fields the UI round-trips; dropping
    # them silently broke restore of in-flight cards and spinners.
    "toolKey",
    "activity",
    "pending",
    "reasoning",
    "toolName",
    "turn",
    "state",
    "status",
    "requestId",
    "attempts",
    "sendFailure",
    "runOwner",
}


def _empty_state() -> dict[str, Any]:
    return {
        "active_id": "",
        "sessions": [],
        "projects": [],
        "updated_at": 0,
        "revision": 0,
    }


def _int(value: object) -> int:
    if isinstance(value, bool):
        return 0
    try:
        number = coerce_float(value or 0)
    except (TypeError, ValueError, OverflowError):
        return 0
    if not math.isfinite(number):
        return 0
    try:
        return max(0, int(number))
    except (TypeError, ValueError, OverflowError):
        return 0


def _str(value: object, limit: int = MAX_SHORT_STRING) -> str:
    return str(value or "")[:limit]


def _clean_files(value: object) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    files: list[dict[str, Any]] = []
    for item in value[:MAX_FILES_PER_MESSAGE]:
        if not isinstance(item, dict):
            continue
        files.append(
            {
                "path": _str(item.get("path")),
                "status": _str(item.get("status"), 20),
                "additions": _int(item.get("additions")),
                "deletions": _int(item.get("deletions")),
            }
        )
    return files


def _clean_message(message: object) -> dict[str, Any] | None:
    if not isinstance(message, dict):
        return None
    clean: dict[str, Any] = {}
    for key in MESSAGE_KEYS:
        if key not in message:
            continue
        value = message[key]
        if key == "attempts":
            if isinstance(value, list):
                clean[key] = [
                    {name: _str(item[name], 12_000 if name == "error" else MAX_SHORT_STRING)
                     for name in ("runId", "state", "error", "sendFailure", "runOwner", "warning")
                     if name in item}
                    for item in value[-64:] if isinstance(item, dict)
                ]
        elif key == "files":
            clean[key] = _clean_files(value)
        elif key == "exitCode":
            # Signals have negative exits on POSIX; malformed values are unknown,
            # never coerced to a successful zero exit.
            clean[key] = value if type(value) is int else None
        elif isinstance(value, bool):
            clean[key] = value
        elif isinstance(value, (int, float)) and not isinstance(value, bool):
            clean[key] = _int(value)
        elif value is None:
            clean[key] = None
        elif key == "reasoning":
            if isinstance(value, str):
                clean[key] = value[:64_000]
        elif key in {"text", "output", "result", "command"}:
            clean[key] = _str(value, MAX_STRING)
        else:
            clean[key] = _str(value)
    return clean if clean else None


def _clean_messages(value: object) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    messages: list[dict[str, Any]] = []
    for message in value[-MAX_MESSAGES_PER_SESSION:]:
        clean = _clean_message(message)
        if clean is not None:
            messages.append(clean)
    return messages


MAX_RESEARCH_RUNS_PER_SESSION = 32
MAX_RESEARCH_LIST_ITEMS = 64
MAX_RESEARCH_OBJECT_KEYS = 24
MAX_RESEARCH_DEPTH = 2
RESEARCH_RUN_TEXT_FIELDS = ("runId", "synthesisId", "receipt")
RESEARCH_RUN_LIST_TEXT_FIELDS = (
    "notesCreated",
    "notesUpdated",
    "sourceUrls",
    "queries",
    "counterpoints",
    "qualityWarnings",
)
RESEARCH_RUN_LIST_OBJECT_FIELDS = (
    "searchResults",
    "openedSources",
    "citationMap",
    "evidenceItems",
)


def _clean_research_json(value: object, *, depth: int = MAX_RESEARCH_DEPTH) -> Any:
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return _int(value)
    if isinstance(value, str):
        return _str(value, MAX_STRING)
    if depth <= 0:
        return _str(value, MAX_SHORT_STRING)
    if isinstance(value, list):
        return [
            _clean_research_json(item, depth=depth - 1)
            for item in value[:MAX_RESEARCH_LIST_ITEMS]
        ]
    if isinstance(value, dict):
        clean: dict[str, Any] = {}
        for key, item in list(value.items())[:MAX_RESEARCH_OBJECT_KEYS]:
            token = _str(key, MAX_SHORT_STRING)
            if token:
                clean[token] = _clean_research_json(item, depth=depth - 1)
        return clean
    return _str(value, MAX_SHORT_STRING)


def _clean_research_run(value: object) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    run: dict[str, Any] = {}
    for key in RESEARCH_RUN_TEXT_FIELDS:
        run[key] = _str(value.get(key), MAX_STRING if key == "receipt" else MAX_SHORT_STRING)
    for key in RESEARCH_RUN_LIST_TEXT_FIELDS:
        raw = value.get(key)
        run[key] = [
            _str(item, MAX_STRING if key == "sourceUrls" else MAX_SHORT_STRING)
            for item in (raw if isinstance(raw, list) else [])[:MAX_RESEARCH_LIST_ITEMS]
        ]
    for key in RESEARCH_RUN_LIST_OBJECT_FIELDS:
        raw = value.get(key)
        run[key] = [
            _clean_research_json(item, depth=MAX_RESEARCH_DEPTH)
            for item in (raw if isinstance(raw, list) else [])[:MAX_RESEARCH_LIST_ITEMS]
        ]
    run["sourcesRead"] = _int(value.get("sourcesRead"))
    run["coverage"] = (
        _clean_research_json(value.get("coverage"), depth=MAX_RESEARCH_DEPTH)
        if isinstance(value.get("coverage"), dict)
        else dict[str, object]()
    )
    run["restoreable"] = False
    run["createdAt"] = _int(value.get("createdAt"))
    return run


def _clean_research_runs(value: object) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    rows: list[dict[str, Any]] = []
    for item in value[-MAX_RESEARCH_RUNS_PER_SESSION:]:
        clean = _clean_research_run(item)
        if clean is not None:
            rows.append(clean)
    return rows


def _clean_research(value: object) -> bool:
    return bool(value)


def _clean_draft(value: object) -> dict[str, Any]:
    draft = value if isinstance(value, dict) else {}
    text = draft.get("text", "")
    if not isinstance(text, str):
        text = ""
    # textarea offsets count UTF-16 code units, including astral characters.
    length = len(text.encode("utf-16-le", errors="surrogatepass")) // 2
    start = min(length, _int(draft.get("start")))
    end = max(start, min(length, _int(draft.get("end"))))
    direction = draft.get("direction")
    return {"text": text, "start": start, "end": end,
            "direction": direction if direction in ("none", "forward", "backward") else "none",
            "revision": min(2**53 - 1, _int(draft.get("revision")))}


def _clean_sessions(value: object) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    sessions: list[dict[str, Any]] = []
    for item in value[:MAX_SESSIONS]:
        if not isinstance(item, dict):
            continue
        terminal_runs = item.get("terminalRuns")
        if not isinstance(terminal_runs, list):
            terminal_runs = list[dict[str, Any]]()
        entry: dict[str, Any] = {
            "draft": _clean_draft(item.get("draft")),
            "id": _str(item.get("id")),
            "title": _str(item.get("title") or "New chat", MAX_TITLE),
            "messages": _clean_messages(item.get("messages")),
            "terminalRuns": [
                _str(run_id) for run_id in terminal_runs[-32:]
            ],
            "createdAt": _int(item.get("createdAt")),
            "projectId": _str(item.get("projectId")) or None,
            "provider": _str(item.get("provider"), 40),
        }
        # Canonical session shape always carries research fields (frontend
        # defaultSession/normalizeSessions always emit researchRuns/research).
        # Always emitting []/False keeps backend/frontend byte-shape stable
        # and avoids spurious revision bumps from _content_equal.
        entry["researchRuns"] = _clean_research_runs(item.get("researchRuns"))
        entry["research"] = _clean_research(item.get("research"))
        if item.get("titleRenamed") is True:
            entry["titleRenamed"] = True
        selection = item.get("modelSelection")
        if isinstance(selection, dict):
            allowed = {"off", "minimal", "low", "medium", "high", "xhigh", "max"}
            effort = selection.get("effort")
            if not isinstance(effort, str) or effort not in allowed:
                effort = "off" if selection.get("thinking") is False else "high" if selection.get("thinking") is True else None
            history = selection.get("efforts")
            efforts = {str(key)[:1000]: value for key, value in list(history.items())[:50] if isinstance(value, str) and value in allowed} if isinstance(history, dict) else dict[str, str]()
            entry["modelSelection"] = {
                "connection_id": _str(selection.get("connection_id"), 40),
                "base_url": _str(selection.get("base_url")),
                "model": _str(selection.get("model")),
                **({"name": _str(selection["name"], 160)} if isinstance(selection.get("name"), str) else {}),
                "effort": effort,
                **({"thinking": selection["thinking"]} if type(selection.get("thinking")) is bool else {}),
                "efforts": efforts,
            }
        sessions.append(entry)
    return sessions


def _clean_projects(value: object) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    projects: list[dict[str, Any]] = []
    for item in value[:MAX_PROJECTS]:
        if not isinstance(item, dict):
            continue
        path = _str(item.get("path"))
        if not path:
            continue
        projects.append(
            {
                "id": _str(item.get("id")),
                "name": _str(item.get("name"), MAX_TITLE),
                "path": path,
                "expanded": item.get("expanded") is not False,
                "createdAt": _int(item.get("createdAt")),
            }
        )
    return projects


def _clean_payload(payload: object) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return _empty_state()
    return {
        "active_id": _str(payload.get("active_id")),
        "sessions": _clean_sessions(payload.get("sessions")),
        "projects": _clean_projects(payload.get("projects")),
        "updated_at": _int(payload.get("updated_at")),
        "revision": _int(payload.get("revision")),
    }


def _message_excerpt(message: dict[str, Any]) -> str:
    kind = str(message.get("type") or "")
    if kind == "user":
        label = "User"
        text = str(message.get("text") or "")
    elif kind == "asst":
        label = "Assistant"
        text = str(message.get("text") or "")
    elif kind == "review":
        label = "Review"
        text = str(message.get("text") or "")
    elif kind == "done":
        label = "Done"
        text = str(message.get("text") or "")
    elif kind == "changes":
        count = _int(message.get("count"))
        files = message.get("files")
        paths = list[str]()
        if isinstance(files, list):
            paths = [
                str(item.get("path") or "")
                for item in files
                if isinstance(item, dict) and item.get("path")
            ][:3]
        suffix = f": {', '.join(paths)}" if paths else ""
        return f"Changes: {count} file{'s' if count != 1 else ''}{suffix}"
    else:
        return ""
    text = _str(text, MAX_EXCERPT_TEXT_CHARS).strip()
    return f"{label}: {text}" if text else ""


class UiStateConflict(ValueError):
    """Client base revision no longer matches the durable revision."""

    def __init__(self, current_revision: int, message: str = "ui_state_conflict") -> None:
        super().__init__(message)
        self.current_revision = int(current_revision or 0)


def _content_equal(first: dict[str, Any], second: dict[str, Any]) -> bool:
    return (
        first.get("active_id") == second.get("active_id")
        and first.get("sessions") == second.get("sessions")
        and first.get("projects") == second.get("projects")
    )


class UiStateStore:
    """Persist the current visible UI state as one bounded local snapshot.

    Single-writer protocol: one Codey server owns ``state_home`` (enforced
    by a server instance lease in ``server.serve``). Within that server,
    every save carries the client's last confirmed ``base_revision`` and
    runs under ``AppContext.ui_state_store_lock``. A mismatched base with
    identical content succeeds idempotently; a mismatched base with
    different content raises :class:`UiStateConflict` and never writes.
    The server always mints the next revision.
    """

    def __init__(self, state_home: str | Path = DEFAULT_STATE_HOME) -> None:
        self.path = Path(state_home) / "ui-state.json"
        self._cached_state: dict[str, Any] | None = None

    def load(self) -> dict[str, Any]:
        try:
            payload = read_json_strict(self.path, max_bytes=MAX_UI_STATE_BYTES)
        except StoreCorruption:
            backup_corrupt_file(self.path)
            payload = None
        if not payload or type(payload.get("schema_version")) is not int or payload.get("schema_version") != SCHEMA_VERSION:
            state = _empty_state()
        else:
            state = _clean_payload(payload.get("state"))
        self._cached_state = state
        return state

    def _current(self) -> dict[str, Any]:
        if self._cached_state is not None:
            return self._cached_state
        return self.load()

    def save(self, state: object, *, base_revision: int) -> dict[str, Any]:
        clean = _clean_payload(state)
        current = self._current()
        current_revision = _int(current.get("revision"))
        if type(base_revision) is not int or base_revision != current_revision:
            if _content_equal(clean, current):
                return current
            raise UiStateConflict(current_revision)
        if _content_equal(clean, current):
            return current
        clean["updated_at"] = max(_int(clean.get("updated_at")), _int(current.get("updated_at")))
        clean["revision"] = current_revision + 1
        write_json_atomic(
            self.path,
            {
                "schema_version": SCHEMA_VERSION,
                "state": clean,
            },
            max_bytes=MAX_UI_STATE_BYTES,
        )
        # Only a successful write becomes the new comparison baseline; a
        # failed write leaves the cache pointing at the last durable state.
        self._cached_state = clean
        return clean

    def visible_session_excerpt(
        self,
        session_id: str,
        *,
        current_request: str = "",
        limit: int = MAX_VISIBLE_EXCERPT_CHARS,
    ) -> str:
        target = str(session_id or "")
        if not target:
            return ""
        current = str(current_request or "").strip()
        for session in self._current().get("sessions", []):
            if not isinstance(session, dict) or str(session.get("id") or "") != target:
                continue
            messages = session.get("messages")
            if not isinstance(messages, list):
                return ""
            lines: list[str] = []
            title = str(session.get("title") or "").strip()
            if title and title != "New chat":
                lines.append(_str(f"Title: {title}", MAX_EXCERPT_TEXT_CHARS))
            visible_lines: list[str] = []
            for message in reversed(messages):
                if not isinstance(message, dict):
                    continue
                if (
                    current
                    and message.get("type") == "user"
                    and str(message.get("text") or "").strip() == current
                ):
                    continue
                line = _message_excerpt(message)
                if line:
                    visible_lines.append(line)
                    if len(visible_lines) >= MAX_VISIBLE_EXCERPT_MESSAGES:
                        break
            lines.extend(reversed(visible_lines))
            excerpt = "\n".join(lines).strip()
            return _str(excerpt, max(0, limit))
        return ""
