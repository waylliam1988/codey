"""Shared clipboard transaction for web chat response copy actions."""

from __future__ import annotations

import contextlib
import uuid
from time import monotonic

from playwright.sync_api import Locator, Page

from codey.runtime.core import cancellation


def copy_action_text(
    page: Page,
    action: Locator,
    *,
    origin: str,
    timeout: float = 2.0,
) -> str:
    """Click a provider copy action and restore the user's clipboard."""
    page.context.grant_permissions(
        ["clipboard-read", "clipboard-write"],
        origin=origin,
    )
    try:
        previous = page.evaluate("navigator.clipboard.readText()")
    except Exception:
        previous = None

    sentinel = f"__CLIPBOARD_CHECK_{uuid.uuid4().hex}__"
    try:
        page.evaluate("(text) => navigator.clipboard.writeText(text)", sentinel)
    except Exception:
        return ""

    copied: str = ""
    try:
        cancellation.check()
        action.click()
        deadline = monotonic() + max(0.0, timeout)
        while monotonic() < deadline:
            copied = page.evaluate("navigator.clipboard.readText()") or ""
            if copied != sentinel:
                break
            cancellation.wait(0.1)
    finally:
        restore = previous if previous is not None else ""
        with contextlib.suppress(Exception):
            page.evaluate("(text) => navigator.clipboard.writeText(text)", restore)

    if not copied or copied == sentinel:
        return ""
    return copied.replace("\r\n", "\n").replace("\r", "\n").strip()
