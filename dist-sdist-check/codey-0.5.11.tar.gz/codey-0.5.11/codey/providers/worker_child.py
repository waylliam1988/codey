"""Child process entry point for isolated Provider adapter overrides."""

from __future__ import annotations

import argparse
import contextlib
import json
import sys
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from codey.automation.browser import DEFAULT_PROFILE
from codey.providers.registry import PROVIDER_TYPES


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--provider", required=True)
    parser.add_argument("--port", type=int, required=True)
    # Required and fail-closed: the override worker must never attach to the
    # user's default browser profile from a second CDP port.
    parser.add_argument("--profile", required=True)
    args = parser.parse_args(argv)

    profile_text = args.profile.strip()
    if not profile_text:
        parser.error("--profile must be a non-empty path")
    try:
        profile = Path(profile_text).expanduser().resolve()
    except (OSError, RuntimeError, ValueError):
        parser.error(f"--profile is not a usable path: {args.profile!r}")
    if profile == DEFAULT_PROFILE.resolve():
        parser.error("refusing the user's default browser profile")

    provider_type = PROVIDER_TYPES.get(args.provider)
    if provider_type is None:
        return 2
    try:
        with _adapter_logs_to_stderr():
            provider = provider_type.connect(
                port=args.port,
                profile=profile,
                open_if_missing=True,
                bring_to_front=False,
                isolated=False,
                fresh_tab=True,
            )
    except Exception as exc:
        # Stdout stays a strict page-plus-replies protocol: startup
        # failures go to stderr with a non-zero exit, and the parent
        # attaches the bounded stderr tail to its exit failure.
        print(
            f"provider worker startup failed: {type(exc).__name__}: {exc}",
            file=sys.stderr,
            flush=True,
        )
        return 2
    with _adapter_logs_to_stderr():
        target_id = _target_id(provider)
    _event("page", port=getattr(provider.session, "cdp_port", 0), target_id=target_id)
    try:
        for line in sys.stdin:
            try:
                request = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(request, dict):
                continue
            request_id = str(request.get("id") or "")
            method = str(request.get("method") or "")
            params = request.get("params")
            params = params if isinstance(params, dict) else {}
            try:
                if method == "new_chat":
                    with _adapter_logs_to_stderr():
                        provider.new_chat(timeout=params.get("timeout"))
                    _reply(request_id, True, None)
                elif method == "send":
                    with _adapter_logs_to_stderr():
                        result = provider.send(
                            str(params.get("text") or ""),
                            timeout=params.get("timeout"),
                        )
                    _reply(request_id, True, result)
                elif method == "close":
                    with _adapter_logs_to_stderr():
                        provider.close()
                    _reply(request_id, True, None)
                    return 0
                elif method == "health":
                    _reply(request_id, True, {"provider": args.provider})
                else:
                    _reply(request_id, False, error=f"unsupported method: {method}")
            except Exception as exc:
                failure = getattr(exc, "failure", None)
                to_dict = getattr(failure, "to_dict", None)
                payload = to_dict() if callable(to_dict) else None
                _reply(request_id, False, error=str(exc), failure=payload)
    finally:
        with _adapter_logs_to_stderr(), contextlib.suppress(Exception):
            provider.close()
    return 0


@contextlib.contextmanager
def _adapter_logs_to_stderr() -> Iterator[None]:
    """Keep stdout a strict JSONL protocol: adapter prints go to stderr.

    The parent reader condemns any non-JSON frame, so ordinary adapter
    logging must never reach stdout. Python-level prints are redirected;
    the protocol frames below always emit outside this guard.
    """
    old = sys.stdout
    sys.stdout = sys.stderr
    try:
        yield
    finally:
        sys.stdout = old


def _target_id(provider: Any) -> str:
    session = None
    try:
        session = provider.session.page.context.new_cdp_session(provider.session.page)
        info = session.send("Target.getTargetInfo")
        target = info.get("targetInfo") if isinstance(info, dict) else None
        return str(target.get("targetId") or "") if isinstance(target, dict) else ""
    except Exception:
        return ""
    finally:
        # The CDP session is a browser-side resource; a one-shot query must
        # not leak it for the lifetime of the page.
        detach = getattr(session, "detach", None)
        if callable(detach):
            with contextlib.suppress(Exception):
                detach()


def _event(name: str, **payload: Any) -> None:
    data = {"event": name}
    data.update(payload)
    print(json.dumps(data, ensure_ascii=False, separators=(",", ":")), flush=True)


def _reply(
    request_id: str,
    ok: bool,
    result: Any = None,
    *,
    error: str = "",
    failure: dict[str, Any] | None = None,
) -> None:
    payload: dict[str, Any] = {"id": request_id, "ok": ok}
    if ok:
        payload["result"] = result
    else:
        payload["error"] = error
        if failure:
            payload["failure"] = failure
    print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), flush=True)


if __name__ == "__main__":
    raise SystemExit(main())
