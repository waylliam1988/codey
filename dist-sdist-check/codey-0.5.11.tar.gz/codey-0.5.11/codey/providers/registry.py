from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from codey.automation.browser import (
    DEFAULT_PORT,
    DEFAULT_PROFILE,
    PROVIDER_URL_CONTAINS,
    detect_open_provider_tabs,
)
from codey.automation.browser import (
    warm_provider_tabs as browser_warm_provider_tabs,
)
from codey.providers.base import ChatProvider
from codey.providers.catalog import (  # noqa: F401 -- re-exported static catalog
    API_CONNECTIONS,
    DEFAULT_PROVIDER_ID,
    PROVIDER_LABELS,
    PROVIDER_WORKER_PORT_OFFSETS,
    WEB_PROVIDER_LABELS,
    WORKER_CHILD_ENV,
    provider_ids,
)

__all__ = [
    "DEFAULT_PROVIDER_ID",
    "PROVIDER_LABELS",
    "PROVIDER_TYPES",
    "PROVIDER_WORKER_PORT_OFFSETS",
    "WEB_PROVIDER_LABELS",
    "WORKER_CHILD_ENV",
    "borrow_open_provider",
    "connect_existing_provider",
    "connect_fresh_provider_tab",
    "connect_provider",
    "provider_ids",
    "provider_tab_availability",
    "warm_provider_tabs",
]
from codey.providers.ids import normalize_provider_id
from codey.providers.local_config import local_endpoint_available
from codey.providers.web_provider import (
    DeepSeekWebProvider,
    GlmWebProvider,
    MimoWebProvider,
    QwenWebProvider,
    StepFunWebProvider,
)
from codey.providers.worker import WorkerChatProvider
from codey.repairs.adapter_overrides import load_enabled_override

PROVIDER_TYPES: dict[str, Any] = {
    "deepseek": DeepSeekWebProvider,
    "mimo": MimoWebProvider,
    "stepfun": StepFunWebProvider,
    "qwen": QwenWebProvider,
    "glm": GlmWebProvider,
}


@dataclass
class _BorrowedSession:
    page: Any

    def close(self) -> None:
        """The owning provider connection keeps this Playwright context alive."""


def provider_tab_availability(*, allowed: set[str] | None = None) -> dict[str, bool]:
    enabled = set(PROVIDER_LABELS) if allowed is None else allowed
    statuses = detect_open_provider_tabs() if enabled.intersection(WEB_PROVIDER_LABELS) else dict[str, bool]()
    payload = {provider_id: provider_id in enabled and bool(statuses.get(provider_id)) for provider_id in WEB_PROVIDER_LABELS}
    payload["local"] = "local" in enabled and local_endpoint_available()
    return payload


def warm_provider_tabs(
    *,
    port: int = DEFAULT_PORT,
    profile: Path = DEFAULT_PROFILE,
) -> dict[str, bool]:
    statuses = browser_warm_provider_tabs(port=port, profile=profile)
    payload = {provider_id: bool(statuses.get(provider_id)) for provider_id in WEB_PROVIDER_LABELS}
    payload["local"] = local_endpoint_available()
    return payload


def connect_provider(
    provider_id: str,
    *,
    port: int = DEFAULT_PORT,
    profile: Path = DEFAULT_PROFILE,
    open_if_missing: bool = True,
    bring_to_front: bool = True,
) -> ChatProvider:
    normalized = normalize_provider_id(provider_id)
    if not normalized:
        if provider_id is None or str(provider_id).strip() == "":
            normalized = DEFAULT_PROVIDER_ID
        else:
            raise ValueError(f"unsupported provider: {provider_id}")
    if normalized in API_CONNECTIONS:
        from codey.providers.api_connections import capture_selection, open_selection

        return open_selection(capture_selection(normalized))
    provider_type = PROVIDER_TYPES.get(normalized)
    if provider_type is None:
        raise ValueError(f"unsupported provider: {provider_id}")
    if open_if_missing and os.environ.get(WORKER_CHILD_ENV) != "1":
        override = load_enabled_override(normalized)
        if override is not None:
            return WorkerChatProvider(
                normalized,
                override,
                port=port + PROVIDER_WORKER_PORT_OFFSETS.get(normalized, 100),
            )
    return cast(ChatProvider, provider_type.connect(
        port=port,
        profile=profile,
        open_if_missing=open_if_missing,
        bring_to_front=bring_to_front,
    ))


def borrow_open_provider(provider_id: str, owner_page: Any) -> ChatProvider | None:
    """Wrap an already-open sibling tab without creating another CDP connection."""
    from codey.automation.browser import _url_host_matches

    normalized = normalize_provider_id(provider_id)
    if normalized in API_CONNECTIONS:
        return None
    marker = PROVIDER_URL_CONTAINS.get(normalized)
    if not marker:
        return None
    try:
        pages = tuple(owner_page.context.pages)
    except Exception:
        return None
    def _matches(candidate: Any) -> bool:
        if candidate is owner_page:
            return False
        try:
            url = str(candidate.url or "")
        except Exception:
            return False
        return _url_host_matches(url, marker)
    page = next(
        (candidate for candidate in pages if _matches(candidate)),
        None,
    )
    if page is None:
        return None
    session = _BorrowedSession(page)
    if normalized in API_CONNECTIONS:
        from codey.providers.api_connections import capture_selection, open_selection

        return open_selection(capture_selection(normalized))
    provider_type = PROVIDER_TYPES.get(normalized)
    return provider_type(session) if provider_type is not None else None


def connect_existing_provider(provider_id: str) -> ChatProvider:
    """Attach to an already-open provider tab without opening a new one."""
    return connect_provider(
        provider_id,
        open_if_missing=False,
        bring_to_front=False,
    )


def connect_fresh_provider_tab(
    provider_id: str,
    *,
    port: int = DEFAULT_PORT,
    profile: Path = DEFAULT_PROFILE,
) -> ChatProvider:
    """Open a temporary provider tab for isolated review-style work."""

    normalized = normalize_provider_id(provider_id)
    if not normalized:
        if provider_id is None or str(provider_id).strip() == "":
            normalized = DEFAULT_PROVIDER_ID
        else:
            raise ValueError(f"unsupported provider: {provider_id}")
    if normalized in API_CONNECTIONS:
        from codey.providers.api_connections import capture_selection, open_selection

        return open_selection(capture_selection(normalized))
    provider_type = PROVIDER_TYPES.get(normalized)
    if provider_type is None:
        raise ValueError(f"unsupported provider: {provider_id}")
    if os.environ.get(WORKER_CHILD_ENV) != "1":
        override = load_enabled_override(normalized)
        if override is not None:
            return WorkerChatProvider(
                normalized,
                override,
                port=port + PROVIDER_WORKER_PORT_OFFSETS.get(normalized, 100),
            )
    return cast(ChatProvider, provider_type.connect(
        port=port,
        profile=profile,
        open_if_missing=True,
        bring_to_front=False,
        fresh_tab=True,
    ))
