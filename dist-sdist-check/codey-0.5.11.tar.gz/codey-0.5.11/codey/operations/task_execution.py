"""Production tool execution for the unified kernel (operations layer).

Project tools reuse the coding guards and readers (path safety, command
policy, shell approval surface); Research tools reuse ResearchTools, the
source gateway, and the evidence ledger. Completion facts come only from
successful tool results and ledger
state, never from substring matching or model-supplied parameters.
"""

from __future__ import annotations

import contextlib
from pathlib import Path
from typing import TYPE_CHECKING, Any

from codey.research.ledger import ResearchLedger
from codey.research.ledger_receipts import ledger_observation
from codey.runtime.core.models import ToolCall, ToolResult

if TYPE_CHECKING:
    from codey.agents.tools import AgentToolFns
    from codey.research.tools import ResearchTools


def close_research_tools(tools: Any) -> None:
    """Release an owned search session without masking the task outcome."""
    close = getattr(getattr(tools, "search", None), "close", None)
    if callable(close):
        with contextlib.suppress(Exception):
            close()


def build_research_tools(deps: Any, *, session_id: str, project: str) -> ResearchTools:
    """Build the execution resources; configuration errors propagate to entry."""
    from codey.knowledge.changes import KnowledgeChanges
    from codey.research.tools import ResearchTools

    knowledge_store = getattr(deps, "knowledge_store", None)
    search_factory = getattr(deps, "search_factory", None)
    if search_factory is None:
        from codey.research.search_factory import default_research_search_provider

        search_factory = default_research_search_provider
    search = search_factory()
    try:
        return ResearchTools(
            search=search, store=knowledge_store,
            changes=KnowledgeChanges(root=knowledge_store.root) if knowledge_store is not None else None,
            diagnostics=None, session_id=session_id, project=project,
        )
    except BaseException:
        close = getattr(search, "close", None)
        if callable(close):
            with contextlib.suppress(Exception):
                close()
        raise


def effective_project_profile(permission_profile: object) -> str:
    """Project-guard profile shared by execution and shell approval.

    The Research profile controls research context and source tools. A
    project tool still needs the coding path/command guard; TaskPolicy
    has already authorized the individual project capability. Approval
    must evaluate with exactly this profile, never a hardcoded duplicate.
    """
    return "coding_writer" if str(permission_profile or "") == "research" else str(
        permission_profile or "coding_writer")


def _tool_result(call: ToolCall, outcome: Any) -> ToolResult:
    audit = dict(getattr(outcome, "audit", {}) or {})
    # Tool implementations cannot classify a request as a runtime guard refusal.
    audit.pop("execution_disposition", None)
    if call.name == "edit":
        changed = getattr(outcome, "changed", False)
        audit["changed"] = changed if type(changed) is bool else False
    return ToolResult(
        ok=outcome.ok is True, call=call, model_text=str(outcome.model_text or ""),
        truncated=bool(getattr(outcome, "truncated", False)),
        presentation=dict(getattr(outcome, "presentation", {}) or {}),
        audit=audit,
        canonical=dict(getattr(outcome, "canonical", {}) or {}),
    )


class ExecutionDelegate:
    """Real guards + real tools behind the kernel's policy snapshot."""

    def __init__(
        self,
        *,
        session: Any = None,
        project_path: Any = None,
        tool_fns: AgentToolFns | None = None,
        research_tools: Any = None,
        permission_profile: str = "coding_writer",
        approval_available: bool = False,
        change_tracker: Any = None,
        managed_outputs: Any = None,
        session_id: str = "",
        run_id: str = "",
        frozen_specs: dict[str, Any] | None = None,
        custom_executors: dict[str, Any] | None = None,
    ) -> None:
        self.session = session
        self.project_path: Path | None = Path(str(project_path)).expanduser() if project_path else None
        if self.project_path is not None and not self.project_path.is_dir():
            self.project_path = None
        self.tool_fns: AgentToolFns | None = tool_fns
        self.research_tools = research_tools
        self.permission_profile = str(permission_profile or "coding_writer")
        self.approval_available = bool(approval_available)
        self.change_tracker = change_tracker
        self.managed_outputs = managed_outputs
        self.session_id = session_id
        self.run_id = run_id
        # 本轮冻结绑定：非 None 时解析/执行不再查询实时注册表。
        self._frozen_specs = frozen_specs
        self._custom_executors = custom_executors
        if self.tool_fns is None and self.project_path is not None:
            try:
                from codey.agents.tools import DEFAULT_TOOL_FNS
                self.tool_fns = DEFAULT_TOOL_FNS
            except Exception:
                pass

    def _resolve_spec(self, name: str) -> Any:
        lowered = str(name or "").strip().lower()
        if self._frozen_specs is not None:
            return self._frozen_specs.get(lowered)
        try:
            from codey.toolchain.tool_spec import spec_for_tool
        except Exception:
            return None
        try:
            return spec_for_tool(lowered)
        except Exception:
            return None

    def _resolve_custom_executor(self, name: str) -> Any:
        lowered = str(name or "").strip().lower()
        if self._custom_executors is not None:
            return self._custom_executors.get(lowered)
        try:
            from codey.toolchain.tool_spec import custom_executor_for
        except Exception:
            return None
        try:
            return custom_executor_for(lowered)
        except Exception:
            return None

    def handles(self, name: str) -> bool:
        spec = self._resolve_spec(name)
        if spec is None:
            return False
        if spec.executor == "receipt":
            return bool(self.session is not None)
        if spec.executor == "project":
            return self.project_path is not None and self.tool_fns is not None
        if spec.executor in {"source", "knowledge"}:
            return bool(self.research_tools is not None)
        try:
            if self._resolve_custom_executor(str(name or "")) is not None:
                return True
        except Exception:
            pass
        return False

    def execute(self, call: ToolCall, *, turn: int = 0,
                tool_index: int = 0) -> tuple[ToolResult, bool, int | None]:
        name = str(call.name or "").strip().lower()
        try:
            spec = self._resolve_spec(name)
            executor = spec.executor if spec is not None else ""
        except Exception:
            executor = ""
        if executor == "receipt":
            from codey.operations.tool_result_reader import read_tool_result

            result = read_tool_result(self, call)
            return result, result.ok, None
        if executor == "project":
            return self._execute_project(call)
        if executor in {"source", "knowledge"}:
            return self._execute_research(call, turn=turn, tool_index=tool_index)
        # Third-task tools run via the frozen turn binding when present,
        # otherwise the live registry.
        try:
            fn = self._resolve_custom_executor(name)
        except Exception:
            fn = None
        if callable(fn):
            try:
                produced = fn(call)
            except Exception as exc:
                result = ToolResult(ok=False, call=call, model_text=f"ERROR: {exc or 'tool failed'}")
                return result, False, None
            if not isinstance(produced, ToolResult):
                result = ToolResult(ok=False, call=call, model_text="ERROR: executor must return a structured ToolResult")
                return result, False, None
            return produced, produced.ok, None
        result = ToolResult(ok=False, call=call, model_text=f"ERROR: no production executor for {name or '?'}")
        return result, False, None

    def _policy_check(self, call: ToolCall) -> tuple[bool, str, bool]:
        """Returns (denied, message, approval_required) via the coding guards."""

        spec = self._resolve_spec(call.name)
        if spec is None:
            return True, "tool definition unavailable", False
        if self.session is None:
            return True, "task session unavailable", False
        if not self.session.policy.allows(spec.grant):
            return True, f"task policy denied {call.name}", False
        if spec.executor != "project":
            return False, "", False
        if self.project_path is None:
            return True, "no associated project", False
        try:
            from codey.agents.tool_execution import (
                evaluate_tool_call_policy_for,
                policy_asks_user,
                policy_denied,
            )
        except Exception as exc:
            return True, f"policy unavailable: {exc}", False
        try:
            runtime_name = {"list_dir": "ls", "read_file": "read", "grep": "search",
                            "find_references": "references"}.get(call.name, call.name)
            decision, _replay = evaluate_tool_call_policy_for(
                ToolCall(runtime_name, dict(call.args or {}), call_id=call.call_id),
                project=self.project_path,
                permission_profile=self._project_permission_profile(),
                approval_available=self.approval_available,
                phase="writer",
            )
        except Exception as exc:
            return True, f"policy error: {exc}", False
        if policy_denied(decision):
            reason = str(getattr(decision, "reason", "") or getattr(decision, "reason_code", "") or "denied")
            return True, f"project guard denied {call.name}: {reason}", False
        try:
            if str(call.name or "") == "shell" and bool(policy_asks_user(decision)):
                return True, "shell requires user approval", True
        except Exception:
            pass
        return False, "", False

    def _project_permission_profile(self) -> str:
        return effective_project_profile(self.permission_profile)

    def _execute_project(self, call: ToolCall) -> tuple[ToolResult, bool, int | None]:
        if self.project_path is None:
            return ToolResult(ok=False, call=call, model_text="ERROR: project path unavailable"), False, None
        if self.tool_fns is None:
            return ToolResult(ok=False, call=call, model_text="ERROR: project tools unavailable"), False, None
        project_path = self.project_path
        denied, message, _approval = self._policy_check(call)
        if denied:
            from codey.operations.kernel_result import policy_denial_result

            result = policy_denial_result(call, message)
            return result, False, None
        name = str(call.name or "").strip().lower()
        runtime_name = {"list_dir": "ls", "read_file": "read", "grep": "search",
                        "find_references": "references"}.get(name, name)
        try:
            if runtime_name in {"ls", "read", "search", "references"}:
                from codey.agents.tool_execution import execute_information_tool_call

                outcome = execute_information_tool_call(
                    project_path, self.tool_fns,
                    ToolCall(runtime_name, dict(call.args or {})),
                )
                result = _tool_result(call, outcome)
                ok = outcome.ok if type(getattr(outcome, "ok", None)) is bool else False
                return result, ok, None
            if name == "edit":
                outcome = self._execute_edit(call)
                result = _tool_result(call, outcome)
                ok = outcome.ok if type(getattr(outcome, "ok", None)) is bool else False
                return result, ok, None
            if name == "run":
                outcome = self.tool_fns.execute_run_command(
                    project_path, str((call.args or {}).get("path", ".") or "."),
                    str((call.args or {}).get("command", "") or ""),
                    permission_profile=self._project_permission_profile(), phase="writer",
                    tool_id=str(getattr(call, "call_id", "") or ""),
                )
                result = _tool_result(call, outcome)
                ok = outcome.ok if type(getattr(outcome, "ok", None)) is bool else False
                return result, ok, getattr(outcome, "exit_code", None)
        except Exception as exc:
            result = ToolResult(ok=False, call=call, model_text=f"ERROR: {exc}")
            return result, False, None
        result = ToolResult(ok=False, call=call, model_text=f"ERROR: unsupported project tool {name}")
        return result, False, None

    def _execute_edit(self, call: ToolCall) -> Any:
        from codey.agents.protocol import canonical_project_path
        from codey.agents.tool_execution import read_before_edit_outcome
        from codey.toolchain.runtime import EditBlock, ToolOutcome, safe_join

        if self.project_path is None:
            return ToolOutcome.error("project path unavailable")
        if self.tool_fns is None:
            return ToolOutcome.error("project tools unavailable")
        project_path = self.project_path
        args = dict(call.args or {})
        path = str(args.get("path", "") or "")
        try:
            canonical = canonical_project_path(project_path, path)
            target = safe_join(project_path, canonical)
        except ValueError:
            return ToolOutcome.error("workspace_escape: path escapes project root")
        if "content" in args:
            if target.is_file():
                return ToolOutcome.error(
                    f"content is only allowed when creating a new file; use replacements for existing file: {canonical}"
                )
            if self.change_tracker is not None:
                self.change_tracker.capture_before(path)
            outcome = self.tool_fns.write_file(project_path, path, str(args.get("content") or ""))
            if outcome.ok and outcome.changed and self.change_tracker is not None:
                self.change_tracker.capture_after(path)
            return outcome
        guard = read_before_edit_outcome(
            project_path, path, set(getattr(self.session, "read_files", set()) or set()),
        )
        if guard is not None:
            return guard
        # Canonical protocol only: replacements with old_string/new_string.
        # Top-level aliases are rejected before any file write.
        for legacy in ("search", "replace"):
            if legacy in args:
                return ToolOutcome.error(f"edit rejects legacy alias: {legacy}")
        replacements = args.get("replacements")
        if not isinstance(replacements, list) or not replacements:
            return ToolOutcome.error("edit needs content or exact replacements")
        blocks: list[dict[str, str]] = []
        for item in replacements:
            if not isinstance(item, dict):
                return ToolOutcome.error("edit replacement must be a mapping")
            if set(item) != {"old_string", "new_string"}:
                return ToolOutcome.error("edit replacement must be exactly old_string/new_string")
            search = str(item.get("old_string") or "")
            replace = str(item.get("new_string") or "")
            if not search:
                return ToolOutcome.error("edit replacement search must be non-empty")
            blocks.append({"old_string": search, "new_string": replace})
        if not blocks:
            return ToolOutcome.error("edit needs content or exact replacements")
        edit_blocks = [EditBlock(old_string=b["old_string"], new_string=b["new_string"]) for b in blocks]
        if self.change_tracker is not None:
            self.change_tracker.capture_before(path)
        outcome = self.tool_fns.edit_file(self.project_path, path, edit_blocks)
        if outcome.ok and outcome.changed and self.change_tracker is not None:
            self.change_tracker.capture_after(path)
        return outcome

    def _opened_result(self, call: ToolCall, opened: Any, url: str, *, turn: int,
                       tool_index: int) -> tuple[ToolResult, bool, int | None]:
        model_text = opened.model_text
        if not opened.ok:
            return ToolResult(ok=False, call=call, model_text=model_text), False, None
        from codey.research.output_receipts import maybe_externalize_output

        title = next((line.removeprefix("Title: ") for line in model_text.splitlines()
                      if line.startswith("Title: ")), "")
        outcome = maybe_externalize_output(
            store=self.managed_outputs, session_id=self.session_id, run_id=self.run_id,
            permission_profile=self.permission_profile, call=call,
            output=opened.receipt_text or model_text, ok=opened.ok,
            turn=turn, tool_index=tool_index, presentation_result=title,
            model_text_override=model_text,
        )
        final_url = self._ledger_final_url({"url": url})
        base = _tool_result(call, outcome)
        merged = dict(base.canonical)
        merged["opened_url"] = final_url
        merged["request_url"] = str(url or "")
        ledger = getattr(self.research_tools, "ledger", None)
        if isinstance(ledger, ResearchLedger):
            merged["research_observation"] = ledger_observation(ledger, "open", url=url)
        result = ToolResult(
            ok=base.ok, call=base.call, model_text=base.model_text, truncated=bool(base.truncated),
            presentation=dict(base.presentation) if isinstance(base.presentation, dict) else {},
            audit=dict(base.audit) if isinstance(base.audit, dict) else {},
            canonical=merged,
        )
        return result, True, None

    def _execute_research(self, call: ToolCall, *, turn: int = 0,
                          tool_index: int = 0) -> tuple[ToolResult, bool, int | None]:
        tools = self.research_tools
        name = str(call.name or "").strip().lower()
        args = dict(call.args or {})
        try:
            if name == "web_search":
                from codey.research.text_args import first_text_arg

                outcome = tools.web_search(first_text_arg(args, "query"))
                canonical = {}
                ledger = getattr(tools, "ledger", None)
                if outcome.ok and isinstance(ledger, ResearchLedger):
                    canonical["research_observation"] = ledger_observation(ledger, name)
                return ToolResult(ok=outcome.ok, call=call, model_text=outcome.model_text, canonical=canonical), outcome.ok, None
            if name == "open_url":
                opened = tools.open_url(str(args.get("url") or ""), offset=args.get("offset", 0),
                                        limit=args.get("limit", 6000), pages=str(args.get("pages") or ""))
                return self._opened_result(call, opened, str(args.get("url") or ""),
                                           turn=turn, tool_index=tool_index)
            if name in {"open_result", "reopen_source", "open_hit"}:
                url = self._resolve_alias_url(name, args)
                if not url:
                    return ToolResult(ok=False, call=call, model_text=f"ERROR: unknown {name} id"), False, None
                target = (getattr(self.session, "hit_targets", {}) or {}).get(
                    str(args.get("hit_id") or "").lower(), {}
                ) if name == "open_hit" else dict[str, Any]()
                opened = (tools.open_url(url, offset=target.get("offset", 0),
                                         pages=target.get("pages", ""))
                          if target else tools.open_url(url))
                return self._opened_result(call, opened, url, turn=turn, tool_index=tool_index)
            if name == "source_search":
                query = str(args.get("query") or "")
                url = str(args.get("url") or "")
                if not url and str(args.get("source_id") or ""):
                    url = self._resolve_alias_url("reopen_source", {"source_id": args.get("source_id")}) or ""
                outcome = tools.source_search(url, query, args.get("limit", 6))
                if outcome.ok and url and self.session is not None:
                    text, mapping = self._build_hit_mapping(outcome.model_text, url)
                    hit_canonical: dict[str, object] = {"hit_targets": mapping, "source_url": url}
                    ledger = getattr(tools, "ledger", None)
                    if isinstance(ledger, ResearchLedger):
                        hit_canonical["research_observation"] = ledger_observation(ledger, name)
                    return (
                        ToolResult(ok=outcome.ok, call=call, model_text=text, canonical=hit_canonical),
                        True, None,
                    )
                return ToolResult(ok=outcome.ok, call=call, model_text=outcome.model_text), outcome.ok, None
            if name == "knowledge_search":
                from codey.research.text_args import first_text_arg

                outcome = tools.knowledge_search(first_text_arg(args, "query"))
                return ToolResult(ok=outcome.ok, call=call, model_text=outcome.model_text), outcome.ok, None
            if name == "knowledge_read":
                outcome = tools.knowledge_read(str(args.get("id") or ""))
                return ToolResult(ok=outcome.ok, call=call, model_text=outcome.model_text), outcome.ok, None
            if name == "knowledge_write":
                before = len(getattr(getattr(tools, "ledger", None), "evidence_items", ()) or ())
                lowered, problem = self._lower_knowledge_sources(args)
                if problem:
                    return ToolResult(ok=False, call=call, model_text=f"ERROR: {problem}"), False, None
                outcome = tools.knowledge_write(lowered)
                if not outcome.ok:
                    return ToolResult(ok=outcome.ok, call=call, model_text=outcome.model_text), False, None
                evidence = self._ledger_evidence(before)
                evidence_canonical: dict[str, object] = {"evidence_items": evidence}
                ledger = getattr(tools, "ledger", None)
                if isinstance(ledger, ResearchLedger):
                    evidence_canonical["research_observation"] = ledger_observation(ledger, name, evidence_start=before)
                return (
                    ToolResult(ok=outcome.ok, call=call, model_text=outcome.model_text, canonical=evidence_canonical),
                    True, None,
                )
            if name == "knowledge_link":
                outcome = tools.knowledge_link(str(args.get("src") or ""), str(args.get("dst") or ""),
                                            str(args.get("kind") or "relates"))
                return ToolResult(ok=outcome.ok, call=call, model_text=outcome.model_text), outcome.ok, None
        except Exception as exc:
            return ToolResult(ok=False, call=call, model_text=f"ERROR: {exc}"), False, None
        return ToolResult(ok=False, call=call, model_text=f"ERROR: unknown research tool {name}"), False, None

    def _lower_knowledge_sources(self, args: dict[str, Any]) -> tuple[dict[str, Any], str]:
        import re

        sources = dict(getattr(self.session, "source_ids", {}) or {})

        def lower(value: object) -> tuple[str, str]:
            text = str(value or "").strip()
            key = text.lower()
            if key in sources:
                return str(sources[key]), ""
            if re.fullmatch(r"s[1-9][0-9]*", key):
                return "", f"unknown source_id: {text}"
            return text, ""

        lowered = dict(args)
        if isinstance(args.get("sources"), list):
            rows: list[str] = []
            for value in args["sources"]:
                resolved, error = lower(value)
                if error:
                    return {}, error
                rows.append(resolved)
            lowered["sources"] = rows
        if isinstance(args.get("evidence"), list):
            evidence: list[dict[str, Any]] = []
            for value in args["evidence"]:
                if not isinstance(value, dict):
                    evidence.append(value)
                    continue
                row = dict(value)
                for key in ("source_url", "source"):
                    if key in row:
                        resolved, error = lower(row[key])
                        if error:
                            return {}, error
                        row[key] = resolved
                evidence.append(row)
            lowered["evidence"] = evidence
        return lowered, ""

    def _resolve_alias_url(self, alias: str, args: dict[str, Any]) -> str:
        session = self.session
        key = {"open_result": "result_id", "reopen_source": "source_id", "open_hit": "hit_id"}.get(alias, "")
        rid = str(args.get(key, "") or "").strip().lower() if key else ""
        if not rid or session is None:
            return ""
        results = dict(getattr(session, "search_results", {}) or {})
        sources = dict(getattr(session, "source_ids", {}) or {})
        if alias == "open_hit":
            return str((getattr(session, "hit_targets", {}) or {}).get(rid, {}).get("url", "") or "")
        return str(results.get(rid, "") or sources.get(rid, "") or "")

    def _build_hit_mapping(self, text: str, url: str) -> tuple[str, dict[str, dict[str, object]]]:
        """Build hit text plus its mapping without touching the session.

        IDs consider both the live session mapping and the current batch so
        repeated IDs never collide. The caller persists the mapping in the
        receipt canonical; the single fact entry applies it to the session.
        """
        import re

        existing = dict(getattr(self.session, "hit_targets", {}) or {}) if self.session is not None else {}
        batch: dict[str, dict[str, object]] = {}
        by_target: dict[tuple[str, int, str], str] = {}
        for key, value in list(existing.items()):
            if isinstance(value, dict):
                by_target[(str(value.get("url", "")), int(value.get("offset", 0) or 0), str(value.get("pages", "")))] = key
        lines: list[str] = []
        counter = len(existing) + 1
        for line in str(text or "").splitlines():
            match = re.match(r"^\s*\d+\.\s+(?:offset\s+(\d+)|p\.(\d+)):", line)
            if match:
                target = (str(url or ""), int(match.group(1) or 0), str(match.group(2) or ""))
                hit_id = by_target.get(target, "")
                if not hit_id:
                    while f"h{counter}" in existing or f"h{counter}" in batch:
                        counter += 1
                    hit_id = f"h{counter}"
                    counter += 1
                    batch[hit_id] = {"url": target[0], "offset": target[1], "pages": target[2]}
                    by_target[target] = hit_id
                line = f"{hit_id}: {line}"
            lines.append(line)
        return "\n".join(lines), batch

    def _ledger_final_url(self, args: dict[str, Any]) -> str:
        from codey.research.urls import opened_url

        requested = str(args.get("url", "") or "")
        ledger = getattr(self.research_tools, "ledger", None)
        return opened_url(ledger, requested)

    def _ledger_evidence(self, before: int) -> list[dict[str, str]]:
        tools = self.research_tools
        ledger = getattr(tools, "ledger", None)
        items = list(getattr(ledger, "evidence_items", ()) or [])
        fresh = items[before:] if before >= 0 else items
        evidence: list[dict[str, str]] = []
        for item in fresh:
            url = str(getattr(item, "source_url", "") or "").strip()
            excerpt = str(getattr(item, "excerpt", "") or "").strip()
            if url and excerpt:
                evidence.append({"source_url": url, "excerpt": excerpt[:600]})
        return evidence


__all__ = ["ExecutionDelegate", "build_research_tools", "close_research_tools"]
