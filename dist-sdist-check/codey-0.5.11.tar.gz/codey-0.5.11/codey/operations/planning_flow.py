"""Planning-readonly task operation."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from codey.research.tools import ResearchTools

from codey.agents.request import AgentRequest
from codey.operations.context import RunFrame, RunWork
from codey.operations.ghost_context import ghost_continuity as _ghost_continuity_fn
from codey.operations.ghost_context import ghost_directive as _ghost_directive_fn
from codey.operations.prompting import record_local_context_trace
from codey.operations.result import ModeOutcome
from codey.operations.task_context import ProjectTaskContextBuilder
from codey.operations.task_state import TaskState
from codey.runtime.observe.events import RunEvent, render_run_event, run_event_ui_payload
from codey.workspace.config import ProjectConfigLoadResult
from codey.workspace.facts import ProjectFactsStore


@dataclass(frozen=True)
class PlanningFlowDeps:
    state: TaskState
    agent_run: Callable[..., Any]
    project_facts: ProjectFactsStore | None = None
    knowledge_store: Any = None
    search_factory: Callable[[], Any] | None = None
    review_log_lines: int = 80
    ghost_directive: Callable[..., Any] | None = None
    ghost_continuity: Callable[..., Any] | None = None
    ghost_experiences: Callable[..., Any] | None = None


def _planning_entry_policy(frame: RunFrame, request: Any) -> Any:
    """Require a read-only policy before constructing execution resources."""
    from codey.operations.task_entry import build_task_policy_for_entry

    policy = frame.entry_policy
    if policy is None:
        policy = build_task_policy_for_entry(request, "planning")
    readonly_grants = policy.grants & {"control", "project.read", "web.read", "knowledge.read"}
    if readonly_grants != policy.grants:
        policy = replace(policy, grants=frozenset(readonly_grants), source=policy.source + ";planning_readonly")
    return policy


def _planning_research_tools(deps: PlanningFlowDeps, policy: Any, *, session_id: str, project: str) -> ResearchTools | None:
    """Construct source resources only when the resolved policy permits them."""
    from codey.operations.task_execution import build_research_tools

    if not policy.allows("web.read") and not policy.allows("knowledge.read"):
        return None
    return build_research_tools(deps, session_id=session_id, project=project)


def run_planning_readonly_mode(
    deps: PlanningFlowDeps,
    frame: RunFrame,
    work: RunWork,
    *,
    config_result: ProjectConfigLoadResult | None = None,
) -> ModeOutcome:
    state = deps.state
    request = frame.request
    project = request.project
    if project is None:
        raise RuntimeError("planning_readonly mode requires a project")
    if frame.provider is None:
        raise RuntimeError("provider is not connected")
    if work.ledger is not None:
        work.record_agent_events_in_ledger = True
    context_builder = ProjectTaskContextBuilder(
        project_facts=deps.project_facts,
        work_checkpoints=None,
        knowledge_store=deps.knowledge_store,
        config_result=config_result,
    )
    project_context = context_builder.build(
        project=project,
        task=request.task,
        session_id=request.session_id,
        run_id=frame.run_id,
        continue_task=False,
        provider_session_changed=frame.provider_session_changed,
    )
    ghost_directive = deps.ghost_directive(
        project=project,
        session_id=request.session_id,
    ) if deps.ghost_directive is not None else None
    ghost_continuity = deps.ghost_continuity(
        project=project,
        session_id=request.session_id,
    ) if deps.ghost_continuity is not None else None
    if ghost_directive is None or ghost_continuity is None:
        ghost_directive = ghost_directive or _ghost_directive_fn(deps.state, project=project, session_id=request.session_id)
        ghost_continuity = ghost_continuity or _ghost_continuity_fn(deps.state, project=project, session_id=request.session_id)
    record_local_context_trace(frame.trace, ghost_directive, ghost_continuity)
    experiences = ""
    if deps.ghost_experiences is not None:
        try:
            experiences = deps.ghost_experiences(
                session_id=request.session_id,
                project=project,
                query=request.task,
            )
        except Exception:
            experiences = ""
    entry_policy = _planning_entry_policy(frame, request)
    # 共同任务准备：策略一次确定、run 身份、授权资源、恢复行全部传入，
    # planning 只收窄写权限并提供规划上下文。
    from codey.operations.task_execution import close_research_tools

    research_tools = _planning_research_tools(
        deps, entry_policy, session_id=request.session_id, project=project,
    )
    try:
        mutations = getattr(state, "runtime_mutations", None)
        if mutations is not None and request.session_id and frame.run_id:
            mutations.mark_writer_running(request.session_id, frame.run_id, provider_id=frame.provider_id)
        result = deps.agent_run(AgentRequest(
            provider=frame.provider,
            project=Path(project),
            task=request.task,
            max_turns=request.max_turns,
            on_event=lambda event: record_planning_event(deps, frame, work, event),
            on_shell_request=None,
            stop_flag=state.run_registry.stop_flag,
            fresh_chat=frame.fresh_chat,
            change_tracker=None,
            conversation=frame.conversation,
            provider_id=frame.provider_id,
            handoff=frame.handoff,
            project_facts=project_context.verified_facts,
            research_context=project_context.research_context,
            project_map=project_context.project_map,
            project_config_warnings=project_context.project_config_warnings,
            ghost_directive=ghost_directive.text,
            ghost_continuity=ghost_continuity.text,
            ghost_experiences=str(experiences or ""),
            permission_profile="planning_readonly",
            trace_recorder=frame.trace,
            session_id=request.session_id,
            run_id=frame.run_id,
            effect_scope="planning:1",
            runtime_mutations=getattr(state, "runtime_mutations", None),
            workspace_revision_store=getattr(state, "workspace_revisions", None),
            managed_outputs=getattr(state, "managed_outputs", None),
            recovered_tool_outcomes=tuple(getattr(frame, "recovered_tool_outcomes", ()) or ()),
            settled_tool_outcomes=frame.settled_tool_outcomes,
            recovered_tool_result_batch_id=str(getattr(frame, "recovered_tool_result_batch_id", "") or ""),
            requested_capabilities=tuple(getattr(request, "requested_capabilities", ()) or ()),
            strict_research=bool(getattr(request, "strict_research", False) is True),
            project_changes_required=bool(getattr(request, "project_changes_required", False) is True),
            task_policy=entry_policy,
            research_tools=research_tools,
        ))
    finally:
        close_research_tools(research_tools)
    state.set_provider_session(
        frame.provider_id,
        None if result.stop_reason == "stopped" else request.session_id,
    )
    frame.conversation.update_snapshot(
        replace(
            frame.conversation.snapshot,
            provider_id=frame.provider_id,
            checks_passed=False,
            summary=result.summary,
            blocker="" if result.stop_reason == "done" else result.summary,
        )
    )
    return ModeOutcome(
        {
            "type": "task_done",
            "run_id": frame.run_id,
            "session_id": request.session_id,
            "summary": result.summary,
            "stop_reason": result.stop_reason,
            "turns": result.turns,
            "max_turns": request.max_turns,
            "provider": frame.provider_id,
            "mode": "planning",
            "changed": False,
        }
    )


def record_planning_event(
    deps: PlanningFlowDeps,
    frame: RunFrame,
    work: RunWork,
    event: RunEvent,
) -> None:
    if work.record_agent_events_in_ledger and work.ledger is not None:
        try:
            work.ledger.append_run_event(event)
        except Exception:
            work.ledger = None
    payload = run_event_ui_payload(frame.run_id, frame.request.session_id, event)
    if payload is not None:
        deps.state.emit(payload)
    if event.kind == "tool_start":
        return
    work.evidence.record(event)
    message = render_run_event(event)
    work.recent_events.append(message)
    if len(work.recent_events) > deps.review_log_lines * 2:
        del work.recent_events[: deps.review_log_lines]


__all__ = [
    "PlanningFlowDeps",
    "record_planning_event",
    "run_planning_readonly_mode",
]
