"""Operation execution context shared by task-mode operations."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from codey.agents.handoff import ConversationContext, ConversationSnapshot
from codey.agents.request import RecoveredToolOutcome
from codey.agents.shell_approval import ShellApprovalRequest
from codey.ghost.work_queue_model import GhostWorkItem
from codey.operations.conversation_window import WindowAction
from codey.operations.kernel_protocol import InitialNativeTurn
from codey.providers.diagnostics import ProviderFailure
from codey.runs.ledger import RunLedgerWriter
from codey.runs.work_checkpoint import WorkCheckpoint, WorkCheckpointStore
from codey.runtime.core.operation_state import RuntimeOperationState
from codey.runtime.observe.events import RunEvent
from codey.runtime.observe.execution_evidence import ExecutionEvidence
from codey.task.model import TaskSubmission
from codey.workspace.revision import INITIAL_WORKSPACE_REVISION


@dataclass
class RunFrame:
    request: TaskSubmission
    run_id: str
    task_kind: str
    provider: Any | None
    provider_id: str
    project_text: str
    conversation: ConversationContext
    fresh_chat: bool
    handoff: str
    research_handoff: str
    prior_snapshot: ConversationSnapshot
    recovered_owner_prompt: str
    provider_session_changed: bool
    preflight_tried: set[str]
    preflight_switches: int
    window_action: WindowAction | None = None
    trace: Any | None = None
    recovered_tool_outcomes: tuple[RecoveredToolOutcome, ...] = ()
    recovered_tool_result_batch_id: str = ""
    entry_policy: Any | None = None
    settled_tool_outcomes: tuple[RecoveredToolOutcome, ...] = ()
    entry_session: Any | None = None
    entry_research_tools: Any | None = None
    entry_initial_turn: InitialNativeTurn | None = None


@dataclass
class RunWork:
    recent_events: list[str]
    evidence: ExecutionEvidence
    work_checkpoint: WorkCheckpoint | None = None
    ledger: RunLedgerWriter | None = None
    trace: Any | None = None
    record_agent_events_in_ledger: bool = False
    claimed_work_item: GhostWorkItem | None = None
    analysis_run_payloads: list[dict[str, object]] = field(default_factory=list)
    artifact_payloads: list[dict[str, object]] = field(default_factory=list)
    operation: RuntimeOperationState | None = None
    turns_observed: int = 0
    workspace_revision: int = INITIAL_WORKSPACE_REVISION
    workspace_fingerprint: str = ""

    def refresh_workspace_state(
        self,
        store: Any,
        project: str,
        *,
        ignored_paths: tuple[str, ...] = (),
    ) -> None:
        state = store.current_state(project, ignored_paths=ignored_paths)
        self.workspace_revision = state.revision
        self.workspace_fingerprint = state.fingerprint
        self.evidence.set_workspace_state(state.revision, state.fingerprint)

    def advance_workspace_revision(
        self,
        store: Any,
        project: str,
        *,
        ignored_paths: tuple[str, ...] = (),
    ) -> None:
        state = store.bump_state(project, ignored_paths=ignored_paths)
        self.workspace_revision = state.revision
        self.workspace_fingerprint = state.fingerprint
        self.evidence.set_workspace_state(state.revision, state.fingerprint)


@dataclass(frozen=True)
class RunHooks:
    on_event: Callable[[RunEvent], None]
    on_shell_request: Callable[[ShellApprovalRequest], None]
    update_checkpoint: Callable[
        [Callable[[WorkCheckpointStore, WorkCheckpoint], WorkCheckpoint]],
        None,
    ]
    record_provider_failure: Callable[[str, ProviderFailure], None]
    append_ledger: Callable[[Callable[[RunLedgerWriter], None]], None]
    provider_failover_order: Callable[[], tuple[str, ...]]
    supervisor: Any | None
    trace: Any | None = None
