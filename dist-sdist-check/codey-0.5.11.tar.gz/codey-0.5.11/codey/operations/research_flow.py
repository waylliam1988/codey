from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, replace
from functools import partial
from typing import Any

from codey.ghost.work_queue_model import GhostWorkItem
from codey.knowledge.research_interest import (
    build_research_interest_candidates,
    candidate_to_topic_hint,
)
from codey.operations.context import RunFrame, RunHooks
from codey.operations.evidence_followup import run_evidence_followup
from codey.operations.result import ModeOutcome
from codey.operations.task_state import TaskState
from codey.policies.permissions import allows_context_source, profile_for_name
from codey.research.completion_gate import RESEARCH_QUEUE_KINDS
from codey.research.context import ResearchContext, RunTraceResearchSink
from codey.research.evidence_ledger import EvidenceLedgerWriteResult
from codey.research.pipeline import (
    ResearchIterationRun,
    ResearchPipeline,
    ResearchPipelineConfig,
    ResearchPipelineResult,
)
from codey.research.proof_quality import proof_review_trace_payload
from codey.research.query_planner import build_research_plan, research_plan_trace_payload
from codey.research.topic_continuity import (
    CONTEXT_SOURCE_KEY as TOPIC_CONTINUITY_CONTEXT_SOURCE_KEY,
)
from codey.research.topic_continuity import (
    MAX_TOPIC_CLAIM_REFS,
    project_topic_continuity,
)
from codey.runtime.core import cancellation
from codey.runtime.observe.prompt_envelope import FailOpenPromptTrace


@dataclass(frozen=True)
class ResearchFlowDeps:
    state: TaskState
    knowledge_store: Any
    evidence_ledgers: Any
    search_factory: Callable[[], object]
    run_research_advisors: Callable[..., Any] | None
    ghost_continuity: Callable[..., object]
    managed_outputs: Any = None
    runtime_mutations: Any = None


def record_research_proof_review_trace(trace: Any | None, review: Any) -> None:
    if trace is None or review is None:
        return
    sink = FailOpenPromptTrace(trace)
    sink.call(
        "record_research_proof_review",
        proof_review_trace_payload(review),
    )
    sink.call("flush")


def record_research_plan_trace(
    trace: Any | None,
    review: Any,
    *,
    question: str = "",
) -> None:
    if trace is None or review is None:
        return
    try:
        plan = build_research_plan(review, question=question)
        payload = research_plan_trace_payload(plan)
    except Exception:
        return
    sink = FailOpenPromptTrace(trace)
    sink.call("record_research_plan", payload)
    sink.call("flush")


def research_queue_item_title(item: GhostWorkItem | None) -> str:
    if item is None:
        return ""
    if str(getattr(item, "kind", "") or "") not in RESEARCH_QUEUE_KINDS:
        return ""
    return str(getattr(item, "title", "") or "").strip()


def run_research_mode(
    deps: ResearchFlowDeps,
    frame: RunFrame,
    hooks: RunHooks,
    *,
    proof_question: str = "",
    run_pipeline: Callable[..., ResearchPipelineResult] | None = None,
) -> ModeOutcome:
    request = frame.request
    if frame.provider is None:
        raise RuntimeError("provider is not connected")
    from codey.operations.provider_session import ConversationProvider

    frame.provider = ConversationProvider(
        frame.provider, frame.conversation,
        fresh_window=(frame.provider_id, "research", frame.project_text),
    )
    pipeline = run_pipeline or partial(run_research_pipeline, deps)
    pipeline_result = pipeline(
        frame,
        hooks,
        max_turns=request.max_turns,
        proof_question=proof_question,
    )
    result = pipeline_result.final_result
    deps.state.set_provider_session(
        frame.provider_id,
        None if result.stop_reason == "stopped" else request.session_id,
    )
    frame.conversation.update_snapshot(
        replace(
            frame.conversation.snapshot,
            mode="research",
            goal=request.task,
            project=frame.project_text,
            provider_id=frame.provider_id,
            blocker="" if result.stop_reason == "done" else result.summary,
            latest_user=request.task,
            latest_reply=result.summary,
            summary=result.summary,
        ),
    )
    receipt = {
        "display": {"summary": result.receipt},
        "work": {
            "created": result.notes_created,
            "updated": result.notes_updated,
            "synthesis_id": result.synthesis_id,
        },
    }
    return ModeOutcome({
        "type": "task_done",
        "run_id": frame.run_id,
        "session_id": request.session_id,
        "summary": result.summary,
        "stop_reason": result.stop_reason,
        "turns": result.turns,
        "max_turns": request.max_turns,
        "provider": frame.provider_id,
        "mode": "research",
        "receipt": receipt,
        "research": research_payload(result, pipeline_result=pipeline_result),
    }, research_result=result, research_pipeline_result=pipeline_result)


def build_research_topic_continuity(
    deps: ResearchFlowDeps,
    *,
    session_id: str,
    project: str,
    trace: Any | None = None,
    prior_claim_refs: Callable[..., tuple[dict[str, object], ...]] | None = None,
) -> tuple[str, dict[str, object] | None]:
    """Admit bounded Ghost-to-Research topic continuity."""

    try:
        profile = profile_for_name("research")
        if not allows_context_source(profile, TOPIC_CONTINUITY_CONTEXT_SOURCE_KEY):
            return "", None
        interest_hints = [
            candidate_to_topic_hint(candidate)
            for candidate in build_research_interest_candidates(
                deps.knowledge_store,
                session_id=session_id,
                project=project,
            )
        ]
        continuity = deps.ghost_continuity(project=project, session_id=session_id)
        claim_ref_loader = prior_claim_refs or (
            partial(deps_prior_claim_refs, deps=deps)
        )
        projection = project_topic_continuity(
            interest_hints=interest_hints,
            continuity_hints=tuple(getattr(continuity, "selected_items", ()) or ()),
            claim_refs=claim_ref_loader(session_id=session_id, project=project),
        )
    except cancellation.TaskCancelled:
        raise
    except cancellation.DeadlineExceeded:
        raise
    except Exception:
        FailOpenPromptTrace(trace).call(
            "warn",
            "research_topic_continuity_projection_failed",
        )
        return "", None
    payload = projection.to_payload()
    if not projection.admitted:
        return "", payload
    return projection.prompt_text, payload


def deps_prior_claim_refs(
    *,
    deps: ResearchFlowDeps | None = None,
    session_id: str,
    project: str,
) -> tuple[dict[str, object], ...]:
    ledgers = deps.evidence_ledgers if deps is not None else None
    return prior_claim_refs(ledgers, session_id=session_id, project=project)


def prior_claim_refs(
    evidence_ledgers: Any,
    *,
    session_id: str,
    project: str,
) -> tuple[dict[str, object], ...]:
    """Bounded claim refs from the durable evidence ledger; refs only."""

    if evidence_ledgers is None:
        return ()
    try:
        snapshot = evidence_ledgers.load(session_id=session_id, project=project)
    except Exception:
        return ()
    payload = getattr(snapshot, "payload", None)
    if not getattr(snapshot, "available", False) or not isinstance(payload, Mapping):
        return ()
    refs: list[dict[str, object]] = []
    for record in list(payload.get("records") or ())[-4:]:
        for claim_ref in record.get("claim_refs") or ():
            text = str(claim_ref or "").strip()
            if not text:
                continue
            refs.append({"ref": f"prior_claim:{text}"})
            if len(refs) > MAX_TOPIC_CLAIM_REFS:
                break
        if len(refs) > MAX_TOPIC_CLAIM_REFS:
            break
    return tuple(refs)


def build_research_context(
    deps: ResearchFlowDeps,
    frame: RunFrame,
    *,
    proof_question: str,
    max_turns: int,
    build_topic_continuity: Callable[..., tuple[str, dict[str, object] | None]] | None = None,
) -> ResearchContext:
    request = frame.request
    if build_topic_continuity is None:
        continuity_text, continuity_payload = build_research_topic_continuity(
            deps,
            session_id=request.session_id,
            project=frame.project_text,
            trace=frame.trace,
        )
    else:
        continuity_text, continuity_payload = build_topic_continuity(
            session_id=request.session_id,
            project=frame.project_text,
            trace=frame.trace,
        )
    return ResearchContext(
        question=request.task,
        session_id=request.session_id,
        run_id=frame.run_id,
        project=frame.project_text,
        provider_id=frame.provider_id,
        proof_question=proof_question,
        permission_profile="research",
        max_turns=max_turns,
        chat_handoff=frame.research_handoff,
        should_stop=deps.state.run_registry.stop_flag.is_set,
        trace=RunTraceResearchSink(frame.trace),
        topic_continuity_context=continuity_text,
        topic_continuity_payload=continuity_payload,
    )


def run_research_pipeline(
    deps: ResearchFlowDeps,
    frame: RunFrame,
    hooks: RunHooks,
    *,
    max_turns: int,
    proof_question: str = "",
    run_iteration: Callable[..., ResearchIterationRun] | None = None,
    build_context: Callable[..., ResearchContext] | None = None,
    record_ledger_write: Callable[[RunHooks, EvidenceLedgerWriteResult], None] | None = None,
) -> ResearchPipelineResult:
    request = frame.request
    if frame.provider is None:
        raise RuntimeError("provider is not connected")

    def iteration(
        *,
        task: str,
        max_turns: int,
        chat_handoff: str,
        search: object,
        tools: Any = None,
        iteration_context: str = "",
        topic_continuity_context: str = "",
        topic_continuity_payload: Any = None,
    ) -> Any:
        import functools

        from codey.operations.research_iteration import run_research_iteration as _canonical

        runner = run_iteration or functools.partial(_canonical, deps)
        return runner(
            provider=frame.provider,
            session_id=request.session_id,
            project=frame.project_text,
            task=task,
            max_turns=max_turns,
            on_event=hooks.on_event,
            stop_flag=deps.state.run_registry.stop_flag,
            provider_id=frame.provider_id,
            run_id=frame.run_id,
            chat_handoff=chat_handoff,
            trace_recorder=frame.trace,
            search=search,
            tools=tools,
            iteration_context=iteration_context,
            topic_continuity_context=topic_continuity_context,
            topic_continuity_payload=topic_continuity_payload,
            requested_capabilities=request.requested_capabilities,
            task_policy=getattr(frame, "entry_policy", None),
        )

    followup_index = 0

    def followup(
        *,
        tools: Any,
        plan: Any,
        material: Any,
        question: str,
        initial_summary: str = "",
        max_context_chars: int = 8000,
        should_stop: Any = None,
        parent_policy: Any = None,
    ) -> Any:
        nonlocal followup_index
        followup_index += 1
        return run_evidence_followup(
            provider=frame.provider,
            tools=tools,
            plan=plan,
            material=material,
            question=question,
            initial_summary=initial_summary,
            max_context_chars=max_context_chars,
            should_stop=should_stop,
            session_id=request.session_id,
            run_id=frame.run_id,
            provider_id=frame.provider_id,
            round_index=followup_index,
            runtime_mutations=deps.runtime_mutations,
            on_event=hooks.on_event,
            parent_policy=parent_policy if parent_policy is not None else getattr(frame, "entry_policy", None),
        )

    recorder = getattr(deps.state, "record_research_changes", None)
    changes_sink = recorder if callable(recorder) else None
    context_builder = build_context or (
        partial(build_research_context, deps)
    )
    ledger_sink = record_ledger_write or record_evidence_ledger_write
    pipeline = ResearchPipeline(
        context=context_builder(
            frame,
            proof_question=proof_question,
            max_turns=max_turns,
        ),
        run_iteration=iteration,
        search_factory=deps.search_factory,
        evidence_followup_runner=followup,
        evidence_ledgers=deps.evidence_ledgers,
        config=ResearchPipelineConfig(),
        ledger_event_sink=lambda result: ledger_sink(hooks, result),
        research_changes_sink=changes_sink,
        policy=getattr(frame, "entry_policy", None),
    )
    return pipeline.run()


def record_evidence_ledger_write(
    hooks: RunHooks,
    result: EvidenceLedgerWriteResult,
) -> None:
    payload = result.to_trace_payload()
    hooks.append_ledger(
        lambda ledger: ledger.append(
            "evidence_ledger_write",
            ok=payload.get("ok"),
            skipped=payload.get("skipped"),
            reason_code=payload.get("reason_code"),
            ledger_ref=payload.get("ledger_ref"),
            record_id=payload.get("record_id"),
            counts=payload.get("counts"),
        )
    )


def research_payload(result: Any, *, pipeline_result: Any | None = None) -> dict[str, Any]:
    payload = {
        "max_turns_used": int(getattr(result, "max_turns_used", 0) or 0),
        "synthesis_id": result.synthesis_id,
        "notes_created": result.notes_created,
        "notes_updated": result.notes_updated,
        "sources_read": result.sources_read,
        "source_urls": result.source_urls,
        "queries": result.queries,
        "search_results": result.search_results,
        "opened_sources": result.opened_sources,
        "coverage": result.coverage,
        "citation_map": result.citation_map,
        "evidence_items": result.evidence_items,
        "counterpoints": result.counterpoints,
        "quality_warnings": result.quality_warnings,
    }
    # 共同 gate 的权威证明随投影保留，不得丢弃后另造。
    try:
        proof = getattr(result, "completion_proof", None)
        to_payload = getattr(proof, "to_payload", None)
        if callable(to_payload):
            payload["completion_proof"] = to_payload()
    except Exception:
        pass
    if pipeline_result is not None:
        to_payload = getattr(pipeline_result, "to_payload", None)
        metadata = to_payload() if callable(to_payload) else dict[str, Any]()
        if isinstance(metadata, dict):
            payload.update({
                "followup_applied": bool(metadata.get("followup_applied")),
                "followup_rounds": max(0, min(3, int(metadata.get("followup_rounds") or 0))),
                "pipeline_stop_reason": str(metadata.get("stop_reason") or ""),
                "planner_stop_reason": str(metadata.get("planner_stop_reason") or ""),
                "fresh_source_count": max(0, int(metadata.get("fresh_source_count") or 0)),
                "new_evidence_count": max(0, int(metadata.get("new_evidence_count") or 0)),
                "final_evidence_count": max(0, int(metadata.get("final_evidence_count") or 0)),
                "attempted_fresh_source_count": max(0, int(metadata.get("attempted_fresh_source_count") or 0)),
                "attempted_new_evidence_count": max(0, int(metadata.get("attempted_new_evidence_count") or 0)),
            })
    return payload


__all__ = [
    "ResearchFlowDeps",
    "build_research_context",
    "build_research_topic_continuity",
    "deps_prior_claim_refs",
    "prior_claim_refs",
    "record_evidence_ledger_write",
    "record_research_plan_trace",
    "record_research_proof_review_trace",
    "research_payload",
    "research_queue_item_title",
    "run_research_mode",
    "run_research_pipeline",
]
