"""Ghost task policy and post-turn projections.

This module owns Ghost side effects around a task run. The task runtime only
passes it terminal facts; Ghost stores do not need to know the old task entry
implementation exists.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from codey.ghost.work_queue import is_strict_work_continuation, proof_refs_from_task_event
from codey.ghost.work_queue_model import GhostWorkItem
from codey.knowledge.research_interest import (
    apply_research_affinity_hints,
    build_research_interest_candidates,
)
from codey.operations.context import RunFrame
from codey.operations.ghost_context import ghost_affinity_store
from codey.operations.research_flow import (
    record_research_plan_trace,
    record_research_proof_review_trace,
    research_queue_item_title,
)
from codey.operations.task_state import TaskState
from codey.research.completion_gate import RESEARCH_QUEUE_KINDS, ResearchCompletionGate
from codey.runs.ledger_projection import load_run_projection
from codey.utils.refs import digest_text


@dataclass(frozen=True)
class GhostTaskPolicyDeps:
    state: TaskState
    run_ledgers: Any = None
    evidence_ledgers: Any = None
    work_checkpoints: Any = None
    knowledge_store: Any = None
    has_reviewable_diff: Callable[[str | None], bool] | None = None
    record_completion_proof_trace: Callable[[Any, object], None] | None = None


def maybe_claim_work_item(
    deps: GhostTaskPolicyDeps,
    request: Any,
    *,
    run_id: str,
) -> Any:
    if str(request.intent or "auto").strip().lower() != "auto":
        return None
    if not is_strict_work_continuation(request.task):
        return None
    store = getattr(deps.state, "ghost_work_queue", None)
    if store is None:
        return None
    if not _ghost_learning_enabled(deps.state):
        return None
    try:
        affinity_hints = ()
        affinity_store = ghost_affinity_store(deps.state)
        if affinity_store is not None:
            try:
                queued = store.list_items(
                    status="queued",
                    project=request.project or "",
                    session_id=request.session_id,
                )
                affinity_hints = affinity_store.query_work_priority_hints(
                    queued,
                    project=request.project or "",
                    session_id=request.session_id,
                )
            except Exception as exc:
                _record_ghost_warning(
                    deps,
                    "work_priority_hints",
                    exc,
                    request=request,
                    run_id=run_id,
                )
                affinity_hints = ()
        result = store.claim_next(
            session_id=request.session_id,
            project=request.project or "",
            run_id=run_id,
            user_request=request.task,
            affinity_hints=affinity_hints,
        )
    except Exception as exc:
        _record_ghost_warning(deps, "work_claim", exc, request=request, run_id=run_id)
        return None
    return result if getattr(result, "ok", False) and getattr(result, "item", None) is not None else None


def release_work_item(
    deps: GhostTaskPolicyDeps,
    item: GhostWorkItem | None,
    *,
    run_id: str,
    reason: str,
) -> None:
    if item is None:
        return
    store = getattr(deps.state, "ghost_work_queue", None)
    if store is None:
        return
    try:
        store.release_item(item.id, run_id=run_id, reason=reason)
    except Exception as exc:
        _record_ghost_warning(deps, "work_release", exc, run_id=run_id)
        return


def run_ghost_post_turn(
    deps: GhostTaskPolicyDeps,
    frame: RunFrame | None,
    event: dict[str, object],
    item: GhostWorkItem | None,
    *,
    research_result: Any = None,
    project_text: str = "",
) -> None:
    session_id = str(event.get("session_id") or getattr(getattr(frame, "request", None), "session_id", "") or "")
    run_id = str(event.get("run_id") or getattr(frame, "run_id", "") or "")
    run_projection = _run_projection(deps, session_id, run_id)
    complete_or_block_work_item(
        deps,
        frame,
        event,
        item,
        research_result=research_result,
        run_projection=run_projection,
    )
    if frame is None:
        sync_affinity_terminal_event(
            deps,
            event,
            request=None,
            run_id=str(event.get("run_id") or ""),
            project_text=project_text,
            run_projection=run_projection,
        )
        return
    maybe_sync_continuity(deps, frame, event, run_projection=run_projection)
    maybe_sync_work_queue(deps, frame, event, run_projection=run_projection)
    maybe_kick_sleep(deps, frame, event, run_projection=run_projection)


def maybe_sync_continuity(
    deps: GhostTaskPolicyDeps,
    frame: RunFrame,
    event: dict[str, object],
    *,
    run_projection: Any = None,
) -> None:
    store = getattr(deps.state, "ghost_continuity", None)
    if store is None:
        return
    mode = str(event.get("mode") or "")
    if mode not in {"chat", "planning"}:
        return
    if not _ghost_learning_enabled(deps.state):
        try:
            deps.state.emit({
                "type": "ghost_continuity_done",
                "run_id": frame.run_id,
                "session_id": frame.request.session_id,
                "ok": True,
                "skipped_reason": "learning_disabled",
                "items_changed": 0,
                "total_items": 0,
                "warnings": [],
            })
        except Exception as exc:
            _record_ghost_warning(
                deps,
                "continuity_learning_disabled_emit",
                exc,
                frame=frame,
                event=event,
            )
        return
    try:
        result = store.sync_from_sources(
            hebbian_store=getattr(deps.state, "ghost_hebbian", None),
            run_projection=run_projection,
            knowledge_store=deps.knowledge_store,
            user_focus_excerpt=frame.request.task,
            session_id=frame.request.session_id,
            run_id=frame.run_id,
            project=frame.project_text if mode != "chat" else "",
            mode=mode,
        )
        deps.state.emit(result.to_event(run_id=frame.run_id, session_id=frame.request.session_id))
    except Exception as exc:
        _record_ghost_warning(deps, "continuity_sync", exc, frame=frame, event=event)
        return


def maybe_kick_sleep(
    deps: GhostTaskPolicyDeps,
    frame: RunFrame,
    event: dict[str, object],
    *,
    run_projection: Any = None,
) -> None:
    if str(event.get("stop_reason") or "") != "done":
        return
    kick = getattr(deps.state, "kick_ghost_sleep", None)
    if not callable(kick):
        return
    try:
        kick(
            trigger="post_turn",
            run_id=frame.run_id,
            session_id=frame.request.session_id,
            project=frame.project_text,
            run_projection=run_projection,
        )
    except Exception as exc:
        _record_ghost_warning(deps, "sleep_kick", exc, frame=frame, event=event)
        return


def maybe_sync_work_queue(
    deps: GhostTaskPolicyDeps,
    frame: RunFrame,
    event: dict[str, object],
    *,
    run_projection: Any = None,
) -> None:
    store = getattr(deps.state, "ghost_work_queue", None)
    affinity_store = ghost_affinity_store(deps.state)
    if store is None and affinity_store is None:
        return
    if not _ghost_learning_enabled(deps.state):
        return
    scope = frame.request.project or ""
    try:
        research_interest_candidates = build_research_interest_candidates(
            deps.knowledge_store,
            session_id=frame.request.session_id,
            project=scope,
        )
        if affinity_store is not None and research_interest_candidates:
            hints = affinity_store.query_research_priority_hints(
                research_interest_candidates,
                session_id=frame.request.session_id,
                project=scope,
            )
            research_interest_candidates = apply_research_affinity_hints(
                research_interest_candidates,
                hints,
            )
        if store is not None:
            store.sync_from_sources(
                continuity_store=getattr(deps.state, "ghost_continuity", None),
                work_checkpoint_store=deps.work_checkpoints,
                run_projection=run_projection,
                terminal_event=event,
                research_interest_candidates=research_interest_candidates,
                session_id=frame.request.session_id,
                run_id=frame.run_id,
                project=scope,
            )
        if affinity_store is not None:
            affinity_store.sync_from_sources(
                hebbian_store=getattr(deps.state, "ghost_hebbian", None),
                work_queue_store=store,
                research_interest_candidates=research_interest_candidates,
                run_projection=run_projection,
                terminal_event=event,
                session_id=frame.request.session_id,
                project=scope,
            )
    except Exception as exc:
        _record_ghost_warning(deps, "work_queue_sync", exc, frame=frame, event=event)
        return


def sync_affinity_terminal_event(
    deps: GhostTaskPolicyDeps,
    event: dict[str, object],
    *,
    request: Any | None,
    run_id: str,
    project_text: str,
    run_projection: Any = None,
) -> None:
    affinity_store = ghost_affinity_store(deps.state)
    if affinity_store is None:
        return
    session_id = str(event.get("session_id") or getattr(request, "session_id", "") or "")
    try:
        affinity_store.sync_from_sources(
            hebbian_store=getattr(deps.state, "ghost_hebbian", None),
            work_queue_store=getattr(deps.state, "ghost_work_queue", None),
            run_projection=run_projection,
            terminal_event=event,
            session_id=session_id,
            project=project_text,
        )
    except Exception as exc:
        _record_ghost_warning(deps, "affinity_sync", exc, event=event, request=request, run_id=run_id)
        return


def complete_or_block_work_item(
    deps: GhostTaskPolicyDeps,
    frame: RunFrame | None,
    event: dict[str, object],
    item: GhostWorkItem | None,
    *,
    research_result: Any = None,
    run_projection: Any = None,
) -> None:
    if item is None:
        return
    store = getattr(deps.state, "ghost_work_queue", None)
    if store is None:
        return
    try:
        run_id = str(event.get("run_id") or item.started_run_id or "")
        if frame is None:
            if str(event.get("stop_reason") or "") != "done":
                store.block_item(
                    item.id,
                    run_id=run_id,
                    blocked_reason=str(event.get("stop_reason") or "run_not_done"),
                )
            return
        if str(event.get("stop_reason") or "") == "done":
            if item.kind in RESEARCH_QUEUE_KINDS:
                decision = ResearchCompletionGate(deps.evidence_ledgers).evaluate(
                    item=item,
                    event=event,
                    research_result=research_result,
                    session_id=frame.request.session_id,
                    project=frame.project_text,
                )
                if deps.record_completion_proof_trace is not None:
                    deps.record_completion_proof_trace(frame.trace, decision.proof)
                if decision.complete:
                    store.complete_item(
                        item.id,
                        run_id=frame.run_id,
                        proof_refs=decision.proof_refs,
                    )
                else:
                    record_research_proof_review_trace(frame.trace, decision.review)
                    record_research_plan_trace(
                        frame.trace,
                        decision.review,
                        question=research_queue_item_title(item) or frame.request.task,
                    )
                    store.block_item(
                        item.id,
                        run_id=frame.run_id,
                        blocked_reason=decision.blocked_reason or "research_proof_failed",
                    )
            else:
                store.complete_item(
                    item.id,
                    run_id=frame.run_id,
                    proof_refs=proof_refs_from_task_event(
                        item,
                        event,
                        run_projection=run_projection,
                    ),
                )
        else:
            store.block_item(
                item.id,
                run_id=frame.run_id,
                blocked_reason=str(event.get("stop_reason") or "run_not_done"),
            )
    except Exception as exc:
        _record_ghost_warning(deps, "work_completion", exc, frame=frame, event=event)
        return


def _ghost_learning_enabled(state: TaskState) -> bool:
    inbox_store = getattr(state, "ghost_inbox", None)
    if inbox_store is None:
        return True
    try:
        return bool(inbox_store.learning_enabled())
    except Exception:
        return False


def _record_ghost_warning(
    deps: GhostTaskPolicyDeps,
    stage: str,
    exc: Exception,
    *,
    frame: RunFrame | None = None,
    event: dict[str, object] | None = None,
    request: Any | None = None,
    run_id: str = "",
) -> None:
    emit = getattr(deps.state, "emit", None)
    if not callable(emit):
        return
    source_event = event or {}
    request = request or getattr(frame, "request", None)
    session_id = str(
        source_event.get("session_id")
        or getattr(request, "session_id", "")
        or ""
    )
    resolved_run_id = str(
        source_event.get("run_id")
        or run_id
        or getattr(frame, "run_id", "")
        or ""
    )
    error_text = f"{stage}:{type(exc).__name__}:{exc}"
    try:
        emit({
            "type": "ghost_post_turn_warning",
            "stage": str(stage or "unknown"),
            "run_id": resolved_run_id,
            "session_id": session_id,
            "error_type": type(exc).__name__,
            "error_ref": digest_text(error_text)[:24],
        })
    except Exception:
        return


def _run_projection(deps: GhostTaskPolicyDeps, session_id: str, run_id: str) -> Any:
    if deps.run_ledgers is None:
        return None
    try:
        projection = load_run_projection(deps.run_ledgers, session_id, run_id)
    except Exception as exc:
        _record_ghost_warning(
            deps, "ledger_incomplete", exc,
            event={"session_id": session_id, "run_id": run_id},
            run_id=run_id,
        )
        return None
    if projection is None:
        # Distinguish "no ledger yet" from "file exists but unreadable":
        # only the latter means Ghost would learn from an incomplete stream.
        try:
            ledger_path = deps.run_ledgers.path_for(session_id, run_id)
        except Exception:
            return None
        try:
            exists = ledger_path.is_file()
        except OSError:
            exists = False
        if exists:
            _record_ghost_warning(
                deps, "ledger_incomplete",
                ValueError("ledger file present but projection unavailable"),
                event={"session_id": session_id, "run_id": run_id},
                run_id=run_id,
            )
        return None
    if not projection.complete:
        _record_ghost_warning(
            deps, "ledger_incomplete",
            ValueError("ledger projection incomplete"),
            event={"session_id": session_id, "run_id": run_id},
            run_id=run_id,
        )
        return None
    return projection


__all__ = [
    "GhostTaskPolicyDeps",
    "complete_or_block_work_item",
    "maybe_sync_work_queue",
    "maybe_claim_work_item",
    "release_work_item",
    "run_ghost_post_turn",
    "sync_affinity_terminal_event",
]
