"""Bounded local file traversal helpers.

This module only walks file paths. It does not read file contents, build an
index, cache results, or infer semantics.
"""

from __future__ import annotations

import stat
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass
from pathlib import Path

from codey.runtime.core import cancellation

DEFAULT_MAX_SCAN_FILES = 1_000
DEFAULT_MAX_SCAN_DIRS = 250
DEFAULT_MAX_DIR_ENTRIES = 1_000


@dataclass
class BoundedScanBudget:
    max_files: int = DEFAULT_MAX_SCAN_FILES
    max_dirs: int = DEFAULT_MAX_SCAN_DIRS
    max_dir_entries: int = DEFAULT_MAX_DIR_ENTRIES
    max_bytes: int | None = None
    files_seen: int = 0
    dirs_seen: int = 0
    bytes_seen: int = 0
    file_limited: bool = False
    dir_limited: bool = False
    entry_limited: bool = False
    byte_limited: bool = False
    read_failed: bool = False

    @property
    def limited(self) -> bool:
        return (
            self.file_limited
            or self.dir_limited
            or self.entry_limited
            or self.byte_limited
        )

    def stop_message(self, label: str) -> str:
        reasons: list[str] = []
        if self.file_limited:
            reasons.append(f"file budget {self.max_files}")
        if self.dir_limited:
            reasons.append(f"directory budget {self.max_dirs}")
        if self.entry_limited:
            reasons.append(f"per-directory entry budget {self.max_dir_entries}")
        if self.byte_limited and self.max_bytes is not None:
            reasons.append(f"byte budget {self.max_bytes}")
        reason = ", ".join(reasons) if reasons else "scan budget"
        scanned = f"{self.files_seen} files and {self.dirs_seen} directories"
        if self.max_bytes is not None:
            scanned += f", {self.bytes_seen} bytes"
        return (
            f"- {label} stopped after {scanned} ({reason}); omitted files may "
            "contain more matches"
        )

    def consume_file(self, path: Path) -> bool:
        if self.files_seen >= self.max_files:
            self.file_limited = True
            return False
        try:
            info = path.lstat()
        except OSError:
            self.read_failed = True
            return False
        if stat.S_ISLNK(info.st_mode):
            return False
        size = 0
        if self.max_bytes is not None:
            size = info.st_size
            if self.bytes_seen + size > self.max_bytes:
                self.byte_limited = True
                return False
        self.files_seen += 1
        self.bytes_seen += size
        return True


def iter_provided_files(
    files: Iterable[Path],
    budget: BoundedScanBudget,
) -> Iterator[Path]:
    for path in files:
        cancellation.check()
        if not budget.consume_file(path):
            if budget.limited:
                return
            continue
        yield path


def _start_entry_kind(start: Path) -> str:
    try:
        start_mode = start.lstat().st_mode
    except OSError:
        return "missing"
    if stat.S_ISLNK(start_mode):
        return "symlink"
    if stat.S_ISREG(start_mode):
        return "file"
    if stat.S_ISDIR(start_mode):
        return "dir"
    return "other"


def _collect_dir_entries(
    current: Path,
    excluded_lower: set[str],
    budget: BoundedScanBudget,
) -> list[Path]:
    entries: list[Path] = []
    raw_seen = 0
    raw_cap = max(budget.max_dir_entries * 4, budget.max_dir_entries + 100)
    try:
        for entry in current.iterdir():
            cancellation.check()
            raw_seen += 1
            if entry.name.lower() in excluded_lower:
                if raw_seen >= raw_cap:
                    budget.entry_limited = True
                    break
                continue
            if len(entries) >= budget.max_dir_entries:
                budget.entry_limited = True
                break
            entries.append(entry)
            if raw_seen >= raw_cap:
                budget.entry_limited = True
                break
    except OSError:
        budget.read_failed = True
        return entries
    return entries


def _partition_sorted_entries(
    entries: list[Path],
    *,
    excluded_lower: set[str],
    allow_dir: Callable[[Path], bool] | None,
    allow_file: Callable[[Path], bool] | None,
    budget: BoundedScanBudget,
) -> tuple[list[Path], list[Path], bool]:
    dirs: list[Path] = []
    yielded: list[Path] = []
    for entry in sorted(entries, key=lambda path: path.name.lower()):
        cancellation.check()
        try:
            entry_mode = entry.lstat().st_mode
            if stat.S_ISLNK(entry_mode):
                continue
            if stat.S_ISDIR(entry_mode):
                if entry.name.lower() in excluded_lower:
                    continue
                if allow_dir is not None and not allow_dir(entry):
                    continue
                dirs.append(entry)
            elif stat.S_ISREG(entry_mode):
                if allow_file is not None and not allow_file(entry):
                    continue
                if not budget.consume_file(entry):
                    if budget.limited:
                        return dirs, yielded, True
                    continue
                yielded.append(entry)
        except OSError:
            budget.read_failed = True
            continue
    return dirs, yielded, False


def iter_bounded_files(
    start: Path,
    *,
    excluded_dirs: set[str],
    budget: BoundedScanBudget,
    allow_dir: Callable[[Path], bool] | None = None,
    allow_file: Callable[[Path], bool] | None = None,
    skip_start_if_excluded: bool = True,
) -> Iterator[Path]:
    cancellation.check()
    excluded_lower = {name.lower() for name in excluded_dirs}
    start_kind = _start_entry_kind(start)
    if start_kind in ("missing", "symlink", "other"):
        return
    if start_kind == "file":
        if allow_file is not None and not allow_file(start):
            return
        if not budget.consume_file(start):
            return
        yield start
        return
    if skip_start_if_excluded and start.name.lower() in excluded_lower:
        return

    stack = [start]
    while stack:
        cancellation.check()
        current = stack.pop()
        if budget.dirs_seen >= budget.max_dirs:
            budget.dir_limited = True
            return
        budget.dirs_seen += 1
        entries = _collect_dir_entries(current, excluded_lower, budget)

        dirs, yielded, stop = _partition_sorted_entries(
            entries,
            excluded_lower=excluded_lower,
            allow_dir=allow_dir,
            allow_file=allow_file,
            budget=budget,
        )
        yield from yielded
        if stop:
            return
        stack.extend(reversed(dirs))
