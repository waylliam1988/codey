"""Research domain tool contracts, projected into the shared ToolSpec registry."""

from __future__ import annotations

import builtins
import math
from dataclasses import dataclass, field
from typing import Any

PROTOCOL_NO_JSON = "no_json"
PROTOCOL_UNKNOWN_TOOL = "unknown_tool"
PROTOCOL_TOO_MANY_TOOLS = "too_many_tools"
PROTOCOL_INVALID_ARGS = "invalid_args"
PROTOCOL_DIRECT_ANSWER = "direct_answer"
PROTOCOL_NATIVE_SEARCH_LEAK = "native_search_leak"
PROTOCOL_DISALLOWED_TOOL = "disallowed_tool"

def knowledge_read_id_guidance(*, source_tool: str = "") -> str:
    source = f" by {source_tool}" if source_tool else ""
    return (
        f"For knowledge_read, pass the note id exactly as returned{source}; "
        "do not prepend facts/ or append .md."
    )


@dataclass(frozen=True)
class ToolArg:
    type: builtins.type[Any]
    default: Any = None
    singleton_dict: bool = False
    list_item_type: builtins.type[Any] | None = None


@dataclass(frozen=True)
class ToolContract:
    name: str
    required: dict[str, type] = field(default_factory=dict)
    optional: dict[str, ToolArg] = field(default_factory=dict)
    example: str = ""
    description: str = ""


@dataclass(frozen=True)
class ContractResult:
    ok: bool
    args: dict[str, Any] = field(default_factory=dict)
    error: str = ""
    error_kind: str = ""


TOOL_CONTRACTS = {
    "web_search": ToolContract(
        name="web_search",
        required={"query": str},
        example='{"tool":"web_search","args":{"query":"..."}}',
        description="search the web for ranked results",
    ),
    "open_url": ToolContract(
        name="open_url",
        required={"url": str},
        optional={
            "offset": ToolArg(int, 0),
            "limit": ToolArg(int, 6000),
            "pages": ToolArg(str, ""),
        },
        example='{"tool":"open_url","args":{"url":"https://...","offset":0,"limit":6000,"pages":"1-5"}}',
        description="read a page's text; for PDFs, pages selects bounded page ranges",
    ),
    "source_search": ToolContract(
        name="source_search",
        required={"url": str, "query": str},
        optional={"limit": ToolArg(int, 6)},
        example='{"tool":"source_search","args":{"url":"https://...","query":"...","limit":6}}',
        description="search within a source already opened with open_url; returns locators, offsets, and PDF pages",
    ),
    "knowledge_search": ToolContract(
        name="knowledge_search",
        required={"query": str},
        example='{"tool":"knowledge_search","args":{"query":"..."}}',
        description="search your existing local notes FIRST",
    ),
    "knowledge_read": ToolContract(
        name="knowledge_read",
        required={"id": str},
        example='{"tool":"knowledge_read","args":{"id":"<note id>"}}',
        description="read one existing note in full. " + knowledge_read_id_guidance(),
    ),
    "knowledge_write": ToolContract(
        name="knowledge_write",
        required={"type": str, "title": str, "body": str},
        optional={
            "id": ToolArg(str, ""),
            "sources": ToolArg(list, None),
            "tags": ToolArg(list, None),
            "aliases": ToolArg(list, None),
            "relations": ToolArg(list, None, singleton_dict=True, list_item_type=dict),
            "evidence": ToolArg(list, None, singleton_dict=True, list_item_type=dict),
            "open_questions": ToolArg(list, None, singleton_dict=True, list_item_type=str),
            "confidence": ToolArg(float, None),
            "retrieved_at": ToolArg(str, None),
            "valid_until": ToolArg(str, None),
            "status": ToolArg(str, "active"),
        },
        example='{"tool":"knowledge_write","args":{"type":"fact","title":"...","body":"...","tags":["..."],"sources":["https://..."],"relations":[{"src":"war","dst":"helium supply","kind":"affects"}],"evidence":[{"claim":"...","source_url":"https://...","excerpt":"exact short text copied from open_url output","stance":"supports"}],"confidence":0.6,"valid_until":"2026-12-31","status":"active"}}',
        description="save small source/fact/hypothesis/conclusion/question notes; final reports must use done",
    ),
    "knowledge_link": ToolContract(
        name="knowledge_link",
        required={"src": str, "dst": str},
        optional={"kind": ToolArg(str, "relates")},
        example='{"tool":"knowledge_link","args":{"src":"<note id>","dst":"<note id or exact title>","kind":"supports"}}',
        description="",
    ),
    "done": ToolContract(
        name="done",
        required={"summary": str},
        optional={"open_questions": ToolArg(list, None, singleton_dict=True, list_item_type=str)},
        example='{"tool":"done","args":{"summary":"<the full human-readable report>","open_questions":["<bounded follow-up research question>"]}}',
        description="",
    ),
}


def research_tool_names(*, include_source_search: bool = True) -> tuple[str, ...]:
    base = (
        "web_search",
        "open_url",
        "knowledge_search",
        "knowledge_read",
        "knowledge_write",
        "knowledge_link",
        "done",
    )
    if not include_source_search:
        return base
    # source_search is inserted after open_url to match the system prompt order
    return (
        "web_search",
        "open_url",
        "source_search",
        "knowledge_search",
        "knowledge_read",
        "knowledge_write",
        "knowledge_link",
        "done",
    )


def render_research_tool_contract_text(*, include_source_search: bool = True) -> str:
    lines: list[str] = []
    for name in research_tool_names(include_source_search=include_source_search):
        contract = TOOL_CONTRACTS[name]
        example = contract.example
        description = contract.description
        if description:
            lines.append(f"- {example}  {description}")
        else:
            lines.append(f"- {example}")
    return "\n".join(lines)


def research_tool_contract_hash(*, include_source_search: bool = True) -> str:
    from codey.toolchain.tool_prompt import model_visible_contract_hash

    return model_visible_contract_hash(
        "research_tool_contract",
        render_research_tool_contract_text(include_source_search=include_source_search),
    )


def _json_type(pytype: type) -> str:
    if pytype is str:
        return "string"
    if pytype is int:
        return "integer"
    if pytype is float:
        return "number"
    if pytype is list:
        return "array"
    return "string"


def openai_parameters_schema(tool: str) -> dict[str, object]:
    contract = TOOL_CONTRACTS.get(tool)
    if contract is None:
        return {"type": "object", "properties": {}, "additionalProperties": False}
    properties: dict[str, object] = {}
    for name, expected in contract.required.items():
        properties[name] = {"type": _json_type(expected)}
    for name, arg in contract.optional.items():
        properties[name] = {"type": _json_type(arg.type)}
    return {
        "type": "object",
        "properties": properties,
        "required": sorted(contract.required.keys()),
        "additionalProperties": False,
    }


def render_openai_tools(*, include_source_search: bool = True) -> list[dict[str, object]]:
    tools: list[dict[str, object]] = []
    for name in research_tool_names(include_source_search=include_source_search):
        contract = TOOL_CONTRACTS[name]
        tools.append(
            {
                "type": "function",
                "function": {
                    "name": name,
                    "description": contract.description or contract.example,
                    "parameters": openai_parameters_schema(name),
                },
            }
        )
    def tool_name(item: dict[str, object]) -> str:
        function = item.get("function")
        return str(function.get("name") or "") if isinstance(function, dict) else ""

    tools.sort(key=tool_name)
    return tools


def validate_tool_args(tool: str, args: dict[str, Any]) -> ContractResult:
    contract = TOOL_CONTRACTS.get(tool)
    if contract is None:
        return ContractResult(False, error=f"unknown tool: {tool}", error_kind=PROTOCOL_UNKNOWN_TOOL)
    normalized = dict(args)
    output: dict[str, Any] = {}
    for name, expected in contract.required.items():
        if name not in normalized:
            return _invalid(f"{tool} missing required arg '{name}'")
        coerced = _coerce(tool, name, normalized[name], expected, required=True)
        if not coerced.ok:
            return coerced
        output[name] = coerced.args[name]
    for name, arg in contract.optional.items():
        if name not in normalized:
            if arg.default is not None:
                output[name] = arg.default
            continue
        coerced = _coerce(
            tool,
            name,
            normalized[name],
            arg.type,
            required=False,
            singleton_dict=arg.singleton_dict,
            list_item_type=arg.list_item_type,
        )
        if not coerced.ok:
            return coerced
        output[name] = coerced.args[name]
    if tool == "knowledge_write" and str(output.get("type") or "").strip().lower() == "synthesis":
        return _invalid("done required for final synthesis; knowledge_write.type must not be 'synthesis'")
    return ContractResult(True, args=output)


def tool_example(tool: str) -> str:
    # Single source: the static Tools: block and all dynamic repair /
    # controller allowed-action examples render from ToolContract examples.
    # Unknown tools fall back to the web_search shape (explicit repair policy).
    contract = TOOL_CONTRACTS.get(tool)
    if contract is not None:
        return contract.example
    return TOOL_CONTRACTS["web_search"].example


def _coerce(
    tool: str,
    name: str,
    value: Any,
    expected: type,
    *,
    required: bool,
    singleton_dict: bool = False,
    list_item_type: type | None = None,
) -> ContractResult:
    if expected is str:
        text = _coerce_str(value)
        if required and not text:
            return _invalid(f"{tool}.{name} must be a non-empty string")
        return ContractResult(True, args={name: text})
    if expected is int:
        parsed = _coerce_int(value)
        if parsed is None:
            return _invalid(f"{tool}.{name} must be an integer")
        return ContractResult(True, args={name: parsed})
    if expected is float:
        parsed_float = _coerce_float(value)
        if parsed_float is None:
            return _invalid(f"{tool}.{name} must be a number")
        return ContractResult(True, args={name: parsed_float})
    if expected is list:
        parsed_list = _coerce_list(value, singleton_dict=singleton_dict)
        if parsed_list is None:
            return _invalid(f"{tool}.{name} must be a list")
        if list_item_type is not None and not all(
            isinstance(item, list_item_type) for item in parsed_list
        ):
            if list_item_type is dict:
                return _invalid(f"{tool}.{name} must be a list of objects")
            return _invalid(f"{tool}.{name} has invalid list item type")
        return ContractResult(True, args={name: parsed_list})
    return ContractResult(True, args={name: value})


def _coerce_str(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (list, tuple)):
        for item in value:
            text = _coerce_str(item)
            if text:
                return text
        return ""
    if value is None or isinstance(value, (dict, set)):
        return ""
    return str(value).strip()


def _coerce_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            return None
        return int(value) if value.is_integer() else None
    if isinstance(value, str):
        text = value.strip()
        if not text or not text.isascii():
            return None
        try:
            return int(text)
        except ValueError:
            return None
    return None


def _coerce_float(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        try:
            number = float(value)
        except OverflowError:
            return None
        return number if math.isfinite(number) else None
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            number = float(text)
        except ValueError:
            return None
        return number if math.isfinite(number) else None
    return None


def _coerce_list(value: Any, *, singleton_dict: bool = False) -> list[Any] | None:
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if singleton_dict and isinstance(value, dict):
        return [value]
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    return None


def _invalid(message: str) -> ContractResult:
    return ContractResult(False, error=message, error_kind=PROTOCOL_INVALID_ARGS)
