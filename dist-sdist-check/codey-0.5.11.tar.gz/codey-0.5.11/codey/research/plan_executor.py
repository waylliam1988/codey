"""Bounded execution for deterministic Research plans."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from codey.policies.network import check_fetch_url
from codey.research.context import ResearchPipelineConfig
from codey.research.guards import bounded_int as _bounded_int
from codey.research.query_planner import ResearchPlan
from codey.research.tools import ResearchTools, clone_research_tools
from codey.research.url_selection import source_candidate_skip_reason
from codey.research.urls import opened_url
from codey.runtime.core import cancellation
from codey.utils.refs import clip


@dataclass(frozen=True)
class PlanExecutionResult:
    queries_executed: tuple[str, ...] = ()
    opened_sources: tuple[dict[str, Any], ...] = ()
    previews: tuple[str, ...] = ()
    fresh_source_urls: tuple[str, ...] = ()
    fresh_source_count: int = 0
    baseline_source_urls: tuple[str, ...] = ()
    skipped_count: int = 0
    stop_reason: str = ""
    errors: tuple[str, ...] = ()

    @property
    def has_new_material(self) -> bool:
        return bool(self.fresh_source_urls)


@dataclass
class _PlanExecutionState:
    queries: list[str]
    opened: list[dict[str, Any]]
    previews: list[str]
    fresh_urls: list[str]
    errors: list[str]
    skipped: int
    seen_urls: set[str]
    baseline_urls: set[str]
    stop_reason: str


class PlanExecutor:
    def __init__(
        self,
        *,
        config: ResearchPipelineConfig | None = None,
        should_stop: Callable[[], bool] | None = None,
    ) -> None:
        self.config = config or ResearchPipelineConfig()
        self.should_stop = should_stop or (lambda: False)

    def execute(
        self, plan: ResearchPlan, tools: ResearchTools, *, policy: object,
    ) -> PlanExecutionResult:
        """Execute one deterministic plan under the parent task policy.

        ``policy`` is required: a missing or non-allowing policy denies the
        whole plan (fail-closed). System searches/opens are read-only and
        stay inside this deterministic episode — they never mint kernel tool
        intents (single episode ownership: only the model tool loop drives
        the durable intent/delivery machine), but every action rechecks the
        same parent grant before running.
        """
        baseline_urls = _collect_baseline_urls(tools)
        if not _policy_allows(policy, "web.read"):
            return PlanExecutionResult(
                queries_executed=(),
                opened_sources=(),
                previews=(),
                fresh_source_urls=(),
                fresh_source_count=0,
                baseline_source_urls=tuple(sorted(baseline_urls)),
                skipped_count=0,
                stop_reason="policy_denied",
                errors=("policy denied web.read for research plan execution",),
            )
        runtime = clone_research_tools(tools)
        state = _PlanExecutionState(
            queries=[],
            opened=[],
            previews=[],
            fresh_urls=[],
            errors=[],
            skipped=0,
            seen_urls=set(baseline_urls),
            baseline_urls=baseline_urls,
            stop_reason="no_queries",
        )
        query_limit, total_limit, per_query_limit = self._execution_limits(plan)
        for candidate in plan.query_candidates[:query_limit]:
            if self._is_stopped():
                state.stop_reason = "stopped"
                break
            if len(state.opened) >= total_limit or total_limit <= 0 or per_query_limit <= 0:
                state.stop_reason = "max_sources"
                break
            query = " ".join(str(candidate.query_preview or "").split())
            if not query:
                state.skipped += 1
                continue
            if not _policy_allows(policy, "web.read"):
                state.stop_reason = "policy_denied"
                state.errors.append("policy denied web.read for research plan execution")
                break
            before_searches = len(runtime.ledger.searches)
            result = runtime.web_search(query)
            state.queries.append(query)
            if not result.ok:
                state.errors.append(_safe_error(result.model_text))
                state.stop_reason = "search_error"
                continue
            search = runtime.ledger.searches[-1] if len(runtime.ledger.searches) > before_searches else None
            if search is None:
                state.stop_reason = "no_results"
                continue
            self._drain_search_hits(runtime, search, query, state, total_limit, per_query_limit, policy=policy)

            if state.stop_reason in {"max_sources", "stopped"}:
                break
        state.stop_reason = self._finalize_stop_reason(state, total_limit)
        return PlanExecutionResult(
            queries_executed=tuple(state.queries),
            opened_sources=tuple(state.opened),
            previews=tuple(state.previews),
            fresh_source_urls=tuple(state.fresh_urls),
            fresh_source_count=len(state.fresh_urls),
            baseline_source_urls=tuple(sorted(state.baseline_urls)),
            skipped_count=state.skipped,
            stop_reason=state.stop_reason,
            errors=tuple(state.errors[:12]),
        )

    def _execution_limits(self, plan: ResearchPlan) -> tuple[int, int, int]:
        query_limit = min(
            _bounded_int(
                plan.max_queries,
                default=self.config.max_queries_per_round,
                lower=0,
                upper=8,
            ),
            _bounded_int(
                self.config.max_queries_per_round,
                default=self.config.max_queries_per_round,
                lower=0,
                upper=8,
            ),
        )
        total_limit = min(
            _bounded_int(
                plan.max_sources,
                default=self.config.max_total_sources,
                lower=0,
                upper=12,
            ),
            _bounded_int(
                self.config.max_total_sources,
                default=self.config.max_total_sources,
                lower=0,
                upper=12,
            ),
        )
        per_query_limit = _bounded_int(
            self.config.max_sources_per_query,
            default=2,
            lower=0,
            upper=8,
        )
        return query_limit, total_limit, per_query_limit

    def _drain_search_hits(
        self,
        runtime: ResearchTools,
        search: Any,
        query: str,
        state: _PlanExecutionState,
        total_limit: int,
        per_query_limit: int,
        *,
        policy: object,
    ) -> None:
        opened_for_query = 0
        for hit in search.results:
            if len(state.opened) >= total_limit:
                state.stop_reason = "max_sources"
                break
            if opened_for_query >= per_query_limit:
                break
            url = str(hit.url or "").strip()
            if not url or url in state.seen_urls:
                state.skipped += 1
                continue
            skip_reason = source_candidate_skip_reason(url)
            if skip_reason:
                state.seen_urls.add(url)
                state.skipped += 1
                state.errors.append(_safe_error(skip_reason))
                continue
            pre_canonical = runtime.ledger.canonical_opened_url(url)
            if pre_canonical and (pre_canonical in state.seen_urls or pre_canonical in state.baseline_urls or pre_canonical in state.fresh_urls):
                state.seen_urls.add(url)
                state.skipped += 1
                continue
            state.seen_urls.add(url)
            reason = check_fetch_url(url)

            if reason:
                state.skipped += 1
                state.errors.append(_safe_error(reason))
                continue
            if not _policy_allows(policy, "web.read"):
                state.skipped += 1
                state.errors.append("policy denied web.read for source open")
                continue
            before_opened = set(runtime.ledger.final_url_set())
            try:
                opened = runtime.open_url(
                    url,
                    limit=self.config.max_source_preview_chars,
                )
            except cancellation.TaskCancelled:
                raise
            if self._is_stopped():
                state.stop_reason = "stopped"
                break
            text = opened.model_text
            if not opened.ok:
                state.skipped += 1
                state.errors.append(_safe_error(text))
                continue
            after_opened = set(runtime.ledger.final_url_set())
            new_urls = sorted(after_opened - before_opened)
            canonical_final = (
                runtime.ledger.canonical_opened_url(new_urls[-1])
                if new_urls
                else runtime.ledger.canonical_opened_url(url)
            ) or url
            state.seen_urls.add(canonical_final)
            final_skip_reason = source_candidate_skip_reason(canonical_final)
            if final_skip_reason:
                state.skipped += 1
                state.errors.append(_safe_error(final_skip_reason + " after redirect"))
                continue
            if canonical_final in state.baseline_urls or canonical_final in state.fresh_urls:
                state.skipped += 1
                continue
            opened_for_query += 1
            source = _opened_source_payload(runtime, canonical_final)
            if source:
                state.opened.append(source)
            state.fresh_urls.append(canonical_final)
            state.previews.append(_source_preview(query, source, text, self.config.max_source_preview_chars))
            state.stop_reason = "opened_sources"

    def _finalize_stop_reason(self, state: _PlanExecutionState, total_limit: int) -> str:
        stop_reason = state.stop_reason
        if stop_reason == "opened_sources" and len(state.opened) >= total_limit:
            stop_reason = "max_sources"
        if stop_reason in {"no_queries", "opened_sources"} and state.queries and not state.fresh_urls:
            stop_reason = "no_new_material"
        return stop_reason

    def _is_stopped(self) -> bool:
        if self.should_stop():
            return True
        cancellation.check()
        return False



def _collect_baseline_urls(tools: ResearchTools) -> set[str]:
    baseline: set[str] = set()
    for url in tools.sources_read:
        if str(url or "").strip():
            baseline.add(str(url).strip())
    for url in tools.ledger.final_url_set():
        if str(url or "").strip():
            baseline.add(str(url).strip())
    for opened in tools.ledger.opened_sources:
        if str(opened.final_url or "").strip():
            baseline.add(str(opened.final_url).strip())
        if str(opened.requested_url or "").strip():
            baseline.add(str(opened.requested_url).strip())
    for ev in tools.ledger.evidence_items:
        if str(ev.source_url or "").strip():
            baseline.add(str(ev.source_url).strip())
    return baseline


def _opened_source_payload(tools: ResearchTools, url: str) -> dict[str, Any]:
    final_url = opened_url(tools.ledger, url)
    for item in tools.ledger.opened_sources:
        if item.final_url == final_url or item.requested_url == final_url:
            return item.to_dict()
    return {}


def _source_preview(query: str, source: dict[str, Any], body: str, limit: int) -> str:
    title = str(source.get("title") or "").strip()
    final_url = str(source.get("final_url") or source.get("url") or "").strip()
    header = " | ".join(part for part in (title, final_url) if part)
    text = clip(str(body or ""), max(500, min(4000, int(limit or 0))))
    return "\n".join(part for part in (f"query: {query}", header, text) if part)


def _safe_error(value: object) -> str:
    return clip(" ".join(str(value or "").split()), 180)


def _policy_allows(policy: object, grant: str) -> bool:
    allows = getattr(policy, "allows", None)
    if not callable(allows):
        return False
    try:
        return bool(allows(grant))
    except Exception:
        return False


__all__ = [
    "PlanExecutionResult",
    "PlanExecutor",
]
