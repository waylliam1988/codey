"""Shared query-term routing hints for Research source connectors.

Term tables only (which query words prefer pubmed/arxiv).
Host-trust tables live in ``source_domains``; the similar historical name
(``connector_domains``) was renamed to end the confusion.
"""

from __future__ import annotations

from typing import Any

MEDICAL_CONNECTOR_TERMS = frozenset({
    "biomedical",
    "cancer",
    "clinical",
    "disease",
    "drug",
    "gene",
    "genetic",
    "genetics",
    "genomic",
    "genomics",
    "life",
    "life_science",
    "medicine",
    "patient",
    "pharma",
    "protein",
    "pubmed",
    "therapy",
    "trial",
    "vaccine",
    "医学",
    "临床",
    "疾病",
    "基因",
    "蛋白",
    "疫苗",
    "药物",
    "生命科学",
    "肿瘤",
    "癌症",
})
ARXIV_CONNECTOR_TERMS = frozenset({
    "algorithm",
    "arxiv",
    "benchmark",
    "computer",
    "diffusion",
    "learning",
    "llm",
    "machine",
    "math",
    "model",
    "neural",
    "nlp",
    "paper",
    "physics",
    "preprint",
    "quantum",
    "rag",
    "retrieval",
    "robotics",
    "transformer",
    "论文",
    "预印本",
    "机器学习",
    "模型",
    "算法",
    "物理",
})
def preferred_connector_ids(
    terms: object,
    *,
    available_ids: tuple[str, ...] = (),
) -> tuple[str, ...]:
    term_set = {str(item or "").casefold() for item in _iter_terms(terms)}
    available = set(available_ids)
    preferred: list[str] = []
    if "pubmed" in available and term_set & MEDICAL_CONNECTOR_TERMS:
        preferred.append("pubmed")
    if "arxiv" in available and term_set & ARXIV_CONNECTOR_TERMS:
        preferred.append("arxiv")
    return tuple(preferred)


def _iter_terms(value: object) -> Any:
    if isinstance(value, str):
        yield from value.split()
        return
    try:
        yield from value  # type: ignore[misc]
    except TypeError:
        text = str(value or "")
        if text:
            yield text


__all__ = [
    "ARXIV_CONNECTOR_TERMS",
    "MEDICAL_CONNECTOR_TERMS",
    "preferred_connector_ids",
]
