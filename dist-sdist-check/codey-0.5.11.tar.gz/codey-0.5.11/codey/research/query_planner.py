"""Deterministic Research follow-up query planner.

Planner v1 consumes proof-review gaps plus connector metadata and returns a
bounded plan. The planner itself does not execute searches, fetch sources, or
patch prompts; ResearchPipeline may use its bounded output as follow-up behavior
input.
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass

from codey.policies.redaction import looks_prompt_visible_secret, looks_sensitive_code
from codey.research.connector_terms import preferred_connector_ids
from codey.research.guards import bounded_int as _bounded_int
from codey.research.guards import (
    connector_id as _connector_id,
)
from codey.research.guards import (
    generated_ref as _generated_ref,
)
from codey.research.guards import (
    valid_digest_ref,
)
from codey.research.proof_quality import ResearchProofReview
from codey.research.source_connectors import (
    CONNECTOR_AVAILABLE_STATUSES,
    SourceConnectorRegistry,
    built_in_connector_registry,
    safe_connector_query_terms,
    safe_connector_signal_text,
)
from codey.utils.refs import (
    bounded_refs,
    clip,
    coerce_float,
    digest_text,
    identifier,
    stable_ref,
)

MAX_PLAN_QUERIES = 8
MAX_PLAN_SOURCES = 12
MAX_PLAN_REASON_CODES = 12
MAX_QUERY_PREVIEW_CHARS = 180
MAX_PLAN_WARNINGS = 12
DEFAULT_MAX_QUERIES = 4
DEFAULT_MAX_SOURCES = 6
PLAN_MAX_DEPTH = 1
_CONNECTOR_REASON_SCORES = {
    "pubmed": (1.0, ("medical_life_science_source",)),
    "arxiv": (0.95, ("paper_preprint_source",)),
}
_QUERY_CONTENT_STOP_TERMS = frozenset({
    "answer",
    "answers",
    "biomedical",
    "cited",
    "citation",
    "citations",
    "claim",
    "claims",
    "conclusion",
    "conclusions",
    "current",
    "direct",
    "evidence",
    "fact",
    "facts",
    "find",
    "fresh",
    "material",
    "materials",
    "opened",
    "primary",
    "question",
    "report",
    "reported",
    "research",
    "retrieved",
    "source",
    "sources",
    "supporting",
    "term",
    "terms",
    "unsupported",
    "use",
    "using",
})


@dataclass(frozen=True)
class QueryCandidate:
    query_id: str
    query_preview: str
    connector_ids: tuple[str, ...] = ()
    reason_codes: tuple[str, ...] = ()
    score: float = 0.0

    def to_payload(self) -> dict[str, object]:
        return {
            "query_id": _generated_ref(self.query_id, "research_query"),
            "query_digest": digest_text(self.query_preview),
            "query_preview": clip(self.query_preview, MAX_QUERY_PREVIEW_CHARS),
            "connector_ids": list(bounded_refs(self.connector_ids, limit=6)),
            "reason_codes": list(bounded_refs(self.reason_codes, limit=MAX_PLAN_REASON_CODES)),
            "score": _unit_float(self.score),
        }

    def to_trace_payload(self) -> dict[str, object]:
        return {
            "query_id": _generated_ref(self.query_id, "research_query"),
            "query_digest": digest_text(self.query_preview),
            "query_chars": len(self.query_preview),
            "connector_ids": list(bounded_refs(self.connector_ids, limit=6)),
            "reason_codes": list(bounded_refs(self.reason_codes, limit=MAX_PLAN_REASON_CODES)),
            "score": _unit_float(self.score),
        }


@dataclass(frozen=True)
class SourcePreference:
    connector_id: str
    reason_codes: tuple[str, ...] = ()
    score: float = 0.0

    def to_payload(self) -> dict[str, object]:
        return {
            "connector_id": _connector_id(self.connector_id),
            "reason_codes": list(bounded_refs(self.reason_codes, limit=MAX_PLAN_REASON_CODES)),
            "score": _unit_float(self.score),
        }


@dataclass(frozen=True)
class ResearchPlan:
    plan_ref: str
    question_digest: str = ""
    proof_ref: str = ""
    query_candidates: tuple[QueryCandidate, ...] = ()
    source_preferences: tuple[SourcePreference, ...] = ()
    max_depth: int = PLAN_MAX_DEPTH
    max_queries: int = DEFAULT_MAX_QUERIES
    max_sources: int = DEFAULT_MAX_SOURCES
    reason_codes: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    def to_payload(self) -> dict[str, object]:
        return {
            "plan_ref": _generated_ref(self.plan_ref, "research_plan"),
            "question_digest": valid_digest_ref(self.question_digest),
            "proof_ref": _generated_ref(self.proof_ref, "research_proof"),
            "query_candidates": [item.to_payload() for item in self.query_candidates[:MAX_PLAN_QUERIES]],
            "source_preferences": [item.to_payload() for item in self.source_preferences[:MAX_PLAN_SOURCES]],
            "max_depth": _bounded_int(self.max_depth, 1, PLAN_MAX_DEPTH),
            "max_queries": _bounded_int(self.max_queries, 1, MAX_PLAN_QUERIES),
            "max_sources": _bounded_int(self.max_sources, 1, MAX_PLAN_SOURCES),
            "reason_codes": list(bounded_refs(self.reason_codes, limit=MAX_PLAN_REASON_CODES)),
            "warnings": list(bounded_refs(self.warnings, limit=MAX_PLAN_WARNINGS)),
            "dry_run": True,
        }

    def to_trace_payload(self) -> dict[str, object]:
        return research_plan_trace_payload(self)


def build_research_plan(
    review: ResearchProofReview | Mapping[str, object] | None,
    *,
    question: str = "",
    registry: SourceConnectorRegistry | None = None,
    max_queries: int = DEFAULT_MAX_QUERIES,
    max_sources: int = DEFAULT_MAX_SOURCES,
) -> ResearchPlan:
    payload = _review_payload(review)
    registry = registry or built_in_connector_registry()
    question_digest = valid_digest_ref(payload.get("question_digest")) or (
        digest_text(question) if question else ""
    )
    proof_ref = _generated_ref(payload.get("proof_ref"), "research_proof")
    max_query_count = _bounded_int(max_queries, 1, MAX_PLAN_QUERIES)
    max_source_count = _bounded_int(max_sources, 1, MAX_PLAN_SOURCES)
    if _proof_ok_without_required_gap(payload):
        reason_codes: tuple[str, ...] = ("proof_ok_no_required_followup",)
        warnings: tuple[str, ...] = ()
        plan_ref = stable_ref(
            "research_plan",
            question_digest,
            proof_ref,
            (),
            (),
            max_query_count,
            max_source_count,
            reason_codes,
            warnings,
        )
        return ResearchPlan(
            plan_ref=plan_ref,
            question_digest=question_digest,
            proof_ref=proof_ref,
            query_candidates=(),
            source_preferences=(),
            max_depth=PLAN_MAX_DEPTH,
            max_queries=max_query_count,
            max_sources=max_source_count,
            reason_codes=reason_codes,
            warnings=warnings,
        )
    signals = _signals_from_review(payload)
    terms = _safe_terms(" ".join([question, *signals]))
    preferences, pref_reasons = _source_preferences(terms, registry)
    query_candidates = _query_candidates(
        signals=signals,
        terms=terms,
        preferences=preferences,
        max_queries=max_query_count,
    )
    reason_codes = tuple(bounded_refs([
        *_reason_codes_from_review(payload),
        *pref_reasons,
        *(
            ("proof_ok_no_required_followup",)
            if bool(payload.get("ok")) and not query_candidates
            else ()
        ),
    ], limit=MAX_PLAN_REASON_CODES))
    warnings = tuple(_planner_warnings(payload, preferences))
    plan_ref = stable_ref(
        "research_plan",
        question_digest,
        proof_ref,
        tuple(item.query_id for item in query_candidates),
        tuple(item.connector_id for item in preferences),
        max_query_count,
        max_source_count,
        tuple(reason_codes),
        tuple(warnings),
    )
    return ResearchPlan(
        plan_ref=plan_ref,
        question_digest=question_digest,
        proof_ref=proof_ref,
        query_candidates=query_candidates,
        source_preferences=preferences,
        max_depth=PLAN_MAX_DEPTH,
        max_queries=max_query_count,
        max_sources=max_source_count,
        reason_codes=tuple(reason_codes),
        warnings=tuple(warnings),
    )


def research_plan_trace_payload(plan: ResearchPlan | Mapping[str, object]) -> dict[str, object]:
    payload = plan.to_payload() if isinstance(plan, ResearchPlan) else dict(plan)
    source_preferences = payload.get("source_preferences")
    if not isinstance(source_preferences, list):
        source_preferences = list[object]()
    query_candidates = payload.get("query_candidates")
    if not isinstance(query_candidates, list):
        query_candidates = list[object]()
    return {
        "plan_ref": _generated_ref(payload.get("plan_ref"), "research_plan"),
        "question_digest": valid_digest_ref(payload.get("question_digest")),
        "proof_ref": _generated_ref(payload.get("proof_ref"), "research_proof"),
        "dry_run": True,
        "max_depth": _bounded_int(payload.get("max_depth"), 1, PLAN_MAX_DEPTH),
        "max_queries": _bounded_int(payload.get("max_queries"), 1, MAX_PLAN_QUERIES),
        "max_sources": _bounded_int(payload.get("max_sources"), 1, MAX_PLAN_SOURCES),
        "query_count": min(MAX_PLAN_QUERIES, len(query_candidates)),
        "source_preferences": [
            _safe_trace_connector_id(item.get("connector_id"))
            for item in source_preferences
            if isinstance(item, Mapping) and _safe_trace_connector_id(item.get("connector_id"))
        ][:MAX_PLAN_SOURCES],
        "reason_codes": [
            _safe_trace_code(item, 80)
            for item in _trace_list_items(payload.get("reason_codes"))
            if _safe_trace_code(item, 80)
        ][:MAX_PLAN_REASON_CODES],
        "warnings": [
            _safe_trace_code(item, 120)
            for item in _trace_list_items(payload.get("warnings"))
            if _safe_trace_code(item, 120)
        ][:MAX_PLAN_WARNINGS],
    }


def _trace_list_items(value: object) -> tuple[object, ...]:
    if isinstance(value, (list, tuple, set)):
        return tuple(value)
    return ()


def _review_payload(review: object) -> dict[str, object]:
    if review is None:
        return {}
    if isinstance(review, ResearchProofReview):
        try:
            return review.to_payload()
        except Exception:
            return {}
    if isinstance(review, Mapping):
        return dict(review)
    return {}


def _signals_from_review(payload: Mapping[str, object]) -> tuple[str, ...]:
    signals: list[str] = []
    for key in ("query_rewrite_candidates", "followup_questions", "coverage_gaps"):
        value = payload.get(key)
        if not isinstance(value, (list, tuple)):
            continue
        for item in value:
            if isinstance(item, Mapping):
                text = str(item.get("text") or item.get("term_ref") or item.get("detail") or "")
            else:
                text = str(item or "")
            safe = _safe_signal_text(text)
            if key == "coverage_gaps" and _low_information_signal(safe):
                continue
            if safe and safe not in signals:
                signals.append(safe)
            if len(signals) >= MAX_PLAN_QUERIES * 2:
                return tuple(signals)
    return tuple(signals)


def _proof_ok_without_required_gap(payload: Mapping[str, object]) -> bool:
    if not bool(payload.get("ok")):
        return False
    if _has_items(payload.get("coverage_gaps")) or _has_items(payload.get("missing_evidence")):
        return False
    answer_status = identifier(payload.get("answer_status"), 40)
    if answer_status and answer_status != "answered":
        return False
    return payload.get("answers_question") is not False


def _has_items(value: object) -> bool:
    return bool(value)


def _source_preferences(
    terms: tuple[str, ...],
    registry: SourceConnectorRegistry,
) -> tuple[tuple[SourcePreference, ...], tuple[str, ...]]:
    available = {
        spec.id: spec
        for spec in registry.all()
        if spec.status in CONNECTOR_AVAILABLE_STATUSES and spec.shipped
    }
    preferences: list[SourcePreference] = []
    reasons: list[str] = []

    def add(connector_id: str, score: float, *reason_codes: str) -> None:
        if connector_id not in available:
            return
        if any(item.connector_id == connector_id for item in preferences):
            return
        preferences.append(SourcePreference(connector_id, reason_codes, score))
        reasons.extend(reason_codes)

    for connector_id in preferred_connector_ids(terms, available_ids=tuple(available)):
        score, reason_codes = _CONNECTOR_REASON_SCORES.get(connector_id, (0.0, ()))
        add(connector_id, score, *reason_codes)
    return tuple(preferences[:MAX_PLAN_SOURCES]), tuple(dict.fromkeys(reasons))


def _query_candidates(
    *,
    signals: tuple[str, ...],
    terms: tuple[str, ...],
    preferences: tuple[SourcePreference, ...],
    max_queries: int,
) -> tuple[QueryCandidate, ...]:
    connector_ids = tuple(item.connector_id for item in preferences)
    candidates: list[QueryCandidate] = []
    question_candidate = _question_terms_query(terms, connector_ids)
    if question_candidate:
        candidates.append(question_candidate)
    for signal in signals:
        candidate = _candidate_query(signal, terms, connector_ids)
        if candidate and not any(item.query_preview == candidate.query_preview for item in candidates):
            candidates.append(candidate)
        if len(candidates) >= max_queries:
            break
    if len(candidates) < max_queries and terms:
        phrase = " ".join(terms[:6])
        suffix = _domain_suffix(connector_ids)
        text = _safe_query_preview(f"{phrase} {suffix}".strip())
        if text and not any(item.query_preview == text for item in candidates):
            candidates.append(_make_query_candidate(text, connector_ids, ("question_terms",), 0.74))
    return tuple(candidates[:max_queries])


def _question_terms_query(
    terms: tuple[str, ...],
    connector_ids: tuple[str, ...],
) -> QueryCandidate | None:
    content_terms = _content_query_terms(terms, limit=8)
    if not content_terms:
        return None
    suffix = _domain_suffix(connector_ids)
    text = _safe_query_preview(f"{' '.join(content_terms)} {suffix}".strip())
    if not text:
        return None
    return _make_query_candidate(text, connector_ids, ("question_terms",), 0.86)


def _candidate_query(
    signal: str,
    terms: tuple[str, ...],
    connector_ids: tuple[str, ...],
) -> QueryCandidate | None:
    text = _safe_query_preview(signal)
    if not text and terms:
        text = _safe_query_preview(" ".join(terms[:6]))
    if not text:
        return None
    suffix = _domain_suffix(connector_ids)
    if suffix and suffix.casefold() not in text.casefold():
        text = _safe_query_preview(f"{text} {suffix}")
    return _make_query_candidate(text, connector_ids, ("proof_review_signal",), 0.82)


def _make_query_candidate(
    query_preview: str,
    connector_ids: tuple[str, ...],
    reason_codes: tuple[str, ...],
    score: float,
) -> QueryCandidate:
    query = clip(query_preview, MAX_QUERY_PREVIEW_CHARS)
    return QueryCandidate(
        query_id=stable_ref("research_query", digest_text(query), connector_ids, reason_codes),
        query_preview=query,
        connector_ids=connector_ids,
        reason_codes=reason_codes,
        score=score,
    )


def _domain_suffix(connector_ids: tuple[str, ...]) -> str:
    if "pubmed" in connector_ids:
        return "PubMed evidence"
    if "arxiv" in connector_ids:
        return "arXiv preprint"
    return "primary source evidence"


def _safe_terms(text: str) -> tuple[str, ...]:
    return safe_connector_query_terms(text, limit=16)


def _safe_query_preview(text: str) -> str:
    tokens = _safe_terms(text)
    if not tokens:
        return ""
    return clip(" ".join(tokens[:10]), MAX_QUERY_PREVIEW_CHARS)


def _content_query_terms(terms: tuple[str, ...], *, limit: int) -> tuple[str, ...]:
    content: list[str] = []
    seen: set[str] = set()
    for raw in terms:
        term = str(raw or "").strip()
        folded = term.casefold()
        if not folded or folded in _QUERY_CONTENT_STOP_TERMS or len(folded) <= 1:
            continue
        if folded in seen:
            continue
        seen.add(folded)
        content.append(term)
        if len(content) >= limit:
            break
    return tuple(content)


def _low_information_signal(value: object) -> bool:
    text = _safe_signal_text(value)
    if not text:
        return True
    return not _content_query_terms(_safe_terms(text), limit=1)


def _safe_signal_text(value: object) -> str:
    return safe_connector_signal_text(value, limit=MAX_QUERY_PREVIEW_CHARS)


def _safe_trace_code(value: object, limit: int) -> str:
    raw = clip(value, limit)
    if not raw:
        return ""
    if looks_sensitive_code(raw):
        return ""
    text = identifier(raw, limit)
    if looks_sensitive_code(text):
        return ""
    return text


def _safe_trace_connector_id(value: object) -> str:
    raw = clip(value, 80)
    if looks_prompt_visible_secret(raw):
        return ""
    return _connector_id(raw)


def _reason_codes_from_review(payload: Mapping[str, object]) -> tuple[str, ...]:
    values: list[str] = []
    for key in ("missing_evidence", "reason_codes"):
        raw = payload.get(key)
        if not isinstance(raw, (list, tuple)):
            continue
        for item in raw:
            code = identifier(item, 80)
            if code and code not in values:
                values.append(code)
    answer_status = identifier(payload.get("answer_status"), 40)
    if answer_status and answer_status != "answered":
        values.append("answer_status_" + answer_status)
    if payload and not bool(payload.get("ok")):
        values.append("proof_review_failed")
    return tuple(values)


def _planner_warnings(
    payload: Mapping[str, object],
    preferences: tuple[SourcePreference, ...],
) -> tuple[str, ...]:
    warnings: list[str] = []
    if not payload:
        warnings.append("missing_proof_review")
    if not preferences:
        warnings.append("no_connector_preference")
    return tuple(dict.fromkeys(warnings))[:MAX_PLAN_WARNINGS]


def _unit_float(value: object) -> float:
    number = coerce_float(value)
    if not math.isfinite(number):
        return 0.0
    return max(0.0, min(1.0, round(number, 3)))


__all__ = [
    "DEFAULT_MAX_QUERIES",
    "DEFAULT_MAX_SOURCES",
    "MAX_PLAN_QUERIES",
    "MAX_PLAN_SOURCES",
    "PLAN_MAX_DEPTH",
    "QueryCandidate",
    "ResearchPlan",
    "SourcePreference",
    "build_research_plan",
    "research_plan_trace_payload",
]
