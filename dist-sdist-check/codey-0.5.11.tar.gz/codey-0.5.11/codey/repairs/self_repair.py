"""Small deduplicated queue for Provider adapter self-repair."""

from __future__ import annotations

import threading
import time
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from typing import Any

from codey.providers.diagnostics import (
    FAILURE_CONTROL_MISSING,
    FAILURE_READINESS_STALE,
    FAILURE_RESPONSE_MISSING,
    ProviderFailure,
)
from codey.providers.ids import normalize_provider_id
from codey.providers.supervisor import STATE_OPEN, ProviderHealth
from codey.repairs.adapter_repair import AdapterRepairResult
from codey.repairs.journal import RepairJournal
from codey.repairs.self_repair_job import SelfRepairJob

STRUCTURAL_FAILURES = {
    FAILURE_CONTROL_MISSING,
    FAILURE_RESPONSE_MISSING,
    FAILURE_READINESS_STALE,
}
REPAIR_COOLDOWN_SECONDS = 15 * 60


class SelfRepairSupervisor:
    """Queue adapter repairs without blocking active user tasks."""

    def __init__(
        self,
        state_home: str | Path | None = None,
        *,
        runner: Callable[[SelfRepairJob], AdapterRepairResult] | None = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.journal = RepairJournal(state_home)
        self.runner = runner
        self.clock = clock
        self._lock = threading.Lock()
        self._queued: dict[str, SelfRepairJob] = {}
        self._last_enqueued: dict[str, float] = {}
        self._kick_running = False

    def maybe_enqueue(
        self,
        provider_id: str,
        failure: ProviderFailure,
        health: ProviderHealth,
    ) -> bool:
        if not _is_repairable_failure(failure, health):
            return False
        key = _job_key(provider_id, failure)
        now = self.clock()
        with self._lock:
            last = self._last_enqueued.get(key)
            if last is not None and now - last < REPAIR_COOLDOWN_SECONDS:
                return False
            job = SelfRepairJob(
                provider_id=normalize_provider_id(provider_id),
                failure_kind=failure.kind,
                failure_stage=failure.stage,
                enqueued_at=now,
                next_retry_at=now,
                failure_facts=failure.facts,
            )
            self._queued[key] = job
            self._last_enqueued[key] = now
        self.journal.append(
            "self_repair_queued",
            provider=provider_id,
            failure_kind=failure.kind,
            failure_stage=failure.stage,
        )
        return True

    def pending(self) -> tuple[SelfRepairJob, ...]:
        with self._lock:
            return tuple(self._queued.values())

    def has_due_work(self) -> bool:
        now = self.clock()
        with self._lock:
            return any(job.next_retry_at <= now for job in self._queued.values())

    def run_pending_once(self) -> tuple[AdapterRepairResult, ...]:
        if self.runner is None:
            return ()
        now = self.clock()
        with self._lock:
            jobs = [
                (key, job)
                for key, job in self._queued.items()
                if job.next_retry_at <= now
            ]
            for key, _job in jobs:
                self._queued.pop(key, None)
        results: list[AdapterRepairResult] = []
        for key, job in jobs:
            try:
                result = self.runner(job)
            except Exception as exc:
                self.journal.append(
                    "self_repair_runner_error",
                    provider=job.provider_id,
                    error=str(exc),
                )
                self._retry_later(key, job)
                continue
            results.append(result)
            self.journal.append(
                "self_repair_finished",
                provider=job.provider_id,
                ok=result.ok,
                generation=result.generation,
                error=result.error,
            )
            if not result.ok:
                self._retry_later(key, job)
        return tuple(results)

    def _retry_later(self, key: str, job: SelfRepairJob) -> None:
        retry_at = self.clock() + REPAIR_COOLDOWN_SECONDS
        with self._lock:
            self._queued[key] = replace(job, next_retry_at=retry_at)

    def kick_if_idle(self, is_busy: Callable[[], bool]) -> bool:
        """Run at most one queued repair while the main task slot is idle."""
        if not self.pending():
            return False
        has_due_work = getattr(self, "has_due_work", None)
        if callable(has_due_work) and not has_due_work():
            return False
        with self._lock:
            if is_busy() or self._kick_running:
                return False
            self._kick_running = True

        def _worker() -> None:
            try:
                self.run_pending_once()
            finally:
                with self._lock:
                    self._kick_running = False

        threading.Thread(target=_worker, name="codey-self-repair", daemon=True).start()
        return True


def run_self_repair_job(
    *,
    state_home: str | Path | None,
    providers: Any,
    job: SelfRepairJob,
) -> AdapterRepairResult:
    """Run one repair job with sibling helpers from the provider registry."""
    from codey.app import provider_services
    from codey.repairs.self_repair_worker import run_self_repair_worker

    if state_home is None:
        return AdapterRepairResult(False, job.provider_id, error="self-repair state is unavailable")
    return run_self_repair_worker(
        job,
        helper_ids=providers.self_repair_candidates(
            job.provider_id,
            ordered=provider_services.provider_failover_order(providers),
        ),
        state_home=state_home,
        source_root=Path(__file__).resolve().parents[1],
    )


def _is_repairable_failure(failure: ProviderFailure, health: ProviderHealth) -> bool:
    return (
        failure.kind in STRUCTURAL_FAILURES
        and health.state == STATE_OPEN
        and bool(normalize_provider_id(failure.model) or failure.model)
    )


def _job_key(provider_id: str, failure: ProviderFailure) -> str:
    return f"{normalize_provider_id(provider_id)}:{failure.kind}:{failure.stage}"
