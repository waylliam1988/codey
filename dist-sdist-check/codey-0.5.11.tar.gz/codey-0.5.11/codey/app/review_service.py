"""Second-model review runs (reviewer providers).

``task_submit`` builds ``TaskRunDeps.run_review`` from ``run_review``; the
review attempt prompt/render lives in ``reviews/``. Import-light by design
(see ``test_server_lazy_state``): nothing here may load the browser stack,
research, or concepts at import time.
"""

from __future__ import annotations

import contextlib
from collections.abc import Callable
from dataclasses import replace
from typing import Any, cast

from codey.app import provider_services as providers
from codey.operations.task_state import TaskState
from codey.policies.limits import REVIEW_TIMEOUT
from codey.providers import controls as provider_controls
from codey.providers.catalog import DEFAULT_PROVIDER_ID
from codey.reviews.core import REVIEW_REPAIR_PROMPT, ReviewResult, parse_review_response, parse_review_with_repair
from codey.reviews.impact_map import safe_review_impact_map
from codey.reviews.review_policy import WEB_IF_AVAILABLE, allow_self_review
from codey.runtime.core import cancellation
from codey.runtime.observe.prompt_envelope import FailOpenPromptTrace, record_provider_send_prompt


def emit_review(ctx: TaskState, session_id: str, text: str) -> None:
    ctx.emit({"type": "review", "session_id": session_id, "text": text})


def emit_review_with_payload(
    ctx: TaskState,
    session_id: str,
    text: str,
    review: ReviewResult,
) -> None:
    from codey.reviews.core import review_result_payload

    ctx.emit({"type": "review", "session_id": session_id, "text": text,
              "review": review_result_payload(review)})


class ReviewSendUnknown(RuntimeError):
    """Provider request was sent but the result is unknown: never auto-resend."""


def run_review_attempt(
    ctx: TaskState,
    *,
    session_id: str,
    project: str,
    task: str,
    writer_summary: str,
    changes: dict[str, Any],
    recent_log: str,
    change_brief: str,
    project_map: str,
    verification_map: str,
    review_impact_map: str,
    execution_evidence: str,
    reviewer_id: str,
    reviewer: Any,
    self_review: bool,
    trace_recorder: object | None = None,
    run_id: str = "",
    review_policy: str = WEB_IF_AVAILABLE,
    review_source_run_id: str = "",
) -> tuple[str, ReviewResult]:
    from codey.reviews.identity import build_identity, capture_snapshot, review_model_identity, verify_snapshot
    from codey.reviews.input import prepare_review_input

    try:
        cancellation.check()
        prepared = prepare_review_input(
            project=project,
            task=task,
            writer_summary=writer_summary,
            changes=changes,
            recent_log=recent_log,
            change_brief=change_brief,
            project_map=project_map,
            verification_map=verification_map,
            review_impact_map=review_impact_map,
            execution_evidence=execution_evidence,
        )
        snapshot = capture_snapshot(project, prepared.scope.provided_files)
        early = _early_snapshot_result(ctx, session_id, reviewer_id, prepared, snapshot)
        if early is not None:
            return reviewer_id, early
        cancellation.check()
        if not verify_snapshot(snapshot):
            return reviewer_id, _stale_before_send(ctx, session_id, reviewer_id, prepared)
        model_id = review_model_identity(reviewer)
        if review_source_run_id and model_id:
            from codey.reviews.reuse import try_reuse_review

            identity = build_identity(prepared, reviewer_id=reviewer_id, policy=review_policy,
                                      model_id=model_id, self_review=self_review, project=project, snapshot=snapshot)
            state_home = getattr(ctx, "state_home", None)
            reused = try_reuse_review(
                state_home=state_home, session_id=session_id, current_run_id=run_id,
                current_project=project, source_run_id=review_source_run_id,
                current_scope=prepared.scope, current_identity=identity, current_snapshot_ok=True,
            ) if state_home is not None else None
            if reused is not None and reused.identity is not None and verify_snapshot(snapshot):
                # Historical artifact reference, current applicability guard.
                identity = replace(identity, attempt_id=reused.identity.attempt_id,
                                   artifact_sha256=reused.identity.artifact_sha256)
                reused = replace(reused, identity=identity)
                emit_review_with_payload(ctx, session_id, "Previous review reused", reused)
                return reviewer_id, reused
        cancellation.check()
        from codey.operations.provider_session import bind_api_usage

        bind_api_usage(reviewer, reviewer_id, trace_recorder)
        reviewer.new_chat()
        review = _request_review_result(reviewer, trace_recorder, prepared, snapshot)
        return reviewer_id, _finalize_review(
            ctx, session_id, project, reviewer_id, self_review,
            prepared, snapshot, review, trace_recorder, run_id, review_policy, model_id,
        )
    finally:
        with contextlib.suppress(Exception):
            reviewer.close()


def _early_snapshot_result(ctx: Any, session_id: Any, reviewer_id: Any, prepared: Any, snapshot: Any) -> Any:
    if snapshot.ok:
        return None
    review = ReviewResult(
        verdict="unknown",
        summary="Review incomplete",
        findings=[],
        status="incomplete",
        origin="fresh",
        diagnostics=("snapshot_unavailable",),
        scope=prepared.scope,
    )
    emit_review(ctx, session_id, f"{providers.review_label(reviewer_id)} incomplete")
    return review


def _stale_before_send(ctx: Any, session_id: Any, reviewer_id: Any, prepared: Any) -> Any:
    review = ReviewResult(
        verdict="unknown",
        summary="Review outdated · files changed",
        findings=[],
        status="stale",
        origin="fresh",
        diagnostics=("snapshot_stale_before_send",),
        scope=prepared.scope,
    )
    emit_review(ctx, session_id, f"{providers.review_label(reviewer_id)} incomplete")
    return review


def _send_review_prompt(reviewer: Any, trace_recorder: Any, prompt: Any) -> Any:
    from codey.providers.api_transport import GenerationRejectedError

    trace = FailOpenPromptTrace(trace_recorder)
    trace.call("record_permission_profile", "reviewer", phase="review")
    record_provider_send_prompt(
        trace_recorder,
        name="review_prompt",
        text=prompt,
        purpose="review prompt sent to provider",
        source_ref="provider_send:review",
        capability_id="review_runner",
    )
    try:
        with provider_controls.suppress_assistance():
            return reviewer.send(prompt, timeout=REVIEW_TIMEOUT)
    except (cancellation.TaskCancelled, cancellation.DeadlineExceeded, GenerationRejectedError):
        raise
    except Exception as exc:
        raise ReviewSendUnknown(str(exc)) from exc


def _request_review_result(reviewer: Any, trace_recorder: object | None, prepared: Any, snapshot: Any) -> ReviewResult:
    """Known output truncation and malformed JSON share one format attempt.

    A completed generation cut short is distinct from an unknown send. Only
    this read-only response may be regenerated; snapshot applicability still
    guards both the retry and the final result.
    """
    from codey.providers.error_classification import OutputLengthError
    from codey.reviews.identity import verify_snapshot

    try:
        reply = _send_review_prompt(reviewer, trace_recorder, prepared.prompt)
    except ReviewSendUnknown as exc:
        if not isinstance(exc.__cause__, OutputLengthError):
            raise
        cancellation.check()
        if not verify_snapshot(snapshot):
            return ReviewResult('unknown', 'Review outdated · files changed', [], status='stale',
                                diagnostics=('snapshot_stale_before_format_repair',))
        reply = _send_review_prompt(reviewer, trace_recorder, REVIEW_REPAIR_PROMPT
            + '\nKeep summary under 160 characters; each finding must identify a concrete defect. '
              'Do not put step-by-step analysis in JSON fields.')
        return parse_review_response(reply, changes=prepared.reviewer_view)
    return cast(ReviewResult, _parse_with_single_repair(reviewer, trace_recorder, reply, prepared))


def _parse_with_single_repair(reviewer: Any, trace_recorder: Any, reply: Any, prepared: Any) -> Any:
    from codey.providers.api_transport import GenerationRejectedError

    def send_repair_prompt(repair: str) -> str:
        record_provider_send_prompt(
            trace_recorder,
            name="review_repair_prompt",
            text=repair,
            purpose="review repair prompt sent to provider",
            source_ref="provider_send:review_repair",
            capability_id="review_runner",
        )
        try:
            return cast(str, reviewer.send(repair, timeout=REVIEW_TIMEOUT))
        except (cancellation.TaskCancelled, cancellation.DeadlineExceeded, GenerationRejectedError):
            raise
        except Exception as exc:
            raise ReviewSendUnknown(str(exc)) from exc

    return parse_review_with_repair(reply, send_repair_prompt, changes=prepared.reviewer_view)


def _finalize_review(
    ctx: Any, session_id: Any, project: Any, reviewer_id: Any, self_review: Any,
    prepared: Any, snapshot: Any, review: Any, trace_recorder: Any, run_id: Any, review_policy: Any = WEB_IF_AVAILABLE, model_id: Any = "",
) -> Any:
    import uuid as _uuid

    from codey.reviews.identity import (
        build_identity,
        prompt_digest_for,
        scope_digest_for,
        snapshot_digest_for,
        verify_snapshot,
    )

    scope_digest = scope_digest_for(prepared.scope)
    prompt_digest = prompt_digest_for(prepared.prompt)
    snapshot_digest = snapshot_digest_for(snapshot)
    attempt_id = _uuid.uuid4().hex[:12]
    snapshot_current = verify_snapshot(snapshot)
    persisted_status = (
        "stale"
        if not snapshot_current
        else ("incomplete" if not prepared.scope.is_complete else review.status)
    )
    review = replace(review, status=persisted_status, scope=prepared.scope)
    artifact_sha = _persist_attempt_artifact(
        ctx, session_id, run_id, attempt_id, review,
        scope_digest, prompt_digest, snapshot_digest,
        reviewer_id, self_review, model_id, review_policy,
    )
    identity = build_identity(
        prepared,
        reviewer_id=reviewer_id,
        policy=review_policy,
        model_id=model_id,
        self_review=self_review,
        project=project,
        snapshot=snapshot,
        attempt_id=attempt_id,
        artifact_sha256=artifact_sha,
    )
    review = replace(review, identity=identity)
    from codey.reviews.persistence import review_trace_payload

    FailOpenPromptTrace(trace_recorder).call(
        "record_coding_review",
        review_trace_payload(review, scope_digest=scope_digest, prompt_digest=prompt_digest),
    )
    label = providers.review_label(reviewer_id)
    prefix = f"{label} self-review" if self_review else label
    if review.approved:
        emit_text = f"{prefix} approved"
    elif not review.is_complete:
        emit_text = f"{prefix} incomplete"
    else:
        emit_text = f"{prefix} suggested changes"
    emit_review_with_payload(ctx, session_id, emit_text, review)
    return review


def _persist_attempt_artifact(
    ctx: Any, session_id: Any, run_id: Any, attempt_id: Any, review: Any,
    scope_digest: Any, prompt_digest: Any, snapshot_digest: Any, reviewer_id: Any, self_review: Any,
    model_id: Any, review_policy: Any,
) -> str:
    if not run_id:
        return ""
    try:
        from codey.reviews.persistence import ReviewArtifactStore, save_review_artifact

        state_home = getattr(ctx, "state_home", None)
        if state_home is None:
            return ""
        ref = save_review_artifact(
            ReviewArtifactStore(state_home),
            session_id=session_id,
            run_id=run_id,
            attempt_id=attempt_id,
            result=review,
            scope_digest=scope_digest,
            prompt_digest=prompt_digest,
            snapshot_digest=snapshot_digest,
            reviewer_id=reviewer_id,
            policy=review_policy,
            model_id=model_id,
            self_review=self_review,
        )
        return ref.sha256 if ref is not None else ""
    except Exception:
        return ""


def run_review(
    ctx: TaskState,
    *,
    session_id: str,
    project: str,
    task: str,
    writer_summary: str,
    changes: dict[str, Any],
    recent_log: str,
    writer_id: str,
    change_brief: str = "",
    project_map: str = "",
    verification_map: str = "",
    review_impact_map: str | None = None,
    execution_evidence: str = "",
    trace_recorder: object | None = None,
    review_policy: str = WEB_IF_AVAILABLE,
    run_id: str = "",
    review_source_run_id: str = "",
    connect_reviewer: Callable[..., Any] | None = None,
    standalone: bool = False,
) -> tuple[str, ReviewResult] | None:
    from codey.reviews.reuse import validate_source_run_id

    cancellation.check()
    self_review_allowed = allow_self_review(review_policy)
    if review_impact_map is None:
        review_impact_map = safe_review_impact_map(project, changes)
    source = validate_source_run_id(review_source_run_id) if review_source_run_id else ""
    with contextlib.ExitStack() as leases:
        selected = _connect_review_model(ctx, session_id=session_id, run_id=run_id, writer_id=writer_id,
                                    self_review_allowed=self_review_allowed, standalone=standalone,
                                    connect_reviewer=connect_reviewer, leases=leases)
        if selected is None:
            return None
        reviewer_id, reviewer, self_review = selected
        return run_review_attempt(
            ctx, session_id=session_id, project=project, task=task,
            writer_summary=writer_summary, changes=changes, recent_log=recent_log,
            change_brief=change_brief, project_map=project_map, verification_map=verification_map,
            review_impact_map=review_impact_map, execution_evidence=execution_evidence,
            reviewer_id=reviewer_id, reviewer=reviewer, self_review=self_review,
            trace_recorder=trace_recorder, run_id=run_id, review_policy=review_policy,
            review_source_run_id=source,
        )


def _connect_review_model(
    ctx: TaskState, *, session_id: str, run_id: str, writer_id: str,
    self_review_allowed: bool, standalone: bool,
    connect_reviewer: Callable[..., Any] | None,
    leases: contextlib.ExitStack,
) -> tuple[str, Any, bool] | None:
    from codey.providers.catalog import API_CONNECTIONS
    from codey.providers.ids import normalize_provider_id

    if connect_reviewer is not None:
        if not self_review_allowed:
            raise ValueError("headless selected-provider review requires self-review permission")
        return writer_id, connect_reviewer(writer_id), True
    if standalone and writer_id in API_CONNECTIONS:
        if not self_review_allowed:
            emit_review(ctx, session_id, "Review unavailable: selected-provider review is disabled.")
            return None
        selected = _selected_api_reviewer(ctx, session_id, run_id, writer_id, standalone=True, leases=leases)
        if selected is None:
            raise RuntimeError("Selected API reviewer is unavailable")
        return selected[0], selected[1], False
    for reviewer_id in providers.reviewer_candidates(ctx, writer_id):
        cancellation.check()
        try:
            with contextlib.ExitStack() as candidate:
                candidate.enter_context(providers.use_model(ctx, reviewer_id))
                reviewer = providers.connect_existing_provider(reviewer_id)
                leases.enter_context(candidate.pop_all())
        except (cancellation.TaskCancelled, cancellation.DeadlineExceeded):
            raise
        except Exception:
            continue
        ctx.set_provider_session(reviewer_id, None)
        return reviewer_id, reviewer, False
    cancellation.check()
    selected = _selected_api_reviewer(ctx, session_id, run_id, writer_id, leases=leases) if self_review_allowed else None
    if selected is not None:
        return selected[0], selected[1], False
    if not self_review_allowed:
        emit_review(ctx, session_id, "Review unavailable: no web reviewer is open.")
        return None
    reviewer_id = normalize_provider_id(writer_id) or DEFAULT_PROVIDER_ID
    leases.enter_context(providers.use_model(ctx, reviewer_id))
    return reviewer_id, providers.connect_fresh_provider_tab(reviewer_id), True


def _selected_api_reviewer(
    ctx: TaskState, session_id: str, run_id: str, writer_id: str, *, standalone: bool = False,
    leases: contextlib.ExitStack | None = None,
) -> tuple[str, Any] | None:
    from codey.providers.api_connections import capture_reviewer_selection, open_selection
    from codey.runtime.core.api_selection import ApiRunSelection
    from codey.runtime.core.operation_state import RuntimeOperationStore

    writer = ctx.run_registry.api_selection_for(run_id)
    if not isinstance(writer, ApiRunSelection) or writer.connection_id != writer_id:
        return None
    operation = RuntimeOperationStore(ctx.runtime_log).load(session_id, run_id) if getattr(ctx, "runtime_log", None) is not None else None
    if operation is not None and operation.reviewer_selection:
        selection = ApiRunSelection.from_payload(operation.reviewer_selection)
    else:
        try:
            preferences = ctx.providers.model_preferences.snapshot()["sources"].get(writer_id, {})
            selected_models = set(preferences.get("models", [])) if preferences.get("enabled") else set()
            selection = writer if standalone else capture_reviewer_selection(writer, allowed_models=selected_models)
        except ValueError:
            return None
        if operation is not None:
            ctx.runtime_mutations.admit_reviewer_selection(session_id, run_id, selection.to_payload())
    if not ctx.providers.model_preferences.allows(selection.connection_id, selection.model_id):
        return None
    if leases is not None:
        leases.enter_context(providers.use_model(ctx, selection.connection_id, selection.model_id))
    return selection.connection_id, open_selection(selection)


__all__ = [
    "ReviewSendUnknown",
    "emit_review",
    "emit_review_with_payload",
    "run_review",
    "run_review_attempt",
]
