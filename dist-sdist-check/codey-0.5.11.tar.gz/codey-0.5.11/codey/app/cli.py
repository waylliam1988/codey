"""Codey entry point.

    python -m codey            launch the native UI (default)
    python -m codey ui         same as above, with --port
    python -m codey chat ...   single-shot prompt, prints reply
    python -m codey agent ...  agent loop without UI (CLI mode)
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, cast


def _safe_print(value: Any, *, file: Any = None) -> None:
    if file is None:
        file = sys.stdout
    text = str(value)
    encoding = getattr(file, "encoding", None) or "utf-8"
    safe = text.encode(encoding, errors="replace").decode(encoding, errors="replace")
    file.write(safe + "\n")


def cmd_ui(args: argparse.Namespace) -> int:
    from codey.app.server import serve

    serve(host="127.0.0.1", port=args.port)
    return 0


def cmd_chat(args: argparse.Namespace) -> int:
    from codey.providers import controls as provider_controls
    from codey.providers.registry import connect_provider

    prompt = " ".join(args.prompt)
    _safe_print(f"[codey] connecting provider ({args.provider}) ...", file=sys.stderr)
    provider_controls.begin_task_context(f"cli-chat:{args.provider}")
    provider = None
    try:
        provider = connect_provider(args.provider, port=args.port)
        reply = provider.send(prompt, timeout=args.timeout)
    finally:
        try:
            if provider is not None:
                provider.close()
        finally:
            provider_controls.end_task_context()
    _safe_print(reply)
    return 0


def _agent_intent(args: argparse.Namespace) -> str:
    if args.readonly:
        return "planning_readonly"
    if args.auto:
        return "auto"
    return args.intent or "project"


def cmd_agent(args: argparse.Namespace) -> int:
    task = " ".join(args.task)
    project = Path(args.project).resolve() if args.project else None
    json_mode = args.json is True
    _safe_print(f"[codey] project: {project}", file=sys.stderr)
    from codey.agents.request import DEFAULT_MAX_TURNS
    from codey.app.headless_runner import (
        HeadlessRequest,
        emit_jsonl,
        run_headless,
    )
    from codey.storage.local_store import DEFAULT_STATE_HOME

    state_home_arg = args.state_home
    state_home = (
        Path(state_home_arg).expanduser()
        if state_home_arg
        else DEFAULT_STATE_HOME
    )
    raw_max_turns = args.max_turns
    max_turns = DEFAULT_MAX_TURNS if raw_max_turns is None else raw_max_turns
    request = HeadlessRequest(
        project=project,
        task=task,
        provider_id=args.provider,
        max_turns=max_turns,
        intent=_agent_intent(args),
        state_home=state_home,
        port=args.port,
        session_id=args.session_id,
        review_source_run_id=args.review_source_run_id,
        requested_capabilities=tuple(name for name, enabled in (
            ("web.read", args.allow_web), ("project.write", args.allow_write),
        ) if enabled),
        continue_task=args.continue_task,
        review_policy=args.review_policy,
        model_selection={"model": args.model, **({"effort": args.effort} if args.effort is not None else {})} if args.model else {},
    )
    if json_mode:
        result = run_headless(
            request,
            emit_jsonl=lambda payload: emit_jsonl(payload, file=sys.stdout),
        )
        return result.exit_code
    rows: list[dict[str, object]] = []

    def _emit_progress(row: dict[str, object]) -> None:
        rows.append(row)
        line = _human_cli_line(row)
        if line:
            _safe_print(line, file=sys.stderr)

    result = run_headless(request, emit_jsonl=_emit_progress)
    done = next(
        (row for row in reversed(rows) if str(row.get("type") or "") == "task_done"),
        None,
    )
    _safe_print(str((done or {}).get("summary") or ""), file=sys.stdout)
    return result.exit_code


def _human_cli_line(row: dict[str, object]) -> str:
    """One quiet human line per headless event; nothing machine-shaped."""
    kind = str(row.get("type") or "")
    if kind == "task_start":
        return f"[codey] start mode={row.get('mode', '')} provider={row.get('provider', '')}"
    if kind in {"status", "info", "review"}:
        text = str(row.get("status") or row.get("text") or "").strip()
        return f"[codey] {text}" if text else ""
    if kind in {"tool_started", "tool"}:
        tool = str(row.get("tool_name") or row.get("tool") or "")
        path = str(row.get("path") or "")
        extra = f" {path}" if path else ""
        command = str(row.get("command") or "")
        if command:
            extra += f" $ {command[:120]}"
        status = "" if kind == "tool_started" else (
            "ok" if row.get("ok") is True else "failed")
        return f"[turn {row.get('turn', '')}] {tool}{extra} {status}".rstrip()
    if kind in {"shell_request", "shell_rejected"}:
        return "[codey] shell commands need approval; denied headlessly."
    return ""


def _ghost_list(args: argparse.Namespace, store: Any) -> int:
    candidates = [
        candidate.to_payload()
        for candidate in store.list_candidates(
            status=getattr(args, "status", "") or None,
            scope=getattr(args, "scope", "") or "",
            project=getattr(args, "project", "") or "",
            session_id=getattr(args, "session_id", "") or "",
        )
    ]
    _print_json({
        "schema_version": 1,
        "ok": True,
        "learning_enabled": store.learning_enabled(),
        "candidates": candidates,
        "warnings": list(store.last_warnings),
    })
    return 0


def _ghost_export(surface: Any) -> int:
    _print_json(surface.export_state())
    return 0


def _ghost_work_list(args: argparse.Namespace, work_queue_store: Any) -> int:
    items = [
        item.to_payload()
        for item in work_queue_store.list_items(
            status=getattr(args, "status", "") or "",
            kind=getattr(args, "kind", "") or "",
            scope=getattr(args, "scope", "") or "",
            project=getattr(args, "project", "") or "",
            session_id=getattr(args, "session_id", "") or "",
        )
    ]
    _print_json({
        "schema_version": 1,
        "ok": True,
        "items": items,
        "warnings": list(work_queue_store.last_warnings),
    })
    return 0


def _ghost_work_transition(action: str, args: argparse.Namespace, work_queue_store: Any) -> int:
    try:
        item = (
            work_queue_store.queue_item(args.item_id)
            if action == "work-queue"
            else work_queue_store.reject_item(args.item_id)
        )
    except (OSError, TypeError, ValueError) as exc:
        _print_error_json(exc)
        return 1
    if item is None:
        _print_error_json("work item not found or invalid transition")
        return 1
    _print_json({
        "schema_version": 1,
        "ok": True,
        "item": item.to_payload(),
    })
    return 0


def _ghost_review(action: str, args: argparse.Namespace, store: Any, hebbian_store: Any) -> int:
    try:
        candidate = store.review_candidate(
            args.candidate_id,
            "accept" if action == "accept" else "reject",
            reviewed_by="cli",
        )
    except ValueError as exc:
        _print_error_json(exc)
        return 2
    except (OSError, TypeError) as exc:
        _print_error_json(exc)
        return 1
    if candidate is None:
        _print_error_json("candidate not found or storage failed")
        return 1
    payload: dict[str, object] = {
        "schema_version": 1,
        "ok": True,
        "candidate": candidate.to_payload(),
    }
    if action == "accept":
        related_candidates = [
            row for row in store.list_candidates(status="accepted")
            if row.id != candidate.id and row.run_id and row.run_id == candidate.run_id
        ]
        result = hebbian_store.reinforce_candidate(
            candidate,
            related_candidates=related_candidates,
        )
        payload["hebbian"] = {
            "applied": result.applied,
            "reason": result.reason,
            "node": result.node.to_payload() if result.node is not None else None,
            "edges": [edge.to_payload() for edge in result.edges],
        }
    else:
        try:
            payload["hebbian_removed"] = hebbian_store.remove_candidate(candidate)
        except (OSError, TypeError, ValueError) as exc:
            _print_error_json(exc)
            return 1
    _print_json(payload)
    return 0


def _ghost_state(hebbian_store: Any) -> int:
    payload = hebbian_store.export_state()
    payload["ok"] = True
    _print_json(payload)
    return 0


def _ghost_directive(args: argparse.Namespace, hebbian_store: Any) -> int:
    from codey.ghost.directive import build_ghost_directive

    budget_arg = getattr(args, "budget", 900)
    directive = build_ghost_directive(
        hebbian_store,
        project=getattr(args, "project", "") or "",
        session_id=getattr(args, "session_id", "") or "",
        budget=900 if budget_arg is None else budget_arg,
    )
    payload = directive.to_payload()
    payload["schema_version"] = 1
    payload["ok"] = True
    _print_json(payload)
    return 0


def _ghost_continuity(args: argparse.Namespace, continuity_store: Any) -> int:
    from codey.ghost.continuity import build_ghost_continuity

    budget_arg = getattr(args, "budget", 900)
    continuity = build_ghost_continuity(
        continuity_store,
        project=getattr(args, "project", "") or "",
        session_id=getattr(args, "session_id", "") or "",
        budget=900 if budget_arg is None else budget_arg,
    )
    payload = continuity.to_payload()
    payload["schema_version"] = 1
    payload["ok"] = True
    _print_json(payload)
    return 0


def _ghost_rebuild_state(args: argparse.Namespace, hebbian_store: Any) -> int:
    if not getattr(args, "yes", False):
        _print_error_json("rebuild-state requires --yes")
        return 2
    ok = hebbian_store.rebuild_from_events()
    _print_json({"schema_version": 1, "ok": ok})
    return 0 if ok else 1


def _ghost_rebuild_continuity(args: argparse.Namespace, continuity_store: Any) -> int:
    if not getattr(args, "yes", False):
        _print_error_json("rebuild-continuity requires --yes")
        return 2
    ok = continuity_store.rebuild_from_events()
    _print_json({"schema_version": 1, "ok": ok})
    return 0 if ok else 1


def _ghost_rebuild_affinity(args: argparse.Namespace, affinity_store: Any) -> int:
    if not getattr(args, "yes", False):
        _print_error_json("rebuild-affinity requires --yes")
        return 2
    ok = affinity_store.rebuild_from_events()
    _print_json({"schema_version": 1, "ok": ok})
    return 0 if ok else 1


def _ghost_reset(args: argparse.Namespace, surface: Any) -> int:
    if not getattr(args, "yes", False):
        _print_error_json("reset requires --yes")
        return 2
    status, payload = surface.dispatch_action({"action": "reset_all", "confirm": True})
    _print_json(payload)
    if status == 400:
        return 2
    return 0 if payload.get("ok") else 1


def _ghost_delete_scope(args: argparse.Namespace, surface: Any) -> int:
    if not getattr(args, "yes", False):
        _print_error_json("delete-scope requires --yes")
        return 2
    status, payload = surface.dispatch_action({
        "action": "delete_scope",
        "confirm": True,
        "scope": getattr(args, "scope_name", ""),
        "project": getattr(args, "project", "") or "",
        "session_id": getattr(args, "session_id", "") or "",
    })
    _print_json(payload)
    if status == 400:
        return 2
    return 0 if payload.get("ok") else 1


def _ghost_enable_disable(action: str, surface: Any, store: Any) -> int:
    _status, payload = surface.dispatch_action(
        {"action": "enable_updates" if action == "enable" else "disable_updates"}
    )
    _print_json({
        "schema_version": 1,
        "ok": payload.get("ok"),
        "learning_enabled": payload.get("enabled", store.learning_enabled()),
    })
    return 0 if payload.get("ok") else 1


def cmd_ghost(args: argparse.Namespace) -> int:
    from codey.ghost.control_surface import GhostControlSurface
    from codey.storage.local_store import DEFAULT_STATE_HOME

    state_home_arg = getattr(args, "state_home", "") or ""
    state_home = Path(state_home_arg).expanduser() if state_home_arg else DEFAULT_STATE_HOME
    surface = GhostControlSurface.from_state_home(state_home)
    if not surface.available or surface.inbox is None:
        _print_error_json("ghost store unavailable")
        return 1
    store = surface.inbox
    hebbian_store = surface.hebbian
    continuity_store = surface.continuity
    affinity_store = surface.affinity
    work_queue_store = surface.work_queue
    action = str(getattr(args, "ghost_cmd", "") or "").strip()
    if action == "list":
        return _ghost_list(args, store)
    if action == "export":
        return _ghost_export(surface)
    if action == "work-list":
        return _ghost_work_list(args, work_queue_store)
    if action in {"work-queue", "work-reject"}:
        return _ghost_work_transition(action, args, work_queue_store)
    if action in {"accept", "reject"}:
        return _ghost_review(action, args, store, hebbian_store)
    if action == "state":
        return _ghost_state(hebbian_store)
    if action == "directive":
        return _ghost_directive(args, hebbian_store)
    if action == "continuity":
        return _ghost_continuity(args, continuity_store)
    if action == "rebuild-state":
        return _ghost_rebuild_state(args, hebbian_store)
    if action == "rebuild-continuity":
        return _ghost_rebuild_continuity(args, continuity_store)
    if action == "rebuild-affinity":
        return _ghost_rebuild_affinity(args, affinity_store)
    if action == "reset":
        return _ghost_reset(args, surface)
    if action == "delete-scope":
        return _ghost_delete_scope(args, surface)
    if action in {"enable", "disable"}:
        return _ghost_enable_disable(action, surface, store)
    _safe_print("ghost subcommand required", file=sys.stderr)
    return 2


def _print_error_json(error: object) -> None:
    _print_json({
        "schema_version": 1,
        "ok": False,
        "error": str(error or "error")[:240],
    })


def _print_json(payload: dict[str, object]) -> None:
    _safe_print(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True),
        file=sys.stdout,
    )


def _add_ghost_subcommands(sub: Any) -> None:
    ghost_common = argparse.ArgumentParser(add_help=False)
    ghost_common.add_argument("--state-home", default="", help="local Codey state directory")

    sp_ghost_list = sub.add_parser("list", parents=[ghost_common], help="list inbox candidates")
    sp_ghost_list.add_argument("--status", default="", help="optional status filter")
    sp_ghost_list.add_argument("--scope", choices=("user", "project", "session"), default="", help="optional scope filter")
    sp_ghost_list.add_argument("--project", default="", help="project path for project scope filtering")
    sp_ghost_list.add_argument("--session-id", default="", help="session id for session scope filtering")
    sp_ghost_list.set_defaults(func=cmd_ghost)

    sp_ghost_export = sub.add_parser("export", parents=[ghost_common], help="export all Ghost local state")
    sp_ghost_export.set_defaults(func=cmd_ghost)

    sp_ghost_work_list = sub.add_parser("work-list", parents=[ghost_common], help="list Ghost work items")
    sp_ghost_work_list.add_argument("--status", default="", help="optional status filter")
    sp_ghost_work_list.add_argument("--kind", default="", help="optional kind filter")
    sp_ghost_work_list.add_argument("--scope", choices=("user", "project", "session"), default="", help="optional scope filter")
    sp_ghost_work_list.add_argument("--project", default="", help="project path for project scope filtering")
    sp_ghost_work_list.add_argument("--session-id", default="", help="session id for session scope filtering")
    sp_ghost_work_list.set_defaults(func=cmd_ghost)

    sp_ghost_work_queue = sub.add_parser("work-queue", parents=[ghost_common], help="queue a Ghost work item")
    sp_ghost_work_queue.add_argument("item_id")
    sp_ghost_work_queue.set_defaults(func=cmd_ghost)

    sp_ghost_work_reject = sub.add_parser("work-reject", parents=[ghost_common], help="reject a Ghost work item")
    sp_ghost_work_reject.add_argument("item_id")
    sp_ghost_work_reject.set_defaults(func=cmd_ghost)

    sp_ghost_accept = sub.add_parser("accept", parents=[ghost_common], help="accept an inbox candidate")
    sp_ghost_accept.add_argument("candidate_id")
    sp_ghost_accept.set_defaults(func=cmd_ghost)

    sp_ghost_reject = sub.add_parser("reject", parents=[ghost_common], help="reject an inbox candidate")
    sp_ghost_reject.add_argument("candidate_id")
    sp_ghost_reject.set_defaults(func=cmd_ghost)

    sp_ghost_state = sub.add_parser("state", parents=[ghost_common], help="export Ghost Hebbian state")
    sp_ghost_state.set_defaults(func=cmd_ghost)

    sp_ghost_directive = sub.add_parser("directive", parents=[ghost_common], help="preview Ghost Directive prompt context")
    sp_ghost_directive.add_argument("--project", default="", help="project path for project-scoped memory")
    sp_ghost_directive.add_argument("--session-id", default="", help="session id for session-scoped memory")
    sp_ghost_directive.add_argument("--budget", type=int, default=900, help="maximum directive characters")
    sp_ghost_directive.set_defaults(func=cmd_ghost)

    sp_ghost_continuity = sub.add_parser("continuity", parents=[ghost_common], help="preview Ghost continuity prompt context")
    sp_ghost_continuity.add_argument("--project", default="", help="project path for project-scoped continuity")
    sp_ghost_continuity.add_argument("--session-id", default="", help="session id for session-scoped continuity")
    sp_ghost_continuity.add_argument("--budget", type=int, default=900, help="maximum continuity characters")
    sp_ghost_continuity.set_defaults(func=cmd_ghost)

    sp_ghost_rebuild = sub.add_parser("rebuild-state", parents=[ghost_common], help="rebuild Ghost Hebbian state from events")
    sp_ghost_rebuild.add_argument("--yes", action="store_true")
    sp_ghost_rebuild.set_defaults(func=cmd_ghost)

    sp_ghost_rebuild_continuity = sub.add_parser(
        "rebuild-continuity",
        parents=[ghost_common],
        help="rebuild Ghost continuity projection from events",
    )
    sp_ghost_rebuild_continuity.add_argument("--yes", action="store_true")
    sp_ghost_rebuild_continuity.set_defaults(func=cmd_ghost)

    sp_ghost_rebuild_affinity = sub.add_parser(
        "rebuild-affinity",
        parents=[ghost_common],
        help="rebuild Ghost Affinity projection from events",
    )
    sp_ghost_rebuild_affinity.add_argument("--yes", action="store_true")
    sp_ghost_rebuild_affinity.set_defaults(func=cmd_ghost)

    sp_ghost_reset = sub.add_parser("reset", parents=[ghost_common], help="delete all Ghost local state")
    sp_ghost_reset.add_argument("--yes", action="store_true")
    sp_ghost_reset.set_defaults(func=cmd_ghost)

    sp_ghost_delete = sub.add_parser("delete-scope", parents=[ghost_common], help="delete one Ghost memory scope")
    sp_ghost_delete.add_argument("scope_name", choices=("user", "project", "session"))
    sp_ghost_delete.add_argument("--project", default="", help="required for project scope")
    sp_ghost_delete.add_argument("--session-id", default="", help="required for session scope")
    sp_ghost_delete.add_argument("--yes", action="store_true")
    sp_ghost_delete.set_defaults(func=cmd_ghost)

    sp_ghost_enable = sub.add_parser("enable", parents=[ghost_common], help="enable future Ghost learning ingest")
    sp_ghost_enable.set_defaults(func=cmd_ghost)

    sp_ghost_disable = sub.add_parser("disable", parents=[ghost_common], help="disable future Ghost learning ingest")
    sp_ghost_disable.set_defaults(func=cmd_ghost)


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv

    # Default: if no subcommand given, launch the UI.
    if not argv or argv[0] not in {"ui", "chat", "agent", "ghost", "-h", "--help"}:
        argv = ["ui", *argv]

    # Single parser tree: ghost shares the root parser so its registration
    # exists exactly once. Parser build stays cold (no toolchain import);
    # DEFAULT_MAX_TURNS is resolved lazily in cmd_agent.
    from codey.providers.catalog import DEFAULT_PROVIDER_ID, provider_ids

    ap = argparse.ArgumentParser(prog="codey")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sp_ui = sub.add_parser("ui", help="launch the native UI (default)")
    sp_ui.add_argument("--port", type=int, default=5173)
    sp_ui.set_defaults(func=cmd_ui)

    sp_chat = sub.add_parser("chat", help="single-shot prompt")
    sp_chat.add_argument("prompt", nargs="+")
    sp_chat.add_argument("--port", type=int, default=9222)
    sp_chat.add_argument("--provider", choices=provider_ids(), default=DEFAULT_PROVIDER_ID)
    sp_chat.add_argument("--timeout", type=float, default=300.0)
    sp_chat.set_defaults(func=cmd_chat)

    sp_agent = sub.add_parser("agent", help="CLI agent loop")
    sp_agent.add_argument("--project", default="", help="attach a project folder")
    sp_agent.add_argument("--max-turns", type=int, default=None)
    sp_agent.add_argument("--port", type=int, default=9222)
    sp_agent.add_argument("--provider", choices=provider_ids(), default=DEFAULT_PROVIDER_ID)
    sp_agent.add_argument("--model", default="", help="explicit API model; protocol comes from connection settings or catalog")
    sp_agent.add_argument("--effort", choices=("off", "minimal", "low", "medium", "high", "xhigh", "max"), default=None)
    sp_agent.add_argument("--json", action="store_true", help="emit JSONL events on stdout")
    modes = sp_agent.add_mutually_exclusive_group()
    modes.add_argument("--intent", choices=("auto", "chat", "project", "hybrid", "research", "review", "planning_readonly"), help="task mode")
    modes.add_argument("--readonly", action="store_true", help="read-only planning")
    modes.add_argument("--auto", action="store_true", help="choose the task path automatically")
    sp_agent.add_argument("--allow-web", action="store_true", help="authorize web reading")
    sp_agent.add_argument("--allow-write", action="store_true", help="authorize project writing, including Research")
    sp_agent.add_argument("--session-id", default="", help="existing or new task session")
    sp_agent.add_argument("--continue", dest="continue_task", action="store_true", help="continue the selected session")
    sp_agent.add_argument("--review-source-run-id", default="", help="prefer a verified review from this prior run")
    sp_agent.add_argument("--review-policy", choices=("web_if_available", "require_web"), default=None, help="Reviewer policy; defaults to configured policy")
    sp_agent.add_argument("--state-home", default="", help="local Codey state directory")
    sp_agent.add_argument("task", nargs="+")
    sp_agent.set_defaults(func=cmd_agent)

    sp_ghost = sub.add_parser("ghost", help="inspect and control Ghost memory inbox")
    sp_ghost_sub = sp_ghost.add_subparsers(dest="ghost_cmd", required=True)
    _add_ghost_subcommands(sp_ghost_sub)

    args = ap.parse_args(argv)
    if args.cmd == "agent":
        from codey.providers.catalog import API_CONNECTIONS

        if args.model and args.provider not in API_CONNECTIONS:
            sp_agent.error("--model requires an API connection")
        if args.effort is not None and not args.model:
            sp_agent.error("--effort requires --model")
        intent = _agent_intent(args)
        if args.continue_task and not args.session_id:
            sp_agent.error("--continue requires --session-id")
        if args.review_source_run_id:
            if not args.session_id:
                sp_agent.error("--review-source-run-id requires --session-id")
            if intent not in {"project", "review"}:
                sp_agent.error("review source requires project or review intent")
    return cast(int, args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
