"""Durable observation journal shared by manual A/B harnesses.

This is the manual-experiment fact layer, not production RunTrace and not an
Evidence Ledger. It gives every live harness one shape for:

- identity-safe manifests (one experiment/run/provider per directory),
- append-only JSONL events with a verifiable hash chain,
- tail recovery after interrupted runs,
- optional prompt/reply transcript archival behind content digests,
- typed provider-observation facts without DOM, cookies, or raw bodies.

Production layers must not import this module; see test_architecture.py.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import time
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from codey.storage.local_store import write_json_atomic

JOURNAL_SCHEMA_VERSION = 1
MANIFEST_KIND = "ab_observation_journal_manifest"
GENESIS_DIGEST = "sha256:" + "0" * 64

TRANSCRIPT_MODE_DIGEST_ONLY = "digest_only"
TRANSCRIPT_MODE_ARCHIVE = "archive"
TRANSCRIPT_MODES = (TRANSCRIPT_MODE_DIGEST_ONLY, TRANSCRIPT_MODE_ARCHIVE)

EVENT_TYPES = (
    "run_start",
    "case_start",
    "send_start",
    "reply",
    "send_error",
    "timeout",
    "adapter_failure",
    "provider_mismatch",
    "case_complete",
    "run_complete",
    "note",
)

MAX_TRANSCRIPT_BYTES = 2 * 1024 * 1024
MAX_FACT_VALUE_CHARS = 200
MAX_FACT_ITEMS = 8
MAX_FACTS_BYTES = 8 * 1024

_URL_RE = re.compile(r"(?i)^[a-z][a-z0-9+.-]*://|^www\.")
_HTML_RE = re.compile(r"(?i)<\s*(html|body|div|script|textarea|input)\b")
_SECRET_VALUE_RE = re.compile(r"(?i)(api[-_]?key|authorization|bearer\s|passwd|password|secret)")
_SECRET_TOKEN_SHAPE_RE = re.compile(r"\b(?:sk|ghp|github_pat)-?[A-Za-z0-9_-]{16,}\b")
_TRANSCRIPT_DIGEST_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
_TRANSCRIPT_FILE_RE = re.compile(r"^[0-9a-f]{64}\.json$")


class ABJournalIdentityMismatch(ValueError):
    """Raised when a journal directory belongs to another experiment/run."""


def _timestamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _digest_payload(value: object) -> str:
    canonical = json.dumps(
        value,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )
    return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def digest_text(value: object) -> str:
    """Stable sha256 ref for one prompt or reply string."""

    return _digest_payload(str(value or ""))


def journal_directory_for(output: Path) -> Path:
    """Journal directory sits next to the result JSON as ``<stem>.trace/``."""

    return output.with_name(f"{output.stem}.trace")


def looks_secret_shaped(value: str) -> bool:
    return bool(_SECRET_VALUE_RE.search(value) or _SECRET_TOKEN_SHAPE_RE.search(value))


def sanitize_fact_value(value: object) -> tuple[bool, object]:
    """Allow-list one observation fact value.

    Booleans, bounded ints/floats, short clean strings, and flat lists of those
    survive. URLs, HTML fragments, cookie-ish strings, and secret-shaped values
    are redacted instead of persisted.
    """

    if isinstance(value, bool):
        return True, value
    if isinstance(value, int):
        return True, max(-(10**15), min(10**15, value))
    if isinstance(value, float):
        # Non-finite floats would serialize as NaN/Infinity, which is not
        # standard JSON and breaks third-party replay parsers.
        if not math.isfinite(value):
            return False, None
        return True, round(value, 6)
    if isinstance(value, str):
        text = " ".join(str(value or "").split())[:MAX_FACT_VALUE_CHARS]
        if not text:
            return False, None
        if _URL_RE.search(text) or _HTML_RE.search(text) or "cookie" in text.lower():
            return True, "[redacted]"
        if looks_secret_shaped(text):
            return True, "[redacted]"
        return True, text
    if isinstance(value, (list, tuple)):
        items: list[object] = []
        for item in list(value)[:MAX_FACT_ITEMS]:
            ok, cleaned = sanitize_fact_value(item)
            if ok:
                items.append(cleaned)
        return True, items
    return False, None


_PROVIDER_OBSERVATION_FACTS = frozenset(
    {
        "input_empty",
        "question_count_increased",
        "response_count_increased",
        "typing_true",
        "typing_false",
        "stop_visible",
        "stop_hidden",
        "response_stable",
        "response_nonempty",
        "response_chars",
        "profile_hash",
        "failure_kind",
        "failure_stage",
        "elapsed_ms",
    }
)

_FACT_ALLOWLIST_BY_EVENT: dict[str, frozenset[str]] = {
    "run_start": frozenset({"cases", "arms", "max_turns", "resumed_attempt", "attempt_index"}),
    "case_start": frozenset({"question_chars"}),
    "send_start": frozenset(),
    "reply": frozenset(),
    "send_error": frozenset({"error_class", "provider_failure"}),
    "timeout": _PROVIDER_OBSERVATION_FACTS,
    "adapter_failure": _PROVIDER_OBSERVATION_FACTS,
    "provider_mismatch": frozenset({"output", "expected_provider", "found_provider"}),
    "case_complete": frozenset({"ok", "stop_reason", "turns", "score"}),
    "run_complete": frozenset({"rows", "status"}),
    "note": frozenset({"output", "cases", "arms", "rerun_failed", "existing_rows"}),
}

_NESTED_FACT_ALLOWLIST_BY_EVENT: dict[str, dict[str, frozenset[str]]] = {
    "send_error": {"provider_failure": frozenset({"kind", "stage"})},
}


def sanitize_facts(event_type: str, facts: Mapping[str, object] | None) -> dict[str, object]:
    """Project raw provider observations into bounded, safe facts.

    Event facts are fail-closed: each event type has an explicit schema, nested
    mappings only survive for typed parents, and the value sanitizer is a second
    guard against URLs, HTML fragments, cookie-ish values, and secret-shaped
    strings.
    """

    if not isinstance(facts, Mapping):
        return {}
    allowed_names = _FACT_ALLOWLIST_BY_EVENT.get(str(event_type or ""), frozenset())
    nested_allowed = _NESTED_FACT_ALLOWLIST_BY_EVENT.get(str(event_type or ""), {})
    cleaned: dict[str, object] = {}
    encoded_size = 0

    def _admit(name: str, value: object, *, typed_nested: bool = False) -> None:
        nonlocal encoded_size
        if not typed_nested and name not in allowed_names:
            return
        allowed, safe_value = sanitize_fact_value(value)
        if not allowed:
            return
        candidate = json.dumps({name: safe_value}, ensure_ascii=False, default=str)
        size = len(candidate.encode("utf-8"))
        if encoded_size + size > MAX_FACTS_BYTES:
            return
        encoded_size += size
        cleaned[name] = safe_value

    for key in sorted(facts, key=str):
        name = str(key or "").strip()
        if name not in allowed_names:
            continue
        value = facts[key]
        if isinstance(value, Mapping):
            allowed_subkeys = nested_allowed.get(name)
            if not allowed_subkeys:
                continue
            for sub_key in sorted(allowed_subkeys):
                sub_name = str(sub_key or "").strip()
                if sub_name:
                    _admit(f"{name}_{sub_name}", value.get(sub_key), typed_nested=True)
            continue
        _admit(name, value)
    return cleaned


@dataclass(frozen=True)
class TranscriptRef:
    mode: str
    prompt_chars: int
    reply_chars: int
    content_digest: str
    path: str = ""

    def to_payload(self) -> dict[str, object]:
        return {
            "mode": self.mode,
            "prompt_chars": self.prompt_chars,
            "reply_chars": self.reply_chars,
            "content_digest": self.content_digest,
            "path": self.path,
        }


class TranscriptReplayCache:
    """Digest-first prompt/reply store for manual replay and scoring.

    ``digest_only`` never writes raw content. ``archive`` stores one bounded
    JSON document per unique prompt/reply pair under ``transcripts/<digest>.json``
    and is idempotent per content digest. Explicit delete/prune helpers are the
    retention boundary; no background process keeps raw transcript material.
    Archived transcripts are manual-layer material only: they must never flow
    into RunTrace, EvidenceLedger, ResearchRecord, citations, or completion
    proofs.
    """

    def __init__(
        self,
        directory: Path,
        *,
        mode: str = TRANSCRIPT_MODE_DIGEST_ONLY,
        max_bytes: int = MAX_TRANSCRIPT_BYTES,
    ) -> None:
        if mode not in TRANSCRIPT_MODES:
            raise ValueError(f"unknown transcript mode: {mode}")
        self.directory = Path(directory)
        self.mode = mode
        self.max_bytes = max_bytes

    def ref_for(self, *, prompt: str, reply: str, archive: bool) -> TranscriptRef:
        prompt_text = str(prompt or "")
        reply_text = str(reply or "")
        digest = _digest_payload({"prompt": prompt_text, "reply": reply_text})
        relative = ""
        if archive and self.mode == TRANSCRIPT_MODE_ARCHIVE:
            target = self._transcript_path(digest)
            encoded = json.dumps(
                {
                    "schema_version": JOURNAL_SCHEMA_VERSION,
                    "kind": "ab_transcript",
                    "content_digest": digest,
                    "prompt": prompt_text,
                    "reply": reply_text,
                    "created_at": _timestamp(),
                },
                ensure_ascii=False,
                indent=2,
            ).encode("utf-8")
            if len(encoded) > self.max_bytes:
                raise ValueError("transcript exceeded bounded size")
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
                with temporary.open("wb") as handle:
                    handle.write(encoded)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, target)
            relative = f"transcripts/{target.name}"
        return TranscriptRef(
            mode=self.mode if archive else TRANSCRIPT_MODE_DIGEST_ONLY,
            prompt_chars=len(prompt_text),
            reply_chars=len(reply_text),
            content_digest=digest,
            path=relative,
        )

    def _transcript_path(self, digest: str) -> Path:
        if not _TRANSCRIPT_DIGEST_RE.fullmatch(digest):
            raise ValueError("invalid transcript digest")
        return self.directory / "transcripts" / f"{digest.removeprefix('sha256:')}.json"

    def delete_transcript(self, ref_or_digest: TranscriptRef | str) -> bool:
        """Delete one archived transcript by digest or TranscriptRef."""

        digest = ref_or_digest.content_digest if isinstance(ref_or_digest, TranscriptRef) else str(ref_or_digest or "")
        target = self._transcript_path(digest)
        try:
            target.unlink()
        except FileNotFoundError:
            return False
        return True

    def prune_transcripts(
        self,
        *,
        max_files: int | None = None,
        max_total_bytes: int | None = None,
    ) -> int:
        """Delete oldest archived transcripts until count/byte budgets fit."""

        if max_files is None and max_total_bytes is None:
            raise ValueError("max_files or max_total_bytes is required")
        if max_files is not None and max_files < 0:
            raise ValueError("max_files must be non-negative")
        if max_total_bytes is not None and max_total_bytes < 0:
            raise ValueError("max_total_bytes must be non-negative")

        entries: list[tuple[Path, float, int]] = []
        root = self.directory / "transcripts"
        if not root.is_dir():
            return 0
        for path in root.glob("*.json"):
            if not _TRANSCRIPT_FILE_RE.fullmatch(path.name):
                continue
            try:
                stat = path.stat()
            except OSError:
                continue
            if path.is_file():
                entries.append((path, stat.st_mtime, stat.st_size))

        entries.sort(key=lambda item: (item[1], item[0].name), reverse=True)
        kept: set[Path] = set()
        kept_bytes = 0
        for index, (path, _mtime, size) in enumerate(entries):
            fits_count = max_files is None or index < max_files
            fits_bytes = max_total_bytes is None or kept_bytes + size <= max_total_bytes
            if fits_count and fits_bytes:
                kept.add(path)
                kept_bytes += size

        deleted = 0
        for path, _mtime, _size in entries:
            if path in kept:
                continue
            try:
                path.unlink()
            except FileNotFoundError:
                continue
            deleted += 1
        return deleted


@dataclass(frozen=True)
class ABJournalEvent:
    seq: int
    ts: str
    run_id: str
    experiment_id: str
    case_id: str
    arm: str
    provider: str
    model: str
    event_type: str
    stage: str
    prompt_digest: str
    reply_digest: str
    content_ref: dict[str, object]
    failure_kind: str
    facts: dict[str, object]
    previous_digest: str
    event_digest: str

    def to_payload(self) -> dict[str, object]:
        return {
            "seq": self.seq,
            "ts": self.ts,
            "run_id": self.run_id,
            "experiment_id": self.experiment_id,
            "case_id": self.case_id,
            "arm": self.arm,
            "provider": self.provider,
            "model": self.model,
            "event_type": self.event_type,
            "stage": self.stage,
            "prompt_digest": self.prompt_digest,
            "reply_digest": self.reply_digest,
            "content_ref": dict(self.content_ref),
            "failure_kind": self.failure_kind,
            "facts": dict(self.facts),
            "previous_digest": self.previous_digest,
            "event_digest": self.event_digest,
        }


_CHAIN_KEYS = (
    "seq",
    "ts",
    "run_id",
    "experiment_id",
    "case_id",
    "arm",
    "provider",
    "model",
    "event_type",
    "stage",
    "prompt_digest",
    "reply_digest",
    "content_ref",
    "failure_kind",
    "facts",
    "previous_digest",
)


def event_chain_digest(payload: Mapping[str, object]) -> str:
    """Recompute the hash-chain digest over the canonical event fields."""

    fields = {key: payload.get(key) for key in _CHAIN_KEYS}
    return _digest_payload(fields)


def verify_event_chain(events: Iterable[Mapping[str, object]]) -> list[str]:
    """Return human-readable integrity problems for an event sequence.

    Beyond linkage and digests this enforces identity constancy: one journal
    belongs to exactly one (experiment_id, run_id, provider) triple, so any
    cross-run or cross-provider mixing is reported even when every individual
    event digest is internally consistent.
    """

    problems: list[str] = []
    previous = GENESIS_DIGEST
    identity: tuple[object, object, object] | None = None
    seen_seqs: set[int] = set()
    expected_seq = 1
    for event in events:
        seq = event.get("seq")
        if isinstance(seq, bool) or not isinstance(seq, int):
            problems.append(f"seq-not-int:{seq!r}")
            continue
        if seq in seen_seqs:
            problems.append(f"duplicate-seq:{seq}")
        seen_seqs.add(seq)
        if seq != expected_seq:
            problems.append(f"seq-gap:{seq}-expected-{expected_seq}")
        expected_seq = seq + 1
        current_identity = (
            event.get("experiment_id"),
            event.get("run_id"),
            event.get("provider"),
        )
        if identity is None:
            identity = current_identity
        elif current_identity != identity:
            problems.append(f"mixed-identity-at-seq:{seq}")
        if str(event.get("previous_digest") or "") != previous:
            problems.append(f"broken-chain-at-seq:{seq}")
        recomputed = event_chain_digest(event)
        if str(event.get("event_digest") or "") != recomputed:
            problems.append(f"bad-digest-at-seq:{seq}")
        previous = str(event.get("event_digest") or previous)
    return problems


def read_events_with_tail_recovery(path: Path) -> tuple[list[dict[str, Any]], int, int]:
    """Read JSONL events with explicit corruption accounting.

    Returns ``(events, tail_invalid, mid_file_invalid)``.

    - ``tail_invalid``: unparseable consecutive lines at the end of the file
      (the durable-append crash case). Safe to auto-recover.
    - ``mid_file_invalid``: unparseable lines before the tail. These are NOT
      silently cleaned; the caller must surface them (the writer refuses to
      append, :meth:`ABJournalReader.recover_tail` cleans explicitly).

    Parsed-but-tampered lines always stay in ``events`` so
    :func:`verify_event_chain` can report digest or chain breakage.
    """

    if not path.is_file():
        return [], 0, 0
    lines = [
        stripped for stripped in path.read_text(encoding="utf-8", errors="replace").splitlines() if stripped.strip()
    ]
    parsed: list[dict[str, Any] | None] = []
    for line in lines:
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            value = None
        parsed.append(value if isinstance(value, dict) else None)

    usable_to = len(parsed)
    while usable_to > 0 and parsed[usable_to - 1] is None:
        usable_to -= 1
    tail_invalid = len(parsed) - usable_to
    mid_file_invalid = sum(1 for item in parsed[:usable_to] if item is None)
    events = [item for item in parsed[:usable_to] if item is not None]
    return events, tail_invalid, mid_file_invalid


class ABJournalWriter:
    """Single-writer durable event journal for one experiment/run/provider."""

    def __init__(
        self,
        *,
        directory: Path,
        experiment_id: str,
        run_id: str,
        provider: str,
        model: str = "",
        transcript_cache: TranscriptReplayCache | None = None,
    ) -> None:
        self.directory = Path(directory)
        self.manifest_path = self.directory / "manifest.json"
        self.events_path = self.directory / "events.jsonl"
        self.experiment_id = str(experiment_id or "").strip()
        self.run_id = str(run_id or "").strip()
        self.provider = str(provider or "").strip()
        self.model = str(model or "").strip()
        self.transcript_cache = transcript_cache or TranscriptReplayCache(self.directory)
        if not self.experiment_id or not self.run_id or not self.provider:
            raise ValueError("experiment_id, run_id, and provider are required")

        events, tail_invalid, mid_file_invalid = read_events_with_tail_recovery(self.events_path)
        problems = verify_event_chain(events)
        if problems:
            raise ValueError(
                f"{self.events_path} failed journal verification "
                f"({problems[:3]}); manual recovery required before writing"
            )
        if mid_file_invalid:
            raise ValueError(
                f"{self.events_path} has {mid_file_invalid} unparseable line(s) "
                "before the tail; run ABJournalReader.recover_tail() manually "
                "after inspecting the file"
            )

        # Identity is enforced from the events themselves, not only from the
        # manifest: a missing/replaced manifest cannot smuggle another
        # experiment/run/provider onto this chain.
        if events:
            first = events[0]
            found = (
                str(first.get("experiment_id") or ""),
                str(first.get("run_id") or ""),
                str(first.get("provider") or ""),
            )
            expected = (self.experiment_id, self.run_id, self.provider)
            if found != expected:
                raise ABJournalIdentityMismatch(
                    f"{self.directory} belongs to experiment/run/provider {found}; refusing to write {expected}"
                )
        self._last_seq = int(events[-1].get("seq")) if events else 0
        self._last_digest = str(events[-1].get("event_digest")) if events else GENESIS_DIGEST
        if tail_invalid:
            # Only trailing unparseable lines reach here once the chain above
            # verified and no mid-file corruption exists.
            self.rewrite_recovered(events)

        self._load_or_reject_manifest()
        self.directory.mkdir(parents=True, exist_ok=True)
        self._write_manifest()
        self._handle = self.events_path.open("a", encoding="utf-8")

    @property
    def event_count(self) -> int:
        return self._last_seq

    def rewrite_recovered(self, events: list[dict[str, Any]]) -> None:
        self.events_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.events_path.with_name(f".{self.events_path.name}.recover")
        with temporary.open("w", encoding="utf-8") as handle:
            for event in events:
                handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, self.events_path)

    # -- identity -----------------------------------------------------------

    def _load_or_reject_manifest(self) -> None:
        if not self.manifest_path.is_file():
            return
        try:
            payload = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        if not isinstance(payload, dict) or payload.get("kind") != MANIFEST_KIND:
            return
        found = (
            str(payload.get("experiment_id") or ""),
            str(payload.get("run_id") or ""),
            str(payload.get("provider") or ""),
        )
        expected = (self.experiment_id, self.run_id, self.provider)
        if found != expected:
            raise ABJournalIdentityMismatch(
                f"{self.directory} belongs to experiment/run/provider {found}; refusing to write {expected}"
            )

    # -- low level ----------------------------------------------------------

    def _append_event(
        self,
        *,
        event_type: str,
        case_id: str = "",
        arm: str = "",
        stage: str = "",
        turn: int | None = None,
        prompt: str = "",
        reply: str = "",
        archive_transcript: bool = False,
        failure_kind: str = "",
        facts: Mapping[str, object] | None = None,
    ) -> ABJournalEvent:
        if event_type not in EVENT_TYPES:
            raise ValueError(f"unknown journal event type: {event_type}")
        safe_facts = sanitize_facts(event_type, facts)
        if turn is not None:
            safe_facts = {"turn": max(0, int(turn)), **safe_facts}

        prompt_text = str(prompt or "")
        reply_text = str(reply or "")
        prompt_digest = digest_text(prompt_text) if prompt_text else ""
        reply_digest = digest_text(reply_text) if reply_text else ""
        ref = self.transcript_cache.ref_for(
            prompt=prompt_text,
            reply=reply_text,
            archive=archive_transcript,
        )
        self._last_seq += 1
        payload: dict[str, object] = {
            "seq": self._last_seq,
            "ts": _timestamp(),
            "run_id": self.run_id,
            "experiment_id": self.experiment_id,
            "case_id": str(case_id or ""),
            "arm": str(arm or ""),
            "provider": self.provider,
            "model": self.model,
            "event_type": event_type,
            "stage": str(stage or ""),
            "prompt_digest": prompt_digest,
            "reply_digest": reply_digest,
            "content_ref": ref.to_payload() if (prompt_text or reply_text) else {},
            "failure_kind": str(failure_kind or ""),
            "facts": safe_facts,
            "previous_digest": self._last_digest,
        }
        payload["event_digest"] = event_chain_digest(payload)
        # allow_nan=False guarantees events.jsonl stays strict, standard JSON
        # that third-party replay parsers can consume.
        line = json.dumps(payload, ensure_ascii=False, sort_keys=True, allow_nan=False)
        self._handle.write(line + "\n")
        self._handle.flush()
        os.fsync(self._handle.fileno())
        self._last_digest = str(payload["event_digest"])
        return ABJournalEvent(**payload)

    def _read_manifest(self) -> dict[str, Any]:
        try:
            payload = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            payload = {}
        if not isinstance(payload, dict) or payload.get("kind") != MANIFEST_KIND:
            payload = {
                "schema_version": JOURNAL_SCHEMA_VERSION,
                "kind": MANIFEST_KIND,
                "experiment_id": self.experiment_id,
                "run_id": self.run_id,
                "provider": self.provider,
                "model": self.model,
                "transcript_mode": self.transcript_cache.mode,
                "started_at": _timestamp(),
                "status": "running",
            }
        return payload

    def _write_manifest(self) -> None:
        manifest = self._read_manifest()
        manifest["status"] = "running"
        manifest["updated_at"] = _timestamp()
        manifest["event_count"] = self._last_seq
        manifest["last_event_digest"] = self._last_digest
        write_json_atomic(self.manifest_path, manifest)

    # -- typed events -------------------------------------------------------

    def append_event(
        self,
        *,
        event_type: str,
        case_id: str = "",
        arm: str = "",
        stage: str = "",
        turn: int | None = None,
        prompt: str = "",
        reply: str = "",
        archive_transcript: bool = False,
        failure_kind: str = "",
        facts: Mapping[str, object] | None = None,
    ) -> ABJournalEvent:
        """Public escape hatch for harness-specific typed events."""

        return self._append_event(
            event_type=event_type,
            case_id=case_id,
            arm=arm,
            stage=stage,
            turn=turn,
            prompt=prompt,
            reply=reply,
            archive_transcript=archive_transcript,
            failure_kind=failure_kind,
            facts=facts,
        )

    def record_run_start(
        self,
        *,
        cases: tuple[str, ...],
        arms: tuple[str, ...],
        max_turns: int,
        resumed_attempt: bool = False,
    ) -> ABJournalEvent:
        manifest = self._read_manifest()
        try:
            previous_attempt = max(0, int(manifest.get("attempt_index") or 0))
        except (TypeError, ValueError):
            previous_attempt = 0
        minimum_attempt = 2 if resumed_attempt else 1
        attempt_index = max(minimum_attempt, previous_attempt + 1)
        event = self._append_event(
            event_type="run_start",
            stage="run_start",
            facts={
                "cases": list(cases),
                "arms": list(arms),
                "max_turns": max_turns,
                "resumed_attempt": resumed_attempt,
                "attempt_index": attempt_index,
            },
        )
        manifest["status"] = "running"
        manifest["resumed_attempt"] = bool(resumed_attempt)
        manifest["attempt_index"] = attempt_index
        self._write_manifest_with(manifest)
        return event

    def record_case_start(self, *, case: str, arm: str, question_chars: int = 0) -> ABJournalEvent:
        event = self._append_event(
            event_type="case_start",
            case_id=case,
            arm=arm,
            stage="case_start",
            facts={"question_chars": question_chars},
        )
        self._write_manifest()
        return event

    def record_send_start(
        self,
        *,
        case: str,
        arm: str,
        turn: int,
        prompt: str,
        stage: str = "",
    ) -> ABJournalEvent:
        return self._append_event(
            event_type="send_start",
            case_id=case,
            arm=arm,
            stage=stage or "send",
            turn=turn,
            prompt=prompt,
        )

    def record_reply(
        self,
        *,
        case: str,
        arm: str,
        turn: int,
        prompt: str,
        reply: str,
        stage: str = "",
    ) -> ABJournalEvent:
        return self._append_event(
            event_type="reply",
            case_id=case,
            arm=arm,
            stage=stage or "reply",
            turn=turn,
            prompt=prompt,
            reply=reply,
            archive_transcript=True,
        )

    def record_send_error(
        self,
        *,
        case: str,
        arm: str,
        turn: int,
        error: str,
        failure_kind: str = "",
        stage: str = "",
        provider_failure: Mapping[str, object] | None = None,
    ) -> ABJournalEvent:
        facts: dict[str, object] = {"error_class": str(error).split(":", 1)[0][:80]}
        if provider_failure:
            # Flattened one level by sanitize_facts, so kind/stage survive as
            # provider_failure_kind / provider_failure_stage scalars.
            facts["provider_failure"] = dict(provider_failure)
        return self._append_event(
            event_type="send_error",
            case_id=case,
            arm=arm,
            stage=stage or "send",
            turn=turn,
            failure_kind=failure_kind or "send_error",
            facts=facts,
        )

    def record_observation(
        self,
        *,
        case: str,
        arm: str,
        observation: str,
        facts: Mapping[str, object] | None = None,
    ) -> ABJournalEvent:
        """Record a typed provider observation (timeout / adapter_failure)."""

        if observation not in ("timeout", "adapter_failure"):
            raise ValueError(f"unsupported observation: {observation}")
        return self._append_event(
            event_type=observation,
            case_id=case,
            arm=arm,
            stage=observation,
            failure_kind=facts.get("failure_kind") if facts else "",
            facts=facts,
        )

    def record_case_complete(
        self,
        *,
        case: str,
        arm: str,
        row: Mapping[str, object],
    ) -> ABJournalEvent:
        turns_raw = row.get("turns")
        try:
            turns = max(0, int(turns_raw))
        except (TypeError, ValueError):
            turns = 0
        score = row.get("score")
        facts: dict[str, object] = {
            "ok": bool(row.get("ok")),
            "stop_reason": str(row.get("stop_reason") or row.get("error") or "")[:120],
            "turns": turns,
        }
        if isinstance(score, (int, float)) and not isinstance(score, bool):
            facts["score"] = round(float(score), 4)
        event = self._append_event(
            event_type="case_complete",
            case_id=case,
            arm=arm,
            stage="case_complete",
            facts=facts,
        )
        self._write_manifest()
        return event

    def record_run_complete(self, *, rows: int, status: str = "done") -> ABJournalEvent:
        event = self._append_event(
            event_type="run_complete",
            stage="run_complete",
            facts={"rows": rows, "status": status},
        )
        manifest = self._read_manifest()
        manifest["status"] = status
        self._write_manifest_with(manifest)
        return event

    def _write_manifest_with(self, manifest: dict[str, Any]) -> None:
        manifest["updated_at"] = _timestamp()
        manifest["event_count"] = self._last_seq
        manifest["last_event_digest"] = self._last_digest
        write_json_atomic(self.manifest_path, manifest)

    def close(self) -> None:
        handle = getattr(self, "_handle", None)
        if handle is not None:
            handle.close()
            self._handle = None


class ABJournalReader:
    """Read-side helpers: replay, verification, resume, and repair."""

    def __init__(self, directory: Path) -> None:
        self.directory = Path(directory)
        self.manifest_path = self.directory / "manifest.json"
        self.events_path = self.directory / "events.jsonl"

    def manifest(self) -> dict[str, Any]:
        try:
            payload = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return payload if isinstance(payload, dict) else {}

    def events(self) -> list[dict[str, Any]]:
        events, _tail, _mid = read_events_with_tail_recovery(self.events_path)
        return events

    def _events_with_integrity_problems(self) -> tuple[list[dict[str, Any]], list[str]]:
        events, tail_invalid, mid_file_invalid = read_events_with_tail_recovery(self.events_path)
        problems = verify_event_chain(events)
        if mid_file_invalid:
            problems.append(f"unparseable-lines:mid_file={mid_file_invalid}")
        if tail_invalid:
            problems.append(f"unparseable-lines:tail={tail_invalid}")
        return events, problems

    def verify_hash_chain(self) -> list[str]:
        """Verify linkage/digests/identity AND surface unparseable lines.

        Unparseable lines never enter ``events()``, so without this check a
        mid-file garbage line would be invisible to verification while still
        making the writer refuse to open.
        """

        _events, problems = self._events_with_integrity_problems()
        return problems

    def recover_tail(self) -> int:
        """Drop unparseable lines (trailing and mid-file); return the count.

        This is the explicit manual-recovery entry point. It removes only
        unparseable lines; parsed-but-tampered events stay and keep failing
        :meth:`verify_hash_chain` until investigated.
        """

        events, tail_invalid, mid_file_invalid = read_events_with_tail_recovery(self.events_path)
        dropped = tail_invalid + mid_file_invalid
        if dropped and self.events_path.is_file():
            temporary = self.events_path.with_name(f".{self.events_path.name}.recover")
            with temporary.open("w", encoding="utf-8") as handle:
                for event in events:
                    handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.events_path)
        return dropped

    def completed_case_keys(self) -> list[tuple[str, str]]:
        events, problems = self._events_with_integrity_problems()
        if problems:
            raise ValueError(
                f"{self.events_path} failed journal verification "
                f"({problems[:3]}); manual recovery required before resume"
            )
        keys: list[tuple[str, str]] = []
        for event in events:
            if event.get("event_type") != "case_complete":
                continue
            key = (str(event.get("case_id") or ""), str(event.get("arm") or ""))
            if key not in keys:
                keys.append(key)
        return keys


__all__ = [
    "ABJournalEvent",
    "ABJournalIdentityMismatch",
    "ABJournalReader",
    "ABJournalWriter",
    "EVENT_TYPES",
    "GENESIS_DIGEST",
    "MANIFEST_KIND",
    "TRANSCRIPT_MODE_ARCHIVE",
    "TRANSCRIPT_MODE_DIGEST_ONLY",
    "TranscriptReplayCache",
    "TranscriptRef",
    "digest_text",
    "journal_directory_for",
    "read_events_with_tail_recovery",
    "sanitize_facts",
    "verify_event_chain",
]
