import type { ToolDisplay as importToolDisplay } from '../render';
export interface ModelChoice {
  enabled: boolean;
  models: string[];
}
export interface ModelUse {
  provider: string;
  model?: string;
}
export interface ModelSource {
  id: string;
  models: Array<{ id: string }>;
}
export interface ModelState {
  preferences: { revision: number; sources: Record<string, ModelChoice> };
  sources: ModelSource[];
  in_use: ModelUse[];
}
export interface Draft {
  text: string;
  start: number;
  end: number;
  direction: 'none' | 'forward' | 'backward';
  revision: number;
}
export type AttemptState = 'sending' | 'running' | 'done' | 'paused' | 'failed';
export interface Message extends importToolDisplay {
  type: string;
  id?: string;
  text?: string;
  sessionId?: string;
  runId?: string;
  eventKey?: string;
  toolKey?: string;
  kind?: string;
  path?: string;
  command?: string;
  result?: string;
  activity?: string;
  error?: boolean;
  pending?: boolean;
  n?: string | number;
  turn?: string | number;
  note?: string;
  status?: string;
  state?: string;
  exitCode?: number | null;
  shellStatus?: string;
  approved?: boolean;
  output?: string;
  requestId?: string;
  sendFailure?: string;
  runOwner?: string;
  attempts?: Array<{ runId: string; state: AttemptState }>;
  payload?: unknown;
  reasoning?: string;
  thinking?: boolean;
  changed?: boolean;
  project?: string;
  count?: number;
  files?: Array<{ path?: string; status?: string; additions?: number; deletions?: number }>;
  commandSha256?: string;
  commandChars?: number;
  commandTruncated?: boolean;
  cwd?: string;
  riskLabel?: string;
  riskTitle?: string;
  riskDetail?: string;
  toolName?: string;
  confidence?: number;
  source_url?: string;
  requested_url?: string;
  final_url?: string;
  title?: string;
  url?: string;
  note_id?: string;
  excerpt?: string;
}
export interface ResearchRun {
  runId: string;
  restoreable: boolean;
  synthesisId?: string;
  notesCreated: string[];
  notesUpdated: string[];
  sourceUrls: string[];
  sourcesRead?: number;
  queries: string[];
  searchResults: Array<Record<string, unknown>>;
  openedSources: Array<Record<string, unknown>>;
  coverage: { queries?: string[]; skipped_results?: Array<Record<string, unknown>> };
  citationMap: Array<Record<string, unknown>>;
  evidenceItems: Array<Record<string, unknown>>;
  counterpoints: string[];
  qualityWarnings: string[];
  receipt?: string;
  createdAt?: number;
}
export interface ResearchPayload {
  synthesis_id?: string;
  notes_created?: string[];
  notes_updated?: string[];
  source_urls?: string[];
  sources_read?: number;
  queries?: string[];
  search_results?: Array<Record<string, unknown>>;
  opened_sources?: Array<Record<string, unknown>>;
  coverage?: { queries?: string[]; skipped_results?: Array<Record<string, unknown>> };
  citation_map?: Array<Record<string, unknown>>;
  evidence_items?: Array<Record<string, unknown>>;
  counterpoints?: string[];
  quality_warnings?: string[];
}
export interface ChangeFile {
  path: string;
  status?: string;
  additions?: number;
  deletions?: number;
}
export interface ChangesData {
  ok: boolean;
  project?: string;
  files: ChangeFile[];
  diff: string;
  mode?: string;
  error?: string;
  conflicts?: string[];
  changed_count?: number;
}
export interface RunData {
  ok: boolean;
  available?: boolean;
  details?: { title?: string; rows?: Array<{ label?: unknown; value?: unknown; tone?: string }>; warnings?: unknown[] };
  error?: string;
  message?: string;
  run_id?: string;
  session_id?: string;
  status?: string;
}
export interface RestoreChangesResult {
  ok?: boolean;
  run?: ResearchRun;
  error?: string;
  message?: string;
  restored?: unknown[];
  conflicts?: string[];
}
export interface ResearchRestoreResult {
  ok: boolean;
  ownerSessionId: string;
  run: ResearchRun;
  message: string;
  restored: unknown[];
}
export interface Session {
  id: string;
  title: string;
  draft: Draft;
  messages: Message[];
  projectId?: string | null;
  provider?: string;
  research?: boolean;
  modelSelection?: {
    connection_id?: string;
    base_url?: string;
    model?: string;
    name?: string;
    effort?: string | null;
    thinking?: boolean | null;
    efforts?: Record<string, string>;
  };
  _toolKeys?: Set<string>;
  _eventKeys?: Set<string>;
  _terminalRunSet?: Set<string>;
  terminalRuns?: string[];
  titleRenamed?: boolean;
  createdAt?: number;
  researchRuns?: ResearchRun[];
}
export interface Project {
  id: string;
  name: string;
  path: string;
  expanded?: boolean;
  createdAt?: number;
}
export interface UiDeps {
  getSessions?: () => Session[];
  setSessions?: (value: Session[]) => void;
  getProjects?: () => Project[];
  setProjects?: (value: Project[]) => void;
  getActiveId?: () => string;
  setActiveId?: (value: string) => void;
  getUpdatedAt?: () => number;
  setUpdatedAt?: (value: number) => void;
  getRevision?: () => number;
  setRevision?: (value: number) => void;
  isDirtySinceBoot?: () => boolean;
  setDirtySinceBoot?: (value: boolean) => void;
  bootHadMeaningfulUiState?: () => boolean;
  renderSidebar?: () => void;
  renderChat?: () => void;
  updateComposerContext?: () => void;
  syncProviderUI?: (provider: string) => void;
  currentProviderId?: () => string;
  receiptSummary?: (receipt: unknown) => string;
  persistActive?: () => void;
  persistActiveNow?: () => void;
  activeSession?: () => Session | undefined;
}
export interface SseDeps {
  setStatus(text: string, kind: string): void;
  applyRunState(data: RunState): void;
  handleServerEvent(data: import('../domain/protocol').ServerEvent): void;
  acceptRun(runId: string | null, sessionId: string | null): void;
  setProviderBusy(value: boolean): void;
  updateSend(): void;
  updateComposerContext(): void;
  refreshProviderStatus(immediate: boolean): void;
}
export interface RunState {
  busy?: boolean;
  run_id?: string;
  session_id?: string;
  run_status?: string;
  last_shell_result?: import('../domain/protocol').ServerEvent;
  last_terminal_event?: import('../domain/protocol').ServerEvent;
  pending_event?: import('../domain/protocol').ServerEvent;
  research_restore_runs?: string[];
}
