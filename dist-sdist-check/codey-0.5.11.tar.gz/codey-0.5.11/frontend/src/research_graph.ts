export interface GraphOptions {
  sessionId?: string;
  activeId?: string;
  depth?: number;
  showDepth?: boolean;
  focusIds?: string[];
  counterpoints?: string[];
  onDepthChange?(depth: number): void;
  onOpenNote?(id: string): void;
  onOpenSource?(url: string): void;
  run?: import('./research_drawer').ResearchRunView;
}

(function () {
  'use strict';

  interface GraphNode {
    id: string;
    kind?: string;
    label?: string;
    weight?: number;
    focus?: boolean;
    x: number;
    y: number;
    vx: number;
    vy: number;
    layerY: number;
    fixed: boolean;
    excerpt?: string;
    url?: string;
    path?: string;
    virtual?: boolean;
    note_type?: string;
    status?: string;
  }
  interface RawGraphNode {
    id: string;
    kind?: string;
    label?: string;
    weight?: number;
    focus?: boolean;
    excerpt?: string;
    url?: string;
    path?: string;
    virtual?: boolean;
    note_type?: string;
    status?: string;
  }
  interface GraphEdge {
    src: string;
    dst: string;
    kind?: string;
    source?: GraphNode;
    target?: GraphNode;
  }
  interface GraphRuntime {
    stop(): void;
    reset(): void;
  }
  interface GraphResponse {
    ok?: boolean;
    error?: string;
    graph?: { nodes?: RawGraphNode[]; edges?: GraphEdge[]; warnings?: string[] };
  }
  interface GraphColors {
    bg: string;
    faint: string;
    muted: string;
    text: string;
    textDim: string;
    ok: string;
  }
  interface GraphState {
    scale: number;
    tx: number;
    ty: number;
    width: number;
    height: number;
    hover: GraphNode | null;
    selected: GraphNode | null;
  }
  let runtime: GraphRuntime | null = null;
  let loadSeq = 0;

  function dispose() {
    loadSeq += 1;
    if (runtime && typeof runtime.stop === 'function') {
      runtime.stop();
    }
    runtime = null;
  }

  function render(panel: HTMLElement, options: GraphOptions) {
    dispose();
    options = options || {};
    panel.classList.add('research-graph-panel');
    const toolbar = document.createElement('div');
    toolbar.className = 'research-graph-toolbar';
    if (options.showDepth !== false) {
      const depthLabel = document.createElement('span');
      depthLabel.textContent = 'Depth';
      toolbar.appendChild(depthLabel);
      for (const depth of [1, 2, 3]) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'research-depth' + ((options.depth || 1) === depth ? ' active' : '');
        btn.textContent = String(depth);
        btn.onclick = () => {
          if (typeof options.onDepthChange === 'function') options.onDepthChange(depth);
        };
        toolbar.appendChild(btn);
      }
    }
    const spacer = document.createElement('div');
    spacer.className = 'research-graph-spacer';
    toolbar.appendChild(spacer);
    const reset = document.createElement('button');
    reset.type = 'button';
    reset.className = 'drawer-btn';
    reset.textContent = 'Reset';
    reset.onclick = () => {
      if (runtime && typeof runtime.reset === 'function') {
        runtime.reset();
      }
    };
    toolbar.appendChild(reset);
    panel.appendChild(toolbar);

    const stage = document.createElement('div');
    stage.className = 'research-graph-stage';
    const canvas = document.createElement('canvas');
    const status = document.createElement('div');
    status.className = 'research-graph-status';
    setStatus(status, 'Loading graph...');
    stage.append(canvas, status);
    panel.appendChild(stage);

    const detail = document.createElement('div');
    detail.className = 'research-graph-detail';
    panel.appendChild(detail);
    setDetail(detail, null, options);
    loadGraph(options, canvas, status, detail);
  }

  async function loadGraph(options: GraphOptions, canvas: HTMLCanvasElement, status: HTMLElement, detail: HTMLElement) {
    const seq = ++loadSeq;
    try {
      const params = graphParams(options);
      const r = await fetch('/api/research/graph?' + params.toString());
      let data: GraphResponse = {};
      try {
        data = await r.json();
      } catch {}
      if (seq !== loadSeq || !canvas.isConnected) return;
      if (!r.ok || !data.ok || !data.graph) {
        setStatus(status, data.error || 'Graph unavailable', true);
        return;
      }
      const graph = data.graph;
      if (!Array.isArray(graph.nodes) || !graph.nodes.length) {
        const warning = Array.isArray(graph.warnings) && graph.warnings.length ? graph.warnings[0] : '';
        setStatus(status, warning || 'No graph yet');
        return;
      }
      if (seq !== loadSeq || !canvas.isConnected) return;
      const nextRuntime = draw(canvas, graph, detail, options);
      if (seq !== loadSeq || !canvas.isConnected) {
        if (nextRuntime && typeof nextRuntime.stop === 'function') nextRuntime.stop();
        return;
      }
      runtime = nextRuntime;
      status.classList.remove('error');
      status.hidden = true;
    } catch {
      if (seq === loadSeq && canvas.isConnected) {
        setStatus(status, 'Graph unavailable', true);
      }
    }
  }

  function setStatus(status: HTMLElement, text: unknown, isError = false): void {
    status.hidden = false;
    status.classList.toggle('error', !!isError);
    status.textContent = String(text ?? '');
  }

  function graphParams(options: GraphOptions): URLSearchParams {
    const params = new URLSearchParams();
    params.set('session_id', options.sessionId || options.activeId || '');
    params.set('depth', String(options.depth || 1));
    params.set('limit', '96');
    const focusIds = Array.isArray(options.focusIds) ? options.focusIds : [];
    for (const id of focusIds) params.append('focus', id);
    for (const item of (options.counterpoints || []).slice(0, 8)) {
      if (item) params.append('counterpoint', item);
    }
    return params;
  }

  function setDetail(detail: HTMLElement, node: GraphNode | null, options: GraphOptions): void {
    detail.innerHTML = '';
    if (!node) {
      const meta = document.createElement('div');
      meta.className = 'research-graph-detail-meta';
      meta.textContent = 'Select a node';
      detail.appendChild(meta);
      return;
    }
    const title = document.createElement('div');
    title.className = 'research-graph-detail-title';
    title.textContent = node.label || node.id || '';
    const meta = document.createElement('div');
    meta.className = 'research-graph-detail-meta';
    meta.textContent = nodeMeta(node);
    detail.append(title, meta);
    if (node.excerpt || node.url || node.path) {
      const body = document.createElement('div');
      body.className = 'research-graph-detail-body';
      setDetailBody(body, node.excerpt || node.url || node.path || '');
      detail.appendChild(body);
    }
    if (node.url || (node.id && !node.virtual)) {
      const action = document.createElement('button');
      action.type = 'button';
      action.className = 'drawer-btn research-copy';
      action.textContent = node.url ? 'Open source' : 'Open in Notes';
      action.onclick = () => openNode(node, options);
      detail.appendChild(action);
    }
  }

  function setDetailBody(body: HTMLElement, text: unknown): void {
    const value = String(text || '');
    if (window.Render && typeof window.Render.renderMarkdown === 'function') {
      body.classList.add('md');
      window.Render.renderMarkdown(body, value);
      return;
    }
    body.textContent = value;
  }

  function nodeMeta(node: GraphNode): string {
    return [node.kind || node.note_type || 'note', node.status || '', node.path || '', node.url || '']
      .filter(Boolean)
      .join(' · ');
  }

  function openNode(node: GraphNode, options: GraphOptions): void {
    if (typeof node.url === 'string' && node.url) {
      if (typeof options.onOpenSource === 'function') options.onOpenSource(node.url);
      return;
    }
    if (!node.id || node.virtual) return;
    if (typeof options.onOpenNote === 'function') options.onOpenNote(node.id);
  }

  function draw(
    canvas: HTMLCanvasElement,
    graph: { nodes?: RawGraphNode[]; edges?: GraphEdge[] },
    detail: HTMLElement,
    options: GraphOptions,
  ): GraphRuntime {
    const css = getComputedStyle(document.documentElement);
    const colors: GraphColors = {
      bg: css.getPropertyValue('--bg').trim() || 'Canvas',
      faint: css.getPropertyValue('--faint').trim() || 'GrayText',
      muted: css.getPropertyValue('--muted').trim() || 'GrayText',
      text: css.getPropertyValue('--text').trim() || 'CanvasText',
      textDim: css.getPropertyValue('--text-dim').trim() || 'GrayText',
      ok: css.getPropertyValue('--ok-dot').trim() || 'Highlight',
    };
    const nodes: GraphNode[] = (graph.nodes || []).map((node: RawGraphNode, index: number) => {
      const seed = hashUnit(node.id || String(index));
      const spread = 72 + hashUnit((node.id || '') + ':x') * 210;
      const sign = seed > 0.5 ? 1 : -1;
      const layerY = graphLayerY(node);
      return {
        ...node,
        x: sign * spread * (0.35 + hashUnit((node.id || '') + ':s')),
        y: layerY + (hashUnit((node.id || '') + ':y') - 0.5) * 54,
        layerY,
        vx: 0,
        vy: 0,
        fixed: false,
      };
    });
    const byId = new Map(nodes.map((node) => [node.id, node]));
    const edges = (graph.edges || [])
      .map((edge: GraphEdge) => ({ ...edge, source: byId.get(edge.src), target: byId.get(edge.dst) }))
      .filter(
        (edge: {
          source?: GraphNode;
          target?: GraphNode;
        }): edge is GraphEdge & { source: GraphNode; target: GraphNode } => !!edge.source && !!edge.target,
      );
    const neighbors = graphNeighbors(edges);
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D context unavailable');
    const context = ctx;
    const state: {
      scale: number;
      tx: number;
      ty: number;
      width: number;
      height: number;
      hover: GraphNode | null;
      selected: GraphNode | null;
    } = { scale: 1, tx: 0, ty: 0, width: 1, height: 1, hover: null, selected: null };
    let frame = 0;
    let running = true;
    let stillFrames = 0;
    let draggingNode: GraphNode | null = null;
    let panning = false;
    let start: { x: number; y: number; sx: number; sy: number; tx: number; ty: number } | null = null;
    let moved = false;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const ratio = window.devicePixelRatio || 1;
      state.width = Math.max(1, rect.width);
      state.height = Math.max(1, rect.height);
      canvas.width = Math.round(state.width * ratio);
      canvas.height = Math.round(state.height * ratio);
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      if (!state.tx && !state.ty) resetView();
      draw();
    };
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);

    function resetView() {
      const bounds = graphBounds(nodes);
      const sx = state.width / Math.max(220, bounds.w + 120);
      const sy = state.height / Math.max(220, bounds.h + 120);
      state.scale = Math.max(0.45, Math.min(1.35, Math.min(sx, sy)));
      state.tx = state.width / 2 - bounds.cx * state.scale;
      state.ty = state.height / 2 - bounds.cy * state.scale;
      draw();
    }

    function animate() {
      if (!running) return;
      const moved = stepResearchGraph(nodes, edges);
      draw();
      if (moved < 0.4) {
        stillFrames += 1;
        if (stillFrames >= 30) {
          frame = 0;
          return;
        }
      } else {
        stillFrames = 0;
      }
      frame = requestAnimationFrame(animate);
    }

    function wake() {
      if (!running || frame) return;
      stillFrames = 0;
      frame = requestAnimationFrame(animate);
    }

    function draw() {
      context.clearRect(0, 0, state.width, state.height);
      context.fillStyle = colors.bg;
      context.fillRect(0, 0, state.width, state.height);
      context.save();
      context.translate(state.tx, state.ty);
      context.scale(state.scale, state.scale);
      for (const edge of edges) drawGraphEdge(context, edge, state, neighbors, colors);
      for (const node of nodes) drawGraphNode(context, node, state, neighbors, colors);
      for (const node of nodes) drawGraphLabel(context, node, state, neighbors, colors);
      context.restore();
    }

    function pointerPoint(event: PointerEvent | WheelEvent | MouseEvent) {
      const rect = canvas.getBoundingClientRect();
      return {
        x: event.clientX - rect.left,
        y: event.clientY - rect.top,
      };
    }

    function worldPoint(event: PointerEvent | WheelEvent | MouseEvent) {
      const point = pointerPoint(event);
      return {
        x: (point.x - state.tx) / state.scale,
        y: (point.y - state.ty) / state.scale,
        sx: point.x,
        sy: point.y,
      };
    }

    function nodeAt(event: PointerEvent | WheelEvent | MouseEvent): GraphNode | null {
      const point = worldPoint(event);
      for (let i = nodes.length - 1; i >= 0; i--) {
        const node = nodes[i];
        const r = graphNodeRadius(node) + 4 / state.scale;
        if (Math.hypot(node.x - point.x, node.y - point.y) <= r) return node;
      }
      return null;
    }

    function onPointerDown(event: PointerEvent): void {
      const point = worldPoint(event);
      const hit = nodeAt(event);
      start = { ...point, tx: state.tx, ty: state.ty };
      moved = false;
      if (hit) {
        draggingNode = hit;
        hit.fixed = true;
        canvas.classList.add('dragging');
      } else {
        panning = true;
        canvas.classList.add('dragging');
      }
      canvas.setPointerCapture(event.pointerId);
    }

    function onPointerMove(event: PointerEvent): void {
      const point = worldPoint(event);
      if (start && Math.hypot(point.sx - start.sx, point.sy - start.sy) > 4) moved = true;
      if (draggingNode) {
        draggingNode.x = point.x;
        draggingNode.y = point.y;
        draggingNode.vx = 0;
        draggingNode.vy = 0;
        draw();
        return;
      }
      if (panning && start) {
        state.tx = start.tx + (point.sx - start.sx);
        state.ty = start.ty + (point.sy - start.sy);
        draw();
        return;
      }
      const hit = nodeAt(event);
      if (hit !== state.hover) {
        state.hover = hit;
        draw();
      }
    }

    function onPointerUp(event: PointerEvent): void {
      const hit = nodeAt(event);
      if (draggingNode) draggingNode.fixed = false;
      draggingNode = null;
      panning = false;
      canvas.classList.remove('dragging');
      try {
        canvas.releasePointerCapture(event.pointerId);
      } catch {}
      if (!moved) {
        state.selected = hit;
        setDetail(detail, hit, options);
      }
      start = null;
      draw();
      wake();
    }

    function onWheel(event: WheelEvent): void {
      event.preventDefault();
      const point = pointerPoint(event);
      const before = {
        x: (point.x - state.tx) / state.scale,
        y: (point.y - state.ty) / state.scale,
      };
      const factor = event.deltaY > 0 ? 0.9 : 1.1;
      state.scale = Math.max(0.35, Math.min(2.8, state.scale * factor));
      state.tx = point.x - before.x * state.scale;
      state.ty = point.y - before.y * state.scale;
      draw();
    }

    function onDblClick(event: MouseEvent): void {
      const hit = nodeAt(event);
      if (hit) openNode(hit, options);
    }

    canvas.addEventListener('pointerdown', onPointerDown);
    canvas.addEventListener('pointermove', onPointerMove);
    canvas.addEventListener('pointerup', onPointerUp);
    canvas.addEventListener('pointercancel', onPointerUp);
    canvas.addEventListener('wheel', onWheel, { passive: false });
    canvas.addEventListener('dblclick', onDblClick);
    resize();
    animate();

    return {
      reset: resetView,
      stop() {
        running = false;
        cancelAnimationFrame(frame);
        observer.disconnect();
        canvas.removeEventListener('pointerdown', onPointerDown);
        canvas.removeEventListener('pointermove', onPointerMove);
        canvas.removeEventListener('pointerup', onPointerUp);
        canvas.removeEventListener('pointercancel', onPointerUp);
        canvas.removeEventListener('wheel', onWheel);
        canvas.removeEventListener('dblclick', onDblClick);
      },
    };
  }

  function graphNeighbors(edges: GraphEdge[]) {
    const out = new Map();
    for (const edge of edges) {
      if (!out.has(edge.src)) out.set(edge.src, new Set());
      if (!out.has(edge.dst)) out.set(edge.dst, new Set());
      out.get(edge.src).add(edge.dst);
      out.get(edge.dst).add(edge.src);
    }
    return out;
  }

  function stepResearchGraph(
    nodes: GraphNode[],
    edges: Array<GraphEdge & { source: GraphNode; target: GraphNode }>,
  ): number {
    const repel = 2600;
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i];
      for (let j = i + 1; j < nodes.length; j++) {
        const b = nodes[j];
        let dx = a.x - b.x;
        let dy = a.y - b.y;
        let dist = Math.max(18, Math.hypot(dx, dy));
        const force = repel / (dist * dist);
        dx /= dist;
        dy /= dist;
        if (!a.fixed) {
          a.vx += dx * force;
          a.vy += dy * force;
        }
        if (!b.fixed) {
          b.vx -= dx * force;
          b.vy -= dy * force;
        }
      }
    }
    for (const edge of edges) {
      const a = edge.source;
      const b = edge.target;
      const desired = edge.kind === 'cites' ? 92 : 118;
      let dx = b.x - a.x;
      let dy = b.y - a.y;
      const dist = Math.max(1, Math.hypot(dx, dy));
      const force = (dist - desired) * 0.012;
      dx /= dist;
      dy /= dist;
      if (!a.fixed) {
        a.vx += dx * force;
        a.vy += dy * force;
      }
      if (!b.fixed) {
        b.vx -= dx * force;
        b.vy -= dy * force;
      }
    }
    let maxMove = 0;
    for (const node of nodes) {
      if (node.fixed) continue;
      node.vx += -node.x * 0.0025;
      node.vy += ((node.layerY || 0) - node.y) * 0.004;
      node.vx *= 0.86;
      node.vy *= 0.86;
      const stepX = Math.max(-6, Math.min(6, node.vx));
      const stepY = Math.max(-6, Math.min(6, node.vy));
      node.x += stepX;
      node.y += stepY;
      const move = Math.max(Math.abs(stepX), Math.abs(stepY));
      if (move > maxMove) maxMove = move;
    }
    return maxMove;
  }

  function drawGraphEdge(
    ctx: CanvasRenderingContext2D,
    edge: GraphEdge & { source: GraphNode; target: GraphNode },
    state: GraphState,
    neighbors: Map<string, Set<string>>,
    colors: GraphColors,
  ): void {
    const hoverActive = state.hover && (edge.src === state.hover.id || edge.dst === state.hover.id);
    const selectedActive =
      !hoverActive && state.selected && (edge.src === state.selected.id || edge.dst === state.selected.id);
    const active = hoverActive || selectedActive;
    ctx.save();
    ctx.globalAlpha = hoverActive
      ? 0.95
      : selectedActive
        ? 0.78
        : edge.kind === 'cites' || edge.kind === 'tagged'
          ? 0.2
          : 0.32;
    ctx.strokeStyle = hoverActive ? colors.ok : selectedActive ? colors.text : colors.faint;
    ctx.lineWidth = active ? 1.35 : edge.kind === 'cites' || edge.kind === 'tagged' ? 0.7 : 1;
    if (edge.kind === 'contradicts') ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(edge.source.x, edge.source.y);
    ctx.lineTo(edge.target.x, edge.target.y);
    ctx.stroke();
    ctx.restore();
  }

  function drawGraphNode(
    ctx: CanvasRenderingContext2D,
    node: GraphNode,
    state: GraphState,
    neighbors: Map<string, Set<string>>,
    colors: GraphColors,
  ): void {
    const hot = state.hover || state.selected;
    const connected = hot && (hot.id === node.id || (neighbors.get(hot.id) || new Set()).has(node.id));
    const hovered = state.hover && state.hover.id === node.id;
    const faded = hot && !connected;
    const r = graphNodeRadius(node);
    ctx.save();
    ctx.globalAlpha = faded ? 0.28 : 1;
    ctx.fillStyle = hovered ? colors.ok : node.kind === 'source_url' ? colors.faint : colors.textDim;
    if (!hovered && node.kind === 'counterpoint') ctx.fillStyle = colors.muted;
    if (!hovered && node.kind === 'concept') ctx.fillStyle = colors.text;
    ctx.beginPath();
    ctx.arc(node.x, node.y, r, 0, Math.PI * 2);
    ctx.fill();
    if (connected) {
      ctx.strokeStyle = hovered ? colors.ok : colors.text;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(node.x, node.y, r + 3, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawGraphLabel(
    ctx: CanvasRenderingContext2D,
    node: GraphNode,
    state: GraphState,
    neighbors: Map<string, Set<string>>,
    colors: GraphColors,
  ): void {
    const hot = state.hover || state.selected;
    const connected = hot && (hot.id === node.id || (neighbors.get(hot.id) || new Set()).has(node.id));
    const shouldShow = node.focus || connected || Number(node.weight || 0) >= 2.6;
    if (!shouldShow) return;
    const label = String(node.label || node.id || '').slice(0, 42);
    if (!label) return;
    ctx.save();
    ctx.fillStyle = connected || node.focus ? colors.text : colors.textDim;
    const fontSize = Math.max(11, 12 / state.scale);
    ctx.font = `${fontSize}px ${getComputedStyle(document.body).fontFamily}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.globalAlpha = connected || node.focus ? 0.95 : 0.7;
    const metrics = ctx.measureText(label);
    const pad = 8 / state.scale;
    const minX = (0 - state.tx) / state.scale + metrics.width / 2 + pad;
    const maxX = (state.width - state.tx) / state.scale - metrics.width / 2 - pad;
    const minY = (0 - state.ty) / state.scale + pad;
    const maxY = (state.height - state.ty) / state.scale - fontSize - pad;
    const labelX = minX <= maxX ? Math.max(minX, Math.min(maxX, node.x)) : node.x;
    const rawY = node.y + graphNodeRadius(node) + 5;
    const labelY = minY <= maxY ? Math.max(minY, Math.min(maxY, rawY)) : rawY;
    ctx.fillText(label, labelX, labelY);
    ctx.restore();
  }

  function graphNodeRadius(node: GraphNode): number {
    const base = node.kind === 'source_url' ? 3 : node.kind === 'concept' ? 5 : 4.2;
    return Math.max(2.8, Math.min(11, base + Math.sqrt(Number(node.weight || 1)) * 1.6));
  }

  function graphLayerY(node: RawGraphNode): number {
    if (node.kind === 'concept') return -130;
    if (node.kind === 'source_url') return 145;
    if (node.kind === 'counterpoint') return 90;
    if (node.kind === 'synthesis' || node.kind === 'decision') return -20;
    return 55;
  }

  function graphBounds(nodes: GraphNode[]): { cx: number; cy: number; w: number; h: number } {
    if (!nodes.length) return { cx: 0, cy: 0, w: 1, h: 1 };
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const node of nodes) {
      minX = Math.min(minX, node.x);
      minY = Math.min(minY, node.y);
      maxX = Math.max(maxX, node.x);
      maxY = Math.max(maxY, node.y);
    }
    return {
      cx: (minX + maxX) / 2,
      cy: (minY + maxY) / 2,
      w: maxX - minX,
      h: maxY - minY,
    };
  }

  function hashUnit(value: unknown): number {
    let hash = 2166136261;
    const text = String(value || '');
    for (let i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return ((hash >>> 0) % 10000) / 10000;
  }
  window.ResearchGraph = { render, dispose };
})();
